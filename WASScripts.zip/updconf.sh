#!/bin/sh

date=`date '+%m%d%y.%H%M'`
confdir=/data02/scripts/UpdateConf/ihsadm/$1
#incdir=/data02/ibm/httpserver/7.0-64/conf/Includes-*
logdir=/data02/ibm/httpserver/7.0-64/logs

##Verify user
if [ $(whoami) != "ihsadm" ]
then
  echo "You must be user 'ihsadm' to run this script."
  exit 0
fi

#Ensure proper arguments are used
if [ "$1" = "" ]
then
        echo "Error! You must input the siteId being updated!"
        echo "Usage: ./updconf.sh {siteId}"
        echo "Example: ./updconf.sh 11613-jp-generalpostingsite"
        exit 5
fi

#Check if directory exists, if not exit with error
if [ -d "$1" ]; then
        echo "Dir exists"
else
        echo "Dir does not exist! Please make sure the site directory exists!"
        exit 1
fi

#Check if master conf file exists, if not exit with error
if [ -f "$1/$1.conf" ]; then
        echo "Master conf exists"
else
        echo "Master conf does not exist!"
        exit 1
fi

#Check if ip.txt exists and is not 0 bytes. If not exit with error
if [ -s "ip.txt" ]; then
        echo "ip.txt exists"
else
        echo "ip.txt does not exist or is empty!"
        exit 1
fi

#Create the site conf file for each server
for i in `cat ip.txt|awk -F "|" '$1 == "'$1'" {print $2}'`
do
cp ${confdir}/$1.conf ${confdir}/$1.conf.${i}
done

#Backup original master conf file and remove archived files older than 30 days
cp ${confdir}/$1.conf ${confdir}/archive/$1.conf.${date}
find ${confdir}/archive/$1.conf.* -ignore_readdir_race -type f -mtime +30| xargs rm -f

#Update each conf file from IPs in ip.txt
for line in `cat ip.txt | grep $1` 
do
server=`echo -e $line| awk -F "|" '{print $2}'`
echo $server
ip=`echo -e $line| awk -F "|" '{print $3}'`
echo $ip
/usr/bin/perl -pi -e "s/10.47.[0-9]+.[0-9]+/${ip}/g" ${confdir}/$1.conf.${server}
done 

#Backup conf file on each server
for i in `cat ip.txt | awk -F "|" '$1 == "'$1'" {print $2}'`
do
incNum=`grep $1 ip.txt | grep $i | awk -F "|" '{print $4}'`
incdir=/data02/ibm/httpserver/7.0-64/conf/Includes-${incNum}/script_updated_confs
echo "Backing up ${incdir}/$1.conf on s262381ch3vl${i}"
ssh ihsadm@s262381ch3vl${i}.uschcg6.savvis.net "cp ${incdir}/$1.conf ${incdir}/archive/$1.conf.${date}"
done

#Copy conf out to each server
for i in `cat ip.txt | awk -F "|" '$1 == "'$1'" {print $2}'`
do 
incNum=`grep $1 ip.txt| grep $i | awk -F "|" '{print $4}'`
incdir=/data02/ibm/httpserver/7.0-64/conf/Includes-${incNum}/script_updated_confs
echo "Copy conf out to each server"
scp ${confdir}/$1.conf.${i} ihsadm@s262381ch3vl${i}.uschcg6.savvis.net:${incdir}/$1.conf
ssh ihsadm@s262381ch3vl${i}.uschcg6.savvis.net "chmod 644 ${incdir}/$1.conf"
#scp ${confdir}/$1.conf.${i} ihsadm@s262381ch3vl${i}.uschcg6.savvis.net:${logdir}/$1/$1.conf
#ssh ihsadm@s262381ch3vl${i}.uschcg6.savvis.net "chmod 644 ${logdir}/$1/$1.conf"
done

#Clean up directory
rm -f ${confdir}/$1.conf.*

#Restart apache on all servers
#for i in `cat ip.txt|awk '{print $1}'`
#do
#echo "Would you like to restart $i now?"
#
#        echo -n "Do you wish to continue? (y/n):"
#        read REPLY
#                if [[ "${REPLY}" == "y" ]];
#
#        then
#        ssh ihsadm@s262381ch3vl6${i}.uschcg6.savvis.net ""echo Restarting apache on $i";
#                sudo /data02/apache/apache20/bin/apachectl stop;
#                sleep 5;
#                sudo /data02/apache/apache20/bin/apachectl start;
#                sudo ps -ef|grep http|grep -v bash;
#                sleep 5
#                "
#        else
#
#        echo "Restart of $i has been cancelled"
#
#        fi
#done
