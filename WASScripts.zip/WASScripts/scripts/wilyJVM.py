#Set this variable per environment
nodeName = "s262381ch3vl194Node01"
cellName = "s262381ch3vl194Cell01"
suffixNumber = "testA"
scopeNode = AdminConfig.getid('/Cell:' + cellName + '/Node:' + nodeName + '/')
wasBaseDir = '/data01/websphere/'
wasLibDir = wasBaseDir + 'appserver/7.0-64/java/jre/lib'

vmjarFile = wasLibDir + 'vm.jar'
wilyProbJar = wasBaseDir + 'share/wily/connectors/AutoProbeConnector.jar'
wilyAgentJar = wasBaseDir + 'share/wily/Agent.jar'
wilyProfileDir = wasBaseDir + 'share/wily/profiles/'

runtimeStr = '-Dcom.wily.autoprobe.prependToJVMRuntimePath=' + vmjarFile
xbootStr = '-Xbootclasspath/p:' + wilyProbJar + ':' + wilyAgentJar
profileStr = '-Dcom.wily.introscope.agentProfile=' + wilyProfileDir

nodeServers = AdminConfig.list('Server', scopeNode)
import java
lineSeparator = java.lang.System.getProperty('line.separator')
nodeServers = nodeServers.split(lineSeparator)

for server in nodeServers:

 jvm = AdminConfig.list('JavaVirtualMachine', server)
 jvmArgsTmp = AdminConfig.showAttribute(jvm, 'genericJvmArguments')
 jvmArgs = str(jvmArgsTmp).strip()
 serverTmp = server
 serverName = serverTmp[0:serverTmp.find('(cells')]
 profileName = serverTmp[0:serverTmp.find(suffixNumber)] + '.profile'
 newJvmArgs = ""
 
 if ((jvmArgs.strip() == "None") or (jvmArgs.strip() == "")):
   newJvmArgs = runtimeStr + ' ' + xbootStr + ' ' + profileStr + serverName + '/' + profileName
 elif ((jvmArgsTmp.find('wily')) != -1):
   newJvmArgs = ""
 else:
   newJvmArgs = jvmArgs + ' ' + runtimeStr + ' ' + xbootStr + ' ' + profileStr + serverName + '/' + profileName

 print "-----------------------------------------------------------------------------------------------------------"

 if ((serverName.strip() == "nodeagent") or (serverName.strip() == "server1")):
   print "Skipping " + serverName
 elif (newJvmArgs.strip() == ""):
   print "Skipping JVM arguments for instance " + serverName
   print "Current JVM arguments : " + jvmArgs
 else:
   print "Updating JVM arguments for instance " + serverName
   print "From: " + jvmArgs
   print "To: : " + newJvmArgs
   AdminConfig.modify(jvm, [['genericJvmArguments', newJvmArgs]])

 continue

print "-----------------------------------------------------------------------------------------------------------"
print ""
print "Saving and synchronizing changes ..."
AdminConfig.save()
SyncNodeTemp = AdminControl.completeObjectName('type=NodeSync,node=' + nodeName + ',*' )
AdminControl.invoke(SyncNodeTemp, 'sync')
print "Done!"
print ""
print "Please restart the instances for the changes to take effect then verify them in the WILY admin console."
