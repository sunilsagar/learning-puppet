###############################################################################
# Script:      Jython script to be used on cluster related tasks              #
# Name:        cluster.py                                                     #
# Description: Any new tasks related to cluster should be added here          #
# Author:      KO WebTeam - Ariel Santiago                                    #
###############################################################################

def create(cellNameVar, clusterNameVar):

  cellIdVar = AdminConfig.getid('/Cell:'+ cellNameVar + '/')

  tempVar =  AdminConfig.create('ServerCluster', cellIdVar, '[[name ' + clusterNameVar + ']]')


#----------------------------------------------------------------------------------
# Main
#----------------------------------------------------------------------------------
procNameVar = sys.argv[0] 
saveVar = sys.argv[1]
cellNameVar = sys.argv[2]
clusterNameVar = sys.argv[3]

if procNameVar == 'create':
  create(cellNameVar, clusterNameVar)
else:
  print "Invalid method option"

if saveVar == 'yes':
  AdminConfig.save()
