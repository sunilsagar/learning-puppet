#!/bin/sh

###############################################################################
# Script:      Script to automate the KO Websphere initial site setup process #
# Name:        sitesetup.sh                                                   #
# Description: Calls jython scripts to create WAS objects                     #
# Author:      KO WebTeam - Ariel Santiago                                    #
###############################################################################

saveVar="yes"
commonCfg="common.cfg"
regionCfg="region.cfg"
scriptsDir=/data02/ibm/websphere/scripts/sitesetup/

#Initialize common values such as genUniquePorts to false, serverTemplateName to KODefault and so on
initCommonCfg ()
{
	genUniquePortsVar=`cat ${scriptsDir}${commonCfg} | grep genUniquePorts | awk '{print $2}'`
	serverTemplateNameVar=`cat ${scriptsDir}$commonCfg | grep serverTemplateName | awk '{print $2}'`
	baseWorkingDirectoryVar=`cat ${scriptsDir}${commonCfg} | grep baseWorkingDirectory | awk '{print $2}'`
	httpSessionCloneNameVar=`cat ${scriptsDir}${commonCfg} | grep customHttpSessionCloneId | awk '{print $2}'`
	maxHeapSizeVar=`cat ${scriptsDir}${commonCfg} | grep maxHeapSize | awk '{print $2}'`
}

#Initialize variables based on the selected environment or region
initEnvCfg ()
{
        cellNameVar=`cat ${1} | grep cellName | awk '{print $2}'`
        wasEnvDirVar=`cat ${1} | grep wasEnvDir | awk '{print $2}'`
}

resetGlobal ()
{
	userId=`whoami`
	serverNameVar=""
	serverBootStrapAddress=""
	hostNameVar=""
	portValVar=""
}

#Display string and return a response string
askQuestion () {
  while true
  do
      echo -n "$1 "
      read answer

      if [[ ! -z "${answer}" ]] ; then
          REPLY=${answer}
          return 0
      fi
      echo "Response required. Please try again."
  done
}

askQuestionLoopYN () {
  while true
  do
      echo -n "$1 "
      read answer
      REPLY=${answer}
      if [[ ( ${REPLY} == "y" ) || ( ${REPLY} == "n" ) ]] ; then
         break
      else
         echo "Invalid response! Please try again."
      fi
  done
}

createCluster () {
	displayFlag=${1}
	clusterNameVarLoc="${2}Cluster"

	echo ""	
	echo "*******************************************************************************************************"
	echo "(1) Cluster details"
	echo ""
	echo "Cluster name: ${clusterNameVarLoc}"
	if [[ "${displayFlag}" == "n" ]]; then
	echo ""	
	askQuestionLoopYN "Create the cluster based on the above information? ${changeMsg}"
	if [[ "${REPLY}" == "y" ]]; then
		echo "${wasEnvDirVar}/bin/wsadmin.sh -lang jython -f ${scriptsDir}cluster.py (1)create (2)$saveVar (3)$cellNameVar (4)$clusterNameVarLoc"
		${wasEnvDirVar}/bin/wsadmin.sh -lang jython -f ${scriptsDir}cluster.py create $saveVar $cellNameVar $clusterNameVarLoc
	fi
	fi
}

createVhost () {
	displayFlag=${1}
	vhostNameVarLoc=${2}

	echo ""	
	echo "*******************************************************************************************************"
	echo "(5) Virtual host details"
	echo ""	
	echo "Virtual host name: ${vhostNameVarLoc}"
	if [[ "${displayFlag}" == "n" ]]; then
	echo ""	
	askQuestionLoopYN "Create the virtual host based on the above information? ${changeMsg}"
	if [[ "${REPLY}" == "y" ]]; then
		echo "${wasEnvDirVar}/bin/wsadmin.sh -lang jython -f ${scriptsDir}vhost.py (1)create (2)$saveVar (3)$vhostNameVarLoc (4)$cellNameVar"
		${wasEnvDirVar}/bin/wsadmin.sh -lang jython -f ${scriptsDir}vhost.py create $saveVar $vhostNameVarLoc $cellNameVar
	fi
	fi
}

addVhostAlias () {
	displayFlag=${1}
	vhostNameVarLoc=${2}
	hostNameVarLoc=${3}
	portValVarLoc=${4}
	
	echo ""	
	echo "*******************************************************************************************************"
	echo "(6) Virtual host aliases"

  	lengthTemp=`expr length ${hostNameVarLoc}`
  	lengthTemp=`expr $lengthTemp - 1`
  	hostNameVarTemp=`echo ${hostNameVarLoc:0:lengthTemp}`
  	lengthTemp=`expr length ${portValVarLoc}`
  	lengthTemp=`expr $lengthTemp - 1`
 	portValVarTemp=`echo ${portValVarLoc:0:lengthTemp}`

	echo ""	
	echo "Vhost hostname(s): ${hostNameVarTemp}"
	echo "      port(s): ${portValVarTemp}"

	if [[ "${displayFlag}" == "n" ]]; then
	echo ""	
	askQuestionLoopYN "Add Vhost aliases based on the above information? ${changeMsg}"
	if [[ "${REPLY}" == "y" ]]; then
		echo "${wasEnvDirVar}/bin/wsadmin.sh -lang jython -f ${scriptsDir}vhost.py (1)addAlias (2)$saveVar (3)$vhostNameVarLoc (4)$hostNameVarLoc (5)$portValVarLoc"
		${wasEnvDirVar}/bin/wsadmin.sh -lang jython -f ${scriptsDir}vhost.py addAlias $saveVar $vhostNameVarLoc $hostNameVarLoc $portValVarLoc
	fi
	fi
}

createAppServer () {
	displayFlag=${1}
	envCfg=$2
	serverNameTemp=$3
	instanceCtr=`grep nodeName ${envCfg} | wc -l`
	count=1
	echo ""
	echo "*******************************************************************************************************"
	echo "(2) Appserver details"
	#echo "*******************************************************************************************************"

	while [ $count -le $instanceCtr ]
	do
  		hostSuffixVar=`cat ${envCfg} | grep hostSuffix${count} | awk '{print $2}'`
  		serverNameVarLoc="${serverNameTemp}${hostSuffixVar}"
  		nodeNameVarLoc=`cat ${envCfg} | grep nodeName${count} | awk '{print $2}'`
  		clusterNameVarLoc="${serverNameTemp}Cluster"
  		echo ""
  		echo "Cluster member#${count}: ${serverNameVarLoc}"
  		echo "Node name: ${nodeNameVarLoc}"
		echo "AppServer Template: ${serverTemplateNameVar}"
		echo "Generate Unique Ports: ${genUniquePortsVar}"
  		count=`expr $count + 1`
	done

	if [[ "${displayFlag}" == "n" ]]; then

        echo ""
	askQuestionLoopYN "Create the Appservers and assign to the cluster based on the above information? ${changeMsg}"

	if [[ "${REPLY}" == "y" ]]; then
	count=1
	while [ $count -le $instanceCtr ]
	do
  		hostSuffixVar=`cat ${envCfg} | grep hostSuffix${count} | awk '{print $2}'`
  		serverNameVarLoc="${serverNameTemp}${hostSuffixVar}"
  		nodeNameVarLoc=`cat ${envCfg} | grep nodeName${count} | awk '{print $2}'`
  		clusterNameVarLoc="${serverNameTemp}Cluster"
	        if [ $count -eq 1 ]; then
			echo "${wasEnvDirVar}/bin/wsadmin.sh -lang jython -f ${scriptsDir}appserver.py (1)create (2)$saveVar (3)$clusterNameVarLoc (4)$nodeNameVarLoc (5)$serverNameVarLoc (6)$genUniquePortsVar (7)$serverTemplateNameVar"
       			${wasEnvDirVar}/bin/wsadmin.sh -lang jython -f ${scriptsDir}appserver.py create $saveVar $clusterNameVarLoc $nodeNameVarLoc $serverNameVarLoc $genUniquePortsVar $serverTemplateNameVar
        	else
       			echo "${wasEnvDirVar}/bin/wsadmin.sh -lang jython -f ${scriptsDir}appserver.py (1)createNext (2)$saveVar (3)$clusterNameVarLoc (4)$nodeNameVarLoc (5)$serverNameVarLoc (6)$genUniquePortsVar"
       			${wasEnvDirVar}/bin/wsadmin.sh -lang jython -f ${scriptsDir}appserver.py createNext $saveVar $clusterNameVarLoc $nodeNameVarLoc $serverNameVarLoc $genUniquePortsVar
        	fi
  		count=`expr $count + 1`
	done
	fi
	fi
}

updateAppServer () {
	displayFlag=${1}
	envCfg=$2
	serverNameTemp=$3
	instanceCtr=`grep nodeName ${envCfg} | wc -l`
	count=1

	echo ""
	echo "*******************************************************************************************************"
	echo "(3) Appserver configuration and setting details"
	#echo "*******************************************************************************************************"

	while [ $count -le $instanceCtr ]
	do
 		hostSuffixVar=`cat ${envCfg} | grep hostSuffix${count} | awk '{print $2}'`
		serverNameVarLoc="${serverNameTemp}${hostSuffixVar}"
  		nodeNameVarLoc=`cat ${envCfg} | grep nodeName${count} | awk '{print $2}'`
  		clusterNameVarLoc="${serverNameTemp}Cluster"
		echo ""	
  		echo "Cluster member#${count}: ${serverNameVarLoc}"
  		echo "Node name: ${nodeNameVarLoc}"
  		echo "HttpSessionCloneId: ${serverNameVarLoc}"
  		echo "Maximum Heap Size: ${maxHeapSizeVar}"
  		echo "Log Directory: ${baseWorkingDirectoryVar}${serverNameVarLoc}"
  		count=`expr $count + 1`
	done
	
	if [[ "${displayFlag}" == "n" ]]; then
	echo ""
	askQuestionLoopYN "Update the Appservers' configuration based on the above information? ${changeMsg}"

        if [[ "${REPLY}" == "y" ]]; then
        count=1
        while [ $count -le $instanceCtr ]
        do
                hostSuffixVar=`cat ${envCfg} | grep hostSuffix${count} | awk '{print $2}'`
                serverNameVarLoc="${serverNameTemp}${hostSuffixVar}"
                nodeNameVarLoc=`cat ${envCfg} | grep nodeName${count} | awk '{print $2}'`
                clusterNameVarLoc="${serverNameTemp}Cluster"
       		echo "${wasEnvDirVar}/bin/wsadmin.sh -lang jython -f ${scriptsDir}appserver.py (1)update (2)$saveVar (3)$nodeNameVarLoc (4)$serverNameVarLoc (5)$cellNameVar (6)$httpSessionCloneNameVar (7)$serverNameVarLoc (8)$baseWorkingDirectoryVar (9)$maxHeapSizeVar"
       		${wasEnvDirVar}/bin/wsadmin.sh -lang jython -f ${scriptsDir}appserver.py update $saveVar $nodeNameVarLoc $serverNameVarLoc $cellNameVar $httpSessionCloneNameVar $serverNameVarLoc $baseWorkingDirectoryVar $maxHeapSizeVar
                count=`expr $count + 1`
        done
        fi
	fi
}

updatePort () {
	displayFlag=${1}
        envCfg=$2
        serverNameTemp=$3
	endPointValTemp=$4

        echo ""
        echo "*******************************************************************************************************"
        echo "(4) Appserver port details"
        #echo "*******************************************************************************************************"

#	endPointList=(BOOTSTRAP_ADDRESS CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS DCS_UNICAST_ADDRESS ORB_LISTENER_ADDRESS SAS_SSL_SERVERAUTH_LISTENER_ADDRESS SIB_ENDPOINT_ADDRESS SIB_ENDPOINT_SECURE_ADDRESS SIB_MQ_ENDPOINT_ADDRESS SIB_MQ_ENDPOINT_SECURE_ADDRESS SIP_DEFAULTHOST SIP_DEFAULTHOST_SECURE SOAP_CONNECTOR_ADDRESS WC_adminhost WC_adminhost_secure WC_defaulthost WC_defaulthost_secure)
	endPointList=(BOOTSTRAP_ADDRESS CSIV2_SSL_MUTUALAUTH_LISTENER_ADDRESS CSIV2_SSL_SERVERAUTH_LISTENER_ADDRESS DCS_UNICAST_ADDRESS IPC_CONNECTOR_ADDRESS ORB_LISTENER_ADDRESS SAS_SSL_SERVERAUTH_LISTENER_ADDRESS SIB_ENDPOINT_ADDRESS SIB_ENDPOINT_SECURE_ADDRESS SIB_MQ_ENDPOINT_ADDRESS SIB_MQ_ENDPOINT_SECURE_ADDRESS SIP_DEFAULTHOST SIP_DEFAULTHOST_SECURE SOAP_CONNECTOR_ADDRESS WC_adminhost WC_adminhost_secure WC_defaulthost WC_defaulthost_secure)

	endPointNameVar=''
	endPointValVar=''
	
        echo ""
	for (( i = 0 ; i < ${#endPointList[@]} ; i++ ))
	do
		endPointNameTemp=${endPointList[$i]}
		endPointNameVar=$endPointNameVar$endPointNameTemp'|'
		endPointValVar=$endPointValVar$endPointValTemp'|'
		echo "${endPointList[$i]}: ${endPointValTemp}"
###### The following line dictates how the port numbers are incremented #######
		endPointValTemp=`expr $endPointValTemp + 1`	
#		endPointValTemp=`expr $endPointValTemp + 100`	
	done

	if [[ "${displayFlag}" == "n" ]]; then
        echo ""
        askQuestionLoopYN "Update the ports based on the above information? ${changeMsg}"

        if [[ "${REPLY}" == "y" ]]; then
		instanceCtr=`grep nodeName ${envCfg} | wc -l`
	        count=1
      		while [ $count -le $instanceCtr ]
	        do
       	        	hostSuffixVar=`cat ${envCfg} | grep hostSuffix${count} | awk '{print $2}'`
                	serverNameVarLoc="${serverNameTemp}${hostSuffixVar}"
                	nodeNameVarLoc=`cat ${envCfg} | grep nodeName${count} | awk '{print $2}'`
                	hostNameVarLoc=`cat ${envCfg} | grep hostName${count} | awk '{print $2}'`

			echo "${wasEnvDirVar}/bin/wsadmin.sh -lang jython -f ${scriptsDir}port.py (1)update (2)$saveVar (3)$serverNameVarLoc (4)$nodeNameVarLoc (5)$hostNameVarLoc (6)$endPointNameVar (7)$endPointValVar"
			${wasEnvDirVar}/bin/wsadmin.sh -lang jython -f ${scriptsDir}port.py update $saveVar $serverNameVarLoc $nodeNameVarLoc $hostNameVarLoc $endPointNameVar $endPointValVar 
        	        count=`expr $count + 1`
        	done
	fi
	fi
}

continueSetup () {
     echo ""
     askQuestionLoopYN "Continue using this initial site setup tool? (y/n):"
     if [[ "${REPLY}" != "y" ]]; then
         exit
     fi
}

syncNodes () {
	envCfg=$1
        echo ""
        echo "*******************************************************************************************************"
        echo "(7) Synchronization"
        #echo "*******************************************************************************************************"
        echo ""
	askQuestionLoopYN "Synchronize changes to the nodes now? (y/n):"
        if [[ "${REPLY}" == "y" ]]; then
        instanceCtr=`grep nodeName ${envCfg} | wc -l`
        count=1
        while [ $count -le $instanceCtr ]
        do
        	nodeNameVarLoc=`cat ${envCfg} | grep nodeName${count} | awk '{print $2}'`
        	echo "${wasEnvDirVar}/bin/wsadmin.sh -lang jython -f ${scriptsDir}node.py (1)sync (2)$nodeNameVarLoc"
        	${wasEnvDirVar}/bin/wsadmin.sh -lang jython -f ${scriptsDir}node.py sync $nodeNameVarLoc
        	count=`expr $count + 1`
        done
	else
		echo "Please ensure to synchronize the nodes for the changes to properly take effect !!!"
     	fi
}

displayCreateAllObjects() {
	displayFlag=${1}
        createCluster ${displayFlag} ${serverNameVar}
        createAppServer ${displayFlag} ${scriptsDir}${regionType}_Env.cfg ${serverNameVar}
        updateAppServer ${displayFlag} ${scriptsDir}${regionType}_Env.cfg ${serverNameVar}
        updatePort ${displayFlag} ${scriptsDir}${regionType}_Env.cfg ${serverNameVar} ${serverBootStrapAddress}
	createVhost ${displayFlag} ${serverNameVar}
	addVhostAlias ${displayFlag} ${serverNameVar} ${hostNameVar} ${portValVar}
	if [[ "${displayFlag}" == "n" ]]; then
		syncNodes ${scriptsDir}${regionType}_Env.cfg
	fi
	
}



#############
#MAIN
#############

clear

initCommonCfg

regionVar=`cat ${scriptsDir}${regionCfg} | grep Region | awk '{print $2}'`
regionList=(`echo ${regionVar} | sed 's/|/ /g'`)
changeMsg="Changes will be saved to master configuration! (y/n):"

while true
do
  resetGlobal
  #echo "NOTE: Please refrain from using this script until further notice!!!"
  #exit
  case $userId in
	wasadm) askQuestionLoopYN "You are logged in as $userId to setup a WAS 7.0 site. Please enter 'y' to continue OR enter 'n' and login as wasadm instead (y/n):";;
#	was61) askQuestionLoopYN "You are logged in as $userId and setting up a WAS 6.1 site. Please enter 'y' to continue OR enter 'n' and login as wasadmin instead (y/n):";;
#	*) echo "You have to login as wasadm OR was61 in order to use this script!"; exit ;;
	*) echo "You have to login as wasadm in order to use this script!"; exit ;;
  esac

  if [[ "${REPLY}" == "n" ]]; then
	exit
  fi

  askQuestion "1.) Enter the site application server name:"
  serverNameVar=${REPLY}
  askQuestion "2.) Enter the application server's BOOTSTRAP_ADDRESS:"
  serverBootStrapAddress=${REPLY}

  #Display valid regions
  while true
  do
    for (( ndx=0; ${ndx} < ${#regionList[*]} ; ndx=$ndx+1 ))
    do
       let optionNum=${ndx}+1
       echo "    ${optionNum}> ${regionList[${ndx}]}"
    done
    askQuestion "3.) What environment is the application associated with? Choose from the above option(s):"

    if [[ ( ${REPLY} -lt 1 ) || ( ${REPLY} -gt ${#regionList[*]} ) ]] ; then
      echo "Invalid response.  Please try again."
    else
      selectedOption=${REPLY}-1
      regionType="${regionList[${selectedOption}]}"
      break
    fi
  done

  echo "4.) Enter the virtualhost's hostname:port details for the following aliases"
  hostCtr=1
  REPLY="y"
  while [[ "${REPLY}" == "y" ]]
    do
      echo "    <Alias#${hostCtr}>"
      askQuestion "    hostname: "
      hostNameVar=$hostNameVar$REPLY'|'
      askQuestion "    port: "
      portValVar=$portValVar$REPLY'|'
      askQuestionLoopYN "    Continue to add another? (y/n): "
      hostCtr=`expr $hostCtr + 1`
  done

  lengthTemp=`expr length ${hostNameVar}`
  lengthTemp=`expr $lengthTemp - 1`  
  hostNameVarTemp=`echo ${hostNameVar:0:lengthTemp}`
  lengthTemp=`expr length ${portValVar}`
  lengthTemp=`expr $lengthTemp - 1`  
  portValVarTemp=`echo ${portValVar:0:lengthTemp}`

  echo ""
  echo "You have selected the following details:"
  echo ""
  echo "*******************************************************************************************************"
  echo "Application server name: ${serverNameVar}"
  echo "BOOTSTRAP_ADDRESS: ${serverBootStrapAddress}"
  echo "Region: ${regionType}"
  echo "Vhost hostname(s): ${hostNameVarTemp}"
  echo "      port(s): ${portValVarTemp}"
  echo "*******************************************************************************************************"
  echo ""
  askQuestionLoopYN "If this is correct, enter y to display the details of all objects that will be created. Otherwise enter n to make the necessary corrections (y/n):"
 
  if [[ "${REPLY}" == "y" ]]; then
 
  	initEnvCfg ${scriptsDir}${regionType}_Env.cfg

	#Display all object informations by passing parameter y
	displayCreateAllObjects "y"
	echo ""
	echo "------------------------------------------------------------------------------------------------------------------------------------------------------------------"
	askQuestionLoopYN "THE SUCCEEDING OPTIONS WILL ALLOW YOU TO CONTINUE OR SKIP THE OBJECT CREATION/UPDATE 1 AFTER ANOTHER. ENTER y TO CONTINUE OR n TO ABANDON (y/n):"
	echo "------------------------------------------------------------------------------------------------------------------------------------------------------------------"
	if [[ "${REPLY}" == "y" ]]; then
	#Prompt by passing parameter n and create objects as desired
	displayCreateAllObjects "n"
	else
	echo "You have chosen to abandon!"
	fi
  	continueSetup
	echo ""
  else
  	continueSetup
	echo ""
  fi

done
