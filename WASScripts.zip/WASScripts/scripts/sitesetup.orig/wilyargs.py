############################################################################################
# Script:      Jython script to be used for adding Wily JVM arguments                      #
# Name:        wilyargs.py                                                                 #
# Description: Any new tasks related to adding generic JVM arguments should be added here  #
# Author:      KO WebTeam - Aaron Kottmann                                                 #
############################################################################################

#def sync(nodeNameVar):
#
#    SyncNodeTemp = AdminControl.completeObjectName('type=NodeSync,node=' + nodeNameVar + ',*' )
#    AdminControl.invoke(SyncNodeTemp, 'sync')

def addWilyArgs(clusterNameVar, nodeNameVar, serverNameVar, genUniquePortsVar, templateNameVar):




  AdminTask.setJVMProperties('[-serverName 288-dietcoke -nodeName s262381ch3vl194Node01 -genericJvmArguments "-Dcom.wily.autoprobe.prependToJVMRuntimePath=/data01/opt/websphere61/AppServer6/java/jre/lib/vm.jar -Xbootclasspath/p:/data01/opt/websphere61/share/wily/connectors/AutoProbeConnector.jar:/data01/opt/websphere61/share/wily/Agent.jar -Dcom.wily.introscope.agentProfile=/data01/opt/websphere61/share/wily/profiles/8080-br-brazilbrand63/8080-br-brazilbrand.profile"]')

#----------------------------------------------------------------------------------
# Main
#----------------------------------------------------------------------------------
procNameVar = sys.argv[0]
saveVar = sys.argv[1]

if procNameVar == 'sync':
  nodeNameVar = sys.argv[1]
  sync(nodeNameVar)
else:
  print "Invalid method call"

