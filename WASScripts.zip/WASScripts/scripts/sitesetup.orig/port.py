###############################################################################
# Script:      Jython script to be used on appserver port related tasks       #
# Name:        port.py                                                        #
# Description: Any new tasks related to ports should be added here            #
# Author:      KO WebTeam - Ariel Santiago                                    #
###############################################################################

def updateEndPointsPortNumbers(serverNameVar, nodeNameVar, hostNameVar, endPointNameVar, endPointValVar):

  endPointNameVar = endPointNameVar.replace('|',' ')
  endPointValVar = endPointValVar.replace('|',' ')
  endPointNameArray = endPointNameVar.split()
  endPointValArray = endPointValVar.split()

  count = 0

  for i in endPointNameArray:
    AdminTask.modifyServerPort (serverNameVar, '[-nodeName ' + nodeNameVar + ' -endPointName ' + endPointNameArray[count] + ' -host ' + hostNameVar + '  -port ' + endPointValArray[count] + ' -modifyShared true]')
    count = count + 1

#----------------------------------------------------------------------------------
# Main
#----------------------------------------------------------------------------------
procNameVar = sys.argv[0]
saveVar = sys.argv[1]

if procNameVar == 'update':
  serverNameVar = sys.argv[2]
  nodeNameVar = sys.argv[3]
  hostNameVar = sys.argv[4]
  endPointNameVar = sys.argv[5] 
  endPointValVar = sys.argv[6]
  updateEndPointsPortNumbers(serverNameVar, nodeNameVar, hostNameVar, endPointNameVar, endPointValVar)
else:
  print "Invalid method call"

if saveVar == 'yes':
  AdminConfig.save()

