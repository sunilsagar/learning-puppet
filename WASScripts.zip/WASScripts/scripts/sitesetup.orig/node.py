###############################################################################
# Script:      Jython script to be used on node related tasks                 #
# Name:        node.py                                                        #
# Description: Any new tasks related to node should be added here             #
# Author:      KO WebTeam - Ariel Santiago                                    #
###############################################################################

def sync(nodeNameVar):

    SyncNodeTemp = AdminControl.completeObjectName('type=NodeSync,node=' + nodeNameVar + ',*' )
    AdminControl.invoke(SyncNodeTemp, 'sync')


#----------------------------------------------------------------------------------
# Main
#----------------------------------------------------------------------------------
procNameVar = sys.argv[0]

if procNameVar == 'sync':
  nodeNameVar = sys.argv[1]
  sync(nodeNameVar)
else:
  print "Invalid method call"

