###############################################################################
# Script:      Jython script to be used on virtual host related tasks         #
# Name:        vhost.py                                                       #
# Description: Any new tasks related to virtual host should be added here     #
# Author:      KO WebTeam - Ariel Santiago                                    #
###############################################################################

def create(vhostNameVar, cellNameVar):

  cellIdVar = AdminConfig.getid('/Cell:' + cellNameVar + '/')

  AdminConfig.create('VirtualHost', cellIdVar , [['name', vhostNameVar]])

def addAlias(vhostNameVar, hostNameVar, portValVar):

  hostNameVar = hostNameVar.replace('|',' ')
  portValVar = portValVar.replace('|',' ')
  hostNameArray = hostNameVar.split()
  portValArray = portValVar.split()

  vhostIdVar = AdminConfig.getid ('/VirtualHost:' + vhostNameVar + '/')

  count = 0

  for i in hostNameArray:
    AdminConfig.create('HostAlias', vhostIdVar, [['hostname', hostNameArray[count]], ['port', portValArray[count]]])
    count = count + 1

#----------------------------------------------------------------------------------
# Main
#----------------------------------------------------------------------------------
procNameVar = sys.argv[0]
saveVar = sys.argv[1]

if procNameVar == 'create':
  vhostNameVar = sys.argv[2]
  cellNameVar = sys.argv[3]
  create(vhostNameVar, cellNameVar)
elif procNameVar == 'addAlias':
  vhostNameVar = sys.argv[2]
  hostNameVar = sys.argv[3]
  portValVar = sys.argv[4]
  addAlias(vhostNameVar, hostNameVar, portValVar)
else:
  print "Invalid method call"

if saveVar == 'yes':
  AdminConfig.save()

