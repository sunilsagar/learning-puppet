###################################################################################### 
# Script:      Jython script to be used to Add WebContainer Custom Property          #
# Name:        AddWCCustomProps.py                                                   #
# Description: Any new tasks related to adding WebContainer Custom Properties 		 #	
#				should be added here 												 #
# Author:      KO WebTeam - Reggie de Veas                                           #
######################################################################################

import java.util as util 
import java.io as javaio 
import sys, getopt, re;
import time
import string

global lineSeparator
lineSeparator = java.lang.System.getProperty('line.separator')

def initCommonCfg():
	cellNameVar	= AdminControl.getCell()

def clearscreen():
     print  "\n"*500
     
def quit():
    sys.exit()

def getListArray(l):
    return l.splitlines()	

def getServerName(s):
    return AdminConfig.showAttribute(s, 'name')
	
def is_digit(s):
    try:
        float(s)
        return 0
    except ValueError:
        return 1

def getListArray(l):
    return l.splitlines()	
	
def askQuestionLoopYN(question):
	global REPLY
	REPLY = ''
	while ((REPLY != "Y") | (REPLY != "N")):
		REPLY = raw_input(question)
		REPLY = string.upper(REPLY)
		if ((REPLY == "Y") | (REPLY == "N")):
			return REPLY
			break
		else:
			print  "\n\t\t Invalid response! Please try again."

def choice_N():
	askQuestionLoopYN("\n\t\tYou have chosen to abort.. Please press Y to start from the beginning, or press N to exit.")
	if (REPLY == "Y"):
		#clearscreen()
		whichApp()
		sync_node()
		quit()
	elif (REPLY == "N"):
		quit()							

def sync_node():
	choice = ""
	cell = AdminControl.getCell()
	while (choice != "Y|N"):	
		choice = raw_input("\n\t\t Synchronize changes with the Nodes? [Y|N]: ")
		choice = string.upper(choice)
		if (choice == "Y"):	
			## Full Syncronization ##
			print "\n\t\t Synchronizing configuration with Master Repository "
			nodelist = AdminTask.listManagedNodes()
			for nodename in getListArray(nodelist):
				print "\t\t Doing Full Resynchronization of node %s" % nodename
				####################Identifying the ConfigRepository MBean and assign it to variable######################
				#repo = AdminControl.completeObjectName('type=ConfigRepository,process=nodeagent,node='+ nodename +',*')
				#AdminControl.invoke(repo, 'refreshRepositoryEpoch')
				sync = AdminControl.completeObjectName('cell='+ cell +',node='+ nodename +',type=NodeSync,*')
				try:
					AdminControl.invoke(sync , 'sync')
				except:
					print "\t\t Invalid node Name or Node Not Running.. Skipping"						
				else:	
					AdminControl.invoke(sync , 'sync')
				#time.sleep(3)
			print "\t\t ----------------------------------------------------------------------------------------- "
			print "\t\t Full Resynchronization completed "
			print "\t\t ----------------------------------------------------------------------------------------- "
			x = raw_input("\n\t\tPress Enter to Continue...")
			break
		elif (choice == "N"):
			choice_N()
				
		
def getServerId(a):
	global serverId
	serverId = AdminConfig.getid('/Server:' + a + '/')
	#return serverId
	
def getWebContainerId(s):
	global webContainerId
	webContainerId = AdminConfig.list('WebContainer', s)	
	#return webContainerId
	
def getPropertyList(w):
	global PropertyList
	PropertyList = AdminConfig.list('Property', w)
	#return PropertyList
	
def addNewCustProperty():
	global newCustPropList
	newCustPropList = {}
	flag = ""
	while (flag != 0):
		name = raw_input("\n\t\t\t Property Name? : ")
		value = raw_input("\n\t\t\t Property Value? : ")
		newCustPropList[name] = value
		askQuestionLoopYN("\n\t\t Add another? [Y|N]: ")
		if (REPLY == "Y"):
			flag = 1
		if (REPLY == "N"):
			flag = 0
			break
			
def addWCCustomProperty(appName):
	addNewCustProperty()
	#print "\n\t\t The following will be added:"
	#getServerId(appName)
	#serverId = AdminConfig.getid('/Cell:' + cellNameVar + '/Node:/Server:' + appName + '/')	
	#print serverId
	for key,value in newCustPropList.items():
		CustPropNameVar = key
		CustPropValVar = value
		name = ['name', CustPropNameVar]
		value = ['value', CustPropValVar]
		attrib = [name, value]
		#print attrib
		#webContainerId = AdminConfig.list('WebContainer', serverId)
		#print webContainerId
		AdminConfig.create('Property', webContainerId, attrib)
		print "\n\t\t\t Adding Property %s=%s to server %s" % (CustPropNameVar,CustPropValVar,getServerName(serverId))
	AdminConfig.save()
	#showCustomProperty(serverId)
	
def updateWCCustomProperty(appName):
	selectCustomProperty()
	NewName = raw_input("\n\t\t\t New Property Name? ["+CustPropNameVar+"] : ")
	if (NewName == ""):
		NewName = CustPropNameVar
	NewValue = raw_input("\n\t\t\t New Property Value? ["+CustPropValVar+"] : ")
	if (NewValue == ""):
		NewValue = CustPropValVar
	name = ['name', NewName]
	value = ['value', NewValue]
	attrib = [name, value]
	#print attrib
	#serverId = AdminConfig.getid('/Cell:' + cellNameVar + '/Node:' + nodeNameVar + '/Server:' + appName + '/')
	#webContainerId = AdminConfig.list('WebContainer', serverId)
	#PropertyId = (re.search("^"+CustPropNameVar, (AdminConfig.list('Property', webContainerId))))
	PropertyId = SelectedPropList
	#print PropertyId
	AdminConfig.modify(PropertyId, attrib)		
	AdminConfig.save()
	print "\n\t\t\t Custom Property %s=%s has been added to server %s" % (NewName,NewValue,getServerName(serverId))
	
def removeWCCustomProperty():
	global NewArrayLen
	selectCustomProperty()
	askQuestionLoopYN("\n\t\t You have selected to remove "+CustPropNameVar+"="+CustPropValVar+" from server "+getServerName(serverId)+". Proceed with the changes? [Y|N]: ")
	if (REPLY == "N"):
		x = raw_input("\n\t\t\t Aborting...Press Enter to continue..")
		#removeWCCustomProperty()
	elif (REPLY == "Y"):	
		AdminConfig.remove(SelectedPropList)
		AdminConfig.save()
		print "\n\t\t\t Custom Property %s=%s has been deleted in server %s"  % (CustPropNameVar,CustPropValVar,getServerName(serverId))		
	NewArrayLen = arrayLen - 1
	
def showCustomProperty(serverId):
	global arrayLen, NameList, ValList, propList
	propList = []
	NameList = []
	ValList = []
	webContainerId = AdminConfig.list('WebContainer', serverId)
	#print webContainerId
	propList = AdminConfig.list('Property', webContainerId)
	#print propList
	for prop in getListArray(propList):
		NameVar = AdminConfig.showAttribute(prop, "name")
		ValVar = AdminConfig.showAttribute(prop, "value")
		NameList.append(NameVar)
		ValList.append(ValVar)
	arrayLen = len(NameList)
	#print NameList
	print "\n\t\t\t List of WebContainer Custom Properties:"
	for i in range(0, arrayLen):
		optionNum = i + 1
		print "\t\t\t %s. Name: %s \t Value: %s"   % (str(optionNum),NameList[i],ValList[i])
	

def selectCustomProperty():
	showCustomProperty(serverId)
	choice = raw_input("\n\t\t\t Please Enter your choice: ")
	global CustPropNameVar, CustPropValVar, SelectedPropList
	if is_digit(choice) == 0:
		if int(choice) <= arrayLen :
			choice = int(choice) - 1
			CustPropNameVar = NameList[choice]
			CustPropValVar = ValList[choice]
			SelectedPropList = getListArray(propList)[choice]
		if int(choice) > arrayLen :
			print raw_input("\n\t\tPlease stick with the options in the list..")
			selectCustomProperty()
	else:
		print raw_input("\n\t\tPlease stick with the options in the list..")
		#clearscreen()
		selectCustomProperty()
	
def whichApp():
	siteID = raw_input("\n\t\tPlease Enter the Site ID: ")
	#if is_digit(siteID) != 0 :
	#	print "\n\t\t Invalid site ID!!! Please try again..."
	#	whichApp()
	#else:
	#	searchApp(siteID)
	searchApp(siteID)

def searchApp(siteID):
	global appName
	app = []
	plist = "[-serverType APPLICATION_SERVER]"
	aList = AdminTask.listServers(plist)
	for a in getListArray(aList):
		aName = AdminConfig.showAttribute(a, "name")
		if re.search("^"+siteID, aName):
			app.append(aName)
	aLen = len(app)
	if aLen == 0:
		print "\n\t\t Site ID does not exist!!!"
		x = raw_input("\n\t\t Press Enter to Continue...")
		whichApp()
	else:
		flag = 1
		while (flag != 0):
			#clearscreen()
			print "\n\t\t AppServers Found: \n"
			for i in range(0, aLen):
				optionNum = i + 1
				print "\t\t " + str(optionNum) + " > " + app[i] 
			choice = raw_input("\n\t\t * Please select your option : ")
			if is_digit(choice) == 0:
				if int(choice) <= aLen :
					choice = int(choice) - 1			
					appName = app[choice]
					getServerId(appName)
					getWebContainerId(serverId)
					getPropertyList(webContainerId)
					if (len(PropertyList)) == 0:
						choice1 = raw_input("\n\t\t You have selected '"+appName+"' application which does not contain any custom Property. Please press ENTER to Add a custom Property: ")
						if (choice1 == ""):
							addWCCustomProperty(appName)
							break
						else:
							print raw_input("\n\t\t Please stick with the options in the list..")
							flag = 1
							
					else:	
						choice1 = raw_input("\n\t\t You have selected '"+appName+"' application. Please select to (A)dd (M)odify (D)elete custom Property: ")
						if is_digit(choice1) != 0:
							if ((choice1 == "A") | (choice1 == "a")):
								choice = raw_input("\n\t\t You have selected to Add New Custom Property. Press Enter to proceed..")
								addWCCustomProperty(appName)
								break
							if ((choice1 == "M") | (choice1 == "m")):
								choice = raw_input("\n\t\t You have selected to Modify Existing Custom Property. Press Enter to proceed..")
								flag = ""
								while (flag != 0):								
									updateWCCustomProperty(appName)
									askQuestionLoopYN("\n\t\t Update another one? [Y|N]: ")
									if (REPLY == "Y"):
										flag = 1
									elif (REPLY == "N"):
										flag = 0
										sync_node()
										quit()
							if ((choice1 == "D") | (choice1 == "d")):
								choice = raw_input("\n\t\t You have selected to Delete Existing Custom Property. Press Enter to proceed..")
								flag = ""
								while (flag != 0):
									removeWCCustomProperty()
									if (int(NewArrayLen) != 0):
										askQuestionLoopYN("\n\t\t Delete another one? [Y|N]: ")
										if (REPLY == "Y"):
											flag = 1
										elif (REPLY == "N"):
											flag = 0
											sync_node()
											quit()
									else:
										x = raw_input("\n\t\t No More Custom Properties Left... Press Enter to Continue..")
										sync_node()
										quit()
										#break
							else:
								print raw_input("\n\t\t Please stick with the options in the list..")
								flag = 1
						else:
							print raw_input("\n\t\t Please stick with the options in the list..")
							flag = 1
#						break
				else:
					print raw_input("\n\t\t Please stick with the options in the list..")
					flag = 1


				
#main
initCommonCfg()
#clearscreen()
whichApp()
sync_node()
quit()