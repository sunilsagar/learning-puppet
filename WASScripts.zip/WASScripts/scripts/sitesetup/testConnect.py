#######################################################################################
# Script:      Jython script to be used to TEST DataSource Connectivity at cell level #
# Name:        testConnect.py                                                         #
# Description: Any new tasks related to datasource testing should be added here       #
# Author:      KO WebTeam - Reggie de Veas                                            #
#######################################################################################

##########Testing Database Connection################
JDBCPName = "Oracle JDBC Driver 6"
#print JDBCPName
if (JDBCPName == ""):
	JDBCPName = raw_input("\n\t\t Please Enter the JDBC Provider Name: ")
datasource = raw_input("\n\t\t Which DataSource do you want to TEST? ")
cell = AdminControl.getCell()
dsid = AdminConfig.getid('/Cell:'+ cell +'/JDBCProvider:'+ JDBCPName +'/DataSource:'+ datasource +'/')

print "\n\t\t Testing Database Connection"

print "\t\t "+ AdminControl.testConnection(dsid)

print "\t\t ----------------------------------------------------------------------------------------- "
x = raw_input("\n\t\t Press Enter to Continue...")
########################################################