import java.util as util 
import java.io as javaio 
import java.util.HashSet as HashSet
import java.util.HashMap as HashMap
import java.util.TreeMap as TreeMap
import java.util.TreeSet as TreeSet
import java.lang.Integer as Integer
import java.lang.Comparable as Comparable
from time import sleep
import sys, java
from sys import argv
import os

def getConnectString():
        properties = util.Properties()
        propertiesfis =javaio.FileInputStream("JDBC.connectstring")
        properties.load(propertiesfis)
        result= {}
        for entry in properties.entrySet():
            result[entry.key] = entry.value
	    #print '%s = %s' % (entry.key.strip(), entry.value.strip())
	#print len(properties)
        #print properties["KOUSP"]

getConnectString()
