import time
import string
from time import sleep
import sys, java
from sys import argv
import os

lineSeparator = java.lang.System.getProperty('line.separator')

def clearscreen():
     print  "\n"*500
    
def quit():
    sys.exit()

def choice_N():
	choice1 = ""
	while (choice1 != "Y|N"):
		choice1 = raw_input("\n\t\tYou have chosen to abort.. Please press Y to start from the beginning, or press N to exit.. : ")
		choice1 = string.upper(choice1)
		if (choice1 == "Y"):
			clearscreen()
			createJDBC()
		elif (choice1 == "N"):
			quit()	
			
def sync_node():
	choice = ""
	while (choice != "Y|N"):	
		choice = raw_input("\n\t\t Synchronize changes with the Nodes? [Y|N]: ")
		choice = string.upper(choice)
		if (choice == "Y"):	
			## Full Syncronization ##
			print "\n\t\t Synchronizing configuration with Master Repository "
			nodelist = AdminTask.listManagedNodes().split(lineSeparator)
			for nodename in nodelist :
				print "\t\t Doing Full Resynchronization of node "+ nodename
				####################Identifying the ConfigRepository MBean and assign it to variable######################
				repo = AdminControl.completeObjectName('type=ConfigRepository,process=nodeagent,node='+ nodename +',*')
				AdminControl.invoke(repo, 'refreshRepositoryEpoch')
				sync = AdminControl.completeObjectName('cell='+ cell +',node='+ nodename +',type=NodeSync,*')
				AdminControl.invoke(sync , 'sync')
				time.sleep(3)
			print "\t\t ----------------------------------------------------------------------------------------- "
			print "\t\t Full Resynchronization completed "
			print "\t\t ----------------------------------------------------------------------------------------- "
			x = raw_input("\n\t\t Press Enter to Continue...")
			break
		elif (choice == "N"):
			choice_N()			
			
def createJDBC():
	global cell
	#name = "jdbcOracle"+ env
	name = raw_input("\n\t\t 1.) Enter the JDBC Provider Name to create: ")
	print "\n\t\t Name of JDBC Provider which will be created ---> " + name
	#print " ----------------------------------------------------------------------------------------- "
	# Get the name of cell
	cell = AdminControl.getCell()
	cellid = AdminConfig.getid('/Cell:'+ cell +'/')
	#print " ----------------------------------------------------------------------------------------- "
	Serverid = AdminConfig.getid('/Cell:'+ cell)
	
	## Checking for the existence of JDBC Provider 
	print "\n\t\t Checking for the existence of JDBC Provider :"+ name
	J2 = AdminConfig.getid('/Cell:'+ cell +'/JDBCProvider:'+ name)
	print "\n\t\t*******************************************************************************************************"
	if len(J2) > 0:
		print "\n\t\t JDBC Provider exists with name :"+ name +" !!!"
		print "\t\t Please select a different name..."
		x = raw_input("\n\t\t Press Enter to Continue...")
		clearscreen()
		createJDBC()
	else:
		print "\n\t\t JDBC Provider name Does not exist. Continuing with creation.."
		choice = ""
		while (choice != "Y|N"):
			print "\n\t\t*******************************************************************************************************"
			print "\n\t\t JDBC Provider details\n"
			print "\n\t\t Name		: " +  name		
			print "\t\t JDBC Driver	: " +  jdbc_driver
			choice = raw_input("\n\t\t Create the JDBC Provider based on above information? [Y|N]: "	)
			choice = string.upper(choice)
			if (choice == "Y"):	
				## Creating New JDBC Provider ##
				print "\n\t\t Creating New JDBC Provider :"+ name
				n1 = ["name" , name ]
				desc = ["description" , "Oracle JDBC Driver"]
				impn = ["implementationClassName" , "oracle.jdbc.pool.OracleConnectionPoolDataSource"]
				classpath = ["classpath" , jdbc_driver ]
				attrs1 = [n1 , impn , desc , classpath]
				jdbc = AdminConfig.create('JDBCProvider' , Serverid , attrs1)
				#print " New JDBC Provider created :"+ name
				AdminConfig.save()
				print "\n\t\t Saving Configuration "
				print "\t\t----------------------------------------------------------------------------------------- "
				break
			elif (choice == "N"):
				choice_N()	
			
#Main
jdbc_driver = "/usr/lib/oracle/11.2/client64/lib/ojdbc6.jar"
global jdbc_driver
clearscreen()
createJDBC()
sync_node()
