#!/bin/sh
WAS_HOME=/data02/ibm/websphere/appserver/7.0-64/profiles/dmgr
scriptsDir=/data02/ibm/websphere/scripts/sitesetup/DS
LOGO="WebSphere Misc Operations"

createJDBC() {
$WAS_HOME/bin/wsadmin.sh -lang jython -f ${scriptsDir}/createJDBC.py
}

createDS() {
$WAS_HOME/bin/wsadmin.sh -lang jython -f ${scriptsDir}/createDS.py ${scriptsDir}
}

createJ2C() {
$WAS_HOME/bin/wsadmin.sh -lang jython -f ${scriptsDir}/createJ2C.py
}

testConnect() {
$WAS_HOME/bin/wsadmin.sh -lang jython -f ${scriptsDir}/testConnect.py
}

badchoice () { echo -e "\n\t\t\tInvalid Selection ... Please Try Again. Press any key to continue.." ; read junk; } 

menu() {
clear
answer=
echo `date`
echo
echo -e "\t\t\t" $LOGO
echo
echo -e "\t\tPlease Select:"
echo
echo -e "\t\t\t 1.  Create JDBC Provider"
echo -e "\t\t\t 2.  Create J2C Authentication"
echo -e "\t\t\t 3.  Create DataSource"
echo -e "\t\t\t 4.  Test DataSource Connectivity"
echo
echo -e "\t\t\t x.  Exit"
echo
echo -e "\t\t\t Select by pressing the option number and then ENTER: \c" 
read answer

case $answer in
1) createJDBC; menu;;
2) createJ2C; menu;;
3) createDS; menu;;
4) testConnect; menu;;
x|X) break;;
*) badchoice; menu;; 
esac
}


#main
menu


