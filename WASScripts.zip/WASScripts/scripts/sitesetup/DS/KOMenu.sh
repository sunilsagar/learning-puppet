#!/bin/sh
WAS_HOME=/data02/ibm/websphere/appserver/7.0/profiles/dmgr
scriptsDir=/data01/home/wasadmin/scripts/DS
LOGO="KO Operations Menu"

badchoice () { echo -e "\n\t\t\tInvalid Selection ... Please Try Again. Press any key to continue.." ; read junk; } 

menu() {
clear
answer=
echo `date`
echo
echo -e "\t\t\t" $LOGO
echo
echo -e "\t\tPlease Select:"
echo
echo -e "\t\t\t 1.  Create AppServer"
echo -e "\t\t\t 2.  Execute 2nd script for Appserver creation"
echo -e "\t\t\t 3.  DataSource Creation Menu"
#echo -e "\t\t\t 4.  Test DataSource Connectivity"
echo
echo -e "\t\t\t x.  Exit"
echo
echo -e "\t\t\t Select by pressing the option number and then ENTER: \c" 
read answer

case $answer in
1) ${scriptsDir}/sitesetup.sh; menu;;
2) ${scriptsDir}/sitesetup2.sh; menu;;
3) ${scriptsDir}/WAS7-DB.sh; menu;;
#4) testConnect; menu;;
x|X) break;;
*) badchoice; menu;; 
esac
}

#main
menu


