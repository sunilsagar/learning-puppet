##########Testing Database Connection################
datasource = raw_input("\n\t\tWhich DataSource do you want to TEST? ")
cell = AdminControl.getCell()
dsid = AdminConfig.getid('/Cell:'+ cell +'/JDBCProvider:"Oracle JDBC Driver 6"/DataSource:'+ datasource +'/')

print " Testing Database Connection"

print AdminControl.testConnection(dsid)

print " ----------------------------------------------------------------------------------------- "
x = raw_input("\nPress Enter to Continue...")
########################################################