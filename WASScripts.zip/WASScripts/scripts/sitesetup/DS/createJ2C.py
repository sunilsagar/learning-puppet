import time
import string
from time import sleep
import sys, java
from sys import argv
import os

lineSeparator = java.lang.System.getProperty('line.separator')

def clearscreen():
     print  "\n"*500
    
def quit():
    sys.exit()

def choice_N():
	choice1 = ""
	while (choice1 != "Y|N"):
		choice1 = raw_input("\n\t\tYou have chosen to abort.. Please press Y to start from the beginning, or press N to exit.. : ")
		choice1 = string.upper(choice1)
		if (choice1 == "Y"):
			clearscreen()
			createJ2C()
		elif (choice1 == "N"):
			quit()		

def sync_node():
	choice = ""
	while (choice != "Y|N"):	
		choice = raw_input("\n\t\t Synchronize changes with the Nodes? [Y|N]: ")
		choice = string.upper(choice)
		if (choice == "Y"):	
			## Full Syncronization ##
			print "\n\t\t Synchronizing configuration with Master Repository "
			nodelist = AdminTask.listManagedNodes().split(lineSeparator)
			for nodename in nodelist :
				print "\t\t Doing Full Resynchronization of node "+ nodename
				####################Identifying the ConfigRepository MBean and assign it to variable######################
				repo = AdminControl.completeObjectName('type=ConfigRepository,process=nodeagent,node='+ nodename +',*')
				AdminControl.invoke(repo, 'refreshRepositoryEpoch')
				sync = AdminControl.completeObjectName('cell='+ cell +',node='+ nodename +',type=NodeSync,*')
				AdminControl.invoke(sync , 'sync')
				time.sleep(3)
			print "\t\t ----------------------------------------------------------------------------------------- "
			print "\t\t Full Resynchronization completed "
			print "\t\t ----------------------------------------------------------------------------------------- "
			x = raw_input("\n\t\t Press Enter to Continue...")
			break
		elif (choice == "N"):
			choice_N()
						
def createJ2C():
	global cell
	matchFound = ""
	while (matchFound != 0):
		matchFound = 0
		appName = raw_input("\n\t\t1.) J2C Name to Create (usually same as the appName) : ")
		dNode = AdminControl.getNode()
		appAlias = dNode + "/" + appName
		## checking for the existence of JAASAuthData ## 
		jaasAuthDataList = AdminConfig.list("JAASAuthData") 
		jaasAuthDataList=jaasAuthDataList.split(lineSeparator)
		for jaasAuthId in jaasAuthDataList:
			getAlias = AdminConfig.showAttribute(jaasAuthId, "alias")
			if (cmp(getAlias,appAlias) == 0):
				matchFound = matchFound + 1
		if (matchFound != 0):
			print "\n\t\tJ2C AuthAlias with name :"+ appAlias +" exist!!! Please select another name..."
		else:
			print "\n\t\tName does not exist. Continuing with setup..."
	print "\n\t\t\t*** Please provide DB Credentials ***"
	userName = raw_input("\n\t\t2.) UserName : ")
	passWord = raw_input("\n\t\t3.) PassWord : ")

	cell = AdminControl.getCell()
	sec = AdminConfig.getid("/Cell:" + cell + "/Security:/")
	aliasAttr = ["alias", appAlias]
	descAttr = ["description", "authentication information when component-managed"]
	useridAttr = ["userId", userName]
	passwordAttr = ["password", passWord]
	attrs = []
	attrs.append(aliasAttr)
	attrs.append(descAttr)
	attrs.append(useridAttr)
	attrs.append(passwordAttr)
	choice = ""
	while (choice != "Y|N"):
		print "\n\t\t*******************************************************************************************************"
		print "\n\t\t JAAS Auth details\n"
		print "\n\t\t Name		: " +  appAlias		
		print "\t\t UserName	: " +  userName
		print "\t\t PassWord 	: " +  passWord
		choice = raw_input("\n\t\t Create the J2C Auth based on above information? [Y|N]: "	)
		choice = string.upper(choice)
		if (choice == "Y"):
			appauthdata = AdminConfig.create("JAASAuthData", sec, attrs)
			print "\n\t\tCreated new JASSAuthData with Alias name :"+ appAlias
			#AdminTask.createAuthDataEntry('[-alias 123456 -user test -password ******** -description  ]')
			AdminConfig.save()
			print "\n\t\tSaving Configuraion "
			#x = raw_input("\n\t\t Press Enter to Continue...")
			break
		elif (choice == "N"):
			choice_N()	
			

#Main
clearscreen()
createJ2C()
sync_node()
quit()