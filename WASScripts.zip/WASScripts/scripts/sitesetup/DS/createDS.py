import java.util as util 
import java.io as javaio 
import java.util.HashSet as HashSet
import java.util.HashMap as HashMap
import java.util.TreeMap as TreeMap
import java.util.TreeSet as TreeSet
import java.lang.Integer as Integer
import java.lang.Comparable as Comparable
import time
import string
from time import sleep
import sys, java
from sys import argv
import os

lineSeparator = java.lang.System.getProperty('line.separator')
outlist=[]

# Declare global variables

global AdminConfig, AdminControl, selectedJDBCP, JDBCPName, properties, connectString, url, appName

def clearscreen():
     print  "\n"*500
     

def quit():
    sys.exit()

def convertToList(inlist):
     outlist=[]
     if (len(inlist)>0 and inlist[0]=='[' and inlist[len(inlist)-1]==']'):
        inlist = inlist[1:len(inlist)-1]
        clist = inlist.split("\"")
     else:
        clist = inlist.split("\n")
     for elem in clist:
        elem=elem.rstrip();
        if (len(elem)>0):
           outlist.append(elem)
     return outlist

def convertToList2(inlist):
     outlist=[]
     if (len(inlist)>0 and inlist[0]=='[' and inlist[len(inlist)-1]==']'):
        inlist = inlist[1:len(inlist)-1]
        clist = inlist.split(" ")
     else:
        clist = inlist.split("\n")
     for elem in clist:
        elem=elem.rstrip();
        if (len(elem)>0):
           outlist.append(elem)
     return outlist
	 
def _splitlist(s):
    if s[0] != '[' or s[-1] != ']':
        raise "Invalid string: %s" % s
    return s[1:-1].split(' ')

def _splitlines(s):
  rv = [s]
  if '\r' in s:
    rv = s.split('\r\n')
  elif '\n' in s:
    rv = s.split('\n')
  if rv[-1] == '':
    rv = rv[:-1]
  return rv	

def is_digit(s):
    try:
        float(s)
        return 0
    except ValueError:
        return 1

def choice_N():
	choice1 = ""
	while (choice1 != "Y|N"):
		choice1 = raw_input("\n\t\tYou have chosen to abort.. Please press Y to start from the beginning, or press N to exit.")
		choice1 = string.upper(choice1)
		if (choice1 == "Y"):
			x = raw_input("\nPress Enter to Continue...")
			clearscreen()
			appName = raw_input("\t\t1.) Enter the DataSource Name: ")
			getJDBCProvider()  
			getConnectString()
			createDS()
		elif (choice1 == "N"):
			quit()		
		
def sync_node():
	choice = ""
	while (choice != "Y|N"):	
		choice = raw_input("\n\t\t Synchronize changes with the Nodes? [Y|N]: ")
		choice = string.upper(choice)
		if (choice == "Y"):	
			## Full Syncronization ##
			print "\n\t\t Synchronizing configuration with Master Repository "
			nodelist = AdminTask.listManagedNodes().split(lineSeparator)
			for nodename in nodelist :
				print "\t\t Doing Full Resynchronization of node "+ nodename
				####################Identifying the ConfigRepository MBean and assign it to variable######################
				repo = AdminControl.completeObjectName('type=ConfigRepository,process=nodeagent,node='+ nodename +',*')
				AdminControl.invoke(repo, 'refreshRepositoryEpoch')
				sync = AdminControl.completeObjectName('cell='+ cell +',node='+ nodename +',type=NodeSync,*')
				AdminControl.invoke(sync , 'sync')
				time.sleep(3)
			print "\t\t ----------------------------------------------------------------------------------------- "
			print "\t\tFull Resynchronization completed "
			print "\t\t ----------------------------------------------------------------------------------------- "
			x = raw_input("\n\t\tPress Enter to Continue...")
			break
		elif (choice == "N"):
			choice_N()
			
def getJDBCProvider():
	import sys, java, re
	global JDBCPName
	OraJDBC = []
	PClassPath = []
	JDBCArray = {}
	#Get JDBC Provider List
	JDBCPList = convertToList(AdminConfig.list("JDBCProvider"))
	for JDBCP in JDBCPList:
		pName = AdminConfig.showAttribute(JDBCP, 'name')
		providerClasspath = AdminConfig.showAttribute(JDBCP, "classpath")
		if re.search("^[Oo]racle", pName):
			OraJDBC.append(pName)
			PClassPath.append(providerClasspath)
			JDBCArray[pName] = JDBCP
	print "\n\t\t\t List of JDBC Providers:"
	arrayLen = len(OraJDBC)
	for i in range(0, arrayLen):
		optionNum = i + 1
		print "\t\t\t" + str(optionNum) + " > " + OraJDBC[i] + "\t(" + PClassPath[i] + ")"
	choice = raw_input("\n\t\t2.) Please select the JDBC Provider You want to use ? ")
	if is_digit(choice) == 0:
		if int(choice) <= arrayLen :
			choice = int(choice) - 1
			JDBCPName = OraJDBC[choice]
			selectedJDBCP = JDBCArray[OraJDBC[choice]]
			#print selectedJDBCP
		if int(choice) > arrayLen :
			print raw_input("\n\t\tPlease stick with the options in the list..")
			clearscreen()
			getJDBCProvider()
	else:
		print raw_input("\n\t\tPlease stick with the options in the list..")
		clearscreen()
		getJDBCProvider()

def getConnectString():
	global url, connectString
	properties = util.Properties()
	propertiesfis = javaio.FileInputStream(scriptDir+"/JDBC.connectstring")
	properties.load(propertiesfis)
	result= {}
	for entry in properties.entrySet():
		result[entry.key] = entry.value
		#print '%s = %s' % (entry.key.strip(), entry.value.strip())
	#print len(properties)
	#print properties["KOUSP"]
	connectString = raw_input("\n\t\t3.) Database (e.g. KONAT, KONAP..) : ")
	connectString = string.upper(connectString)
	if (properties[connectString] == None):
		print "\n\t\tInvalid DB Name!!! Please try again.."
		getConnectString()
	else:
		url = properties[connectString]
	#print urls

	
def createDS():
	global appName, cell
	datasource = appName
	cell = AdminControl.getCell()
	dNode = AdminControl.getNode()
	ds = AdminConfig.getid('/Cell:'+ cell +'/JDBCProvider:'+ JDBCPName)
	name1 = ["name" , datasource]
	desc = ["description", "New JDBC Datasource"]
	matchFound = "" 
	while (matchFound != 0):
		matchFound = 0
		jndiName = raw_input("\n\t\t4.) Enter the JNDI Name: e.g jdbc/mydb ")
		dsList = AdminTask.listDatasources()
		dsList = dsList.split(lineSeparator)
		for dsName in dsList:
			getJNDI = AdminConfig.showAttribute(dsName, "jndiName")
			if (cmp(getJNDI,jndiName) == 0):
				matchFound = matchFound + 1
		if (matchFound != 0):		
			print "\n\t\tJNDI Alias with name :"+ jndiName +" exist!!! Please try another name..."
		else:
			print "\n\t\tName does not exist. Continuing with setup..."
				
	matchFound = 0 
	while (matchFound == 0):
		J2CAlias = raw_input("\n\t\t5.) Enter the the J2C Auth Alias : ")
		J2CFull = dNode + "/" + J2CAlias
		## checking for the existence of JAASAuthData ## 
		jaasAuthDataList = AdminConfig.list("JAASAuthData") 
		jaasAuthDataList=jaasAuthDataList.split(lineSeparator)
		for jaasAuthId in jaasAuthDataList:
			getAlias = AdminConfig.showAttribute(jaasAuthId, "alias")
			#print getAlias
			#print J2CFull
			if (cmp(getAlias,J2CFull) == 0):
				print "\n\t\tJ2C AuthAlias with name :"+ J2CAlias +" exist."
				matchFound = matchFound + 1
				#print matchFound
		if (matchFound == 0):
			print "\n\t\tJ2C AuthAlias with name :"+ J2CAlias +" does not exist!!! Please select another name..."
			#x = raw_input("\n\t\tPress Enter to Continue...")
			#sys.exit()
	#print "\n\t\t Name of datasource which will be created on JDBC Provider :"+ JDBCPName +" is :"+ datasource	
	jndiNameAttr = ["jndiName", jndiName]
	authentication = ["authDataAlias" , J2CFull]
	st_cachesize = ["statementCacheSize" , "150"]
	ds_hlpclass = ["datasourceHelperClassname" , "com.ibm.websphere.rsadapter.Oracle11gDataStoreHelper"]
	#map_configalias_attr=["mappingConfigAlias", "none"]
	#map_attrs=[authentication , map_configalias_attr]
	map_attrs=[authentication]
	mapping_attr=["mapping", map_attrs]
	ds_attr = [name1 , desc , jndiNameAttr , authentication , st_cachesize , ds_hlpclass , mapping_attr]
	choice = ""
	while (choice != "Y|N"):
		print "\n\t\t*******************************************************************************************************"
		print "\n\t\t DataSource details\n"
		print "\n\t\t JDBC Provider  	: " +  JDBCPName		
		print "\t\t DataSource Name	: " +  datasource
		print "\t\t JNDI Name	     	: " +  jndiName
		print "\t\t J2C Auth Alias 	: " +  J2CFull
		print "\t\t Database URL   	: " +  connectString
		choice = raw_input("\n\t\t Create the DataSource based on above information? [Y|N]: "	)
		choice = string.upper(choice)
		if (choice == "Y"):
			newds = AdminConfig.create('DataSource' , ds , ds_attr)
			print "\n\t\t New DataSource created with name :"+ datasource
			AdminConfig.save()
			print "\t\t Saving Configuration "
			print "\t\t ----------------------------------------------------------------------------------------- "
			## set the properties for the datasource ##
			print "\t\t Setting the properties for DataSource :"+ datasource
			newds1 = AdminConfig.getid('/Cell:'+ cell +'/JDBCProvider:'+ JDBCPName +'/DataSource:'+ datasource)
			propSet = AdminConfig.create('J2EEResourcePropertySet' , newds1 , [])
			name3 = ["name" , "URL"]
			type = ["type" , "java.lang.String"]
			required = ["required" , "true"]
			value = ["value" , url]
			rpAttrs = [name3 , type , required , value]
			jrp = AdminConfig.create('J2EEResourceProperty' , propSet , rpAttrs)
			print "\t\t Properties created for DataSource :"+ datasource
			AdminConfig.save()
			print "\t\t Saving Configuration "
			print "\t\t ----------------------------------------------------------------------------------------- "
	
			#Create an associated connection pool for the new DataSource#
			print "\t\t Creating Connection Pool Setting for DataSource :"+ datasource
			timeout = ["connectionTimeout" , "180"]
			maxconn = ["maxConnections" , "10"]
			minconn = ["minConnections" , "1"]
			reaptime = ["reapTime" , "180"]
			unusedtimeout = ["unusedTimeout" , "1800"]
			agedtimeout = ["agedTimeout" , "0"]
			purgepolicy = ["purgePolicy" , "EntirePool"]
			connPoolAttrs = [timeout , maxconn , minconn , reaptime , unusedtimeout , agedtimeout , purgepolicy]
			AdminConfig.create("ConnectionPool", newds , connPoolAttrs)
			print "\t\t Connection Pool Setting created for DataSource :"+ datasource
			AdminConfig.save()
			print "\t\t Saving Configuraion "
			print "\t\t ----------------------------------------------------------------------------------------- "
			#x = raw_input("\n\t\t Press Enter to Continue...")
			break
		elif (choice == "N"):
			choice_N()
	
#Main	
global scriptDir
scriptDir = sys.argv[0]
clearscreen()
appName = raw_input("\t\t1.) Enter the DataSource Name: ")
getJDBCProvider()  
getConnectString()
createDS()
sync_node()
quit()

