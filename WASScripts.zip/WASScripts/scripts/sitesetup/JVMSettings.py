 ###################################################################################### 
# Script:      Jython script to be used to Set JVM Settings					          #
# Name:        JVMSettings.py		                                                  #
# Description: Any new tasks related to adding JVM Settings				       		  #	
#				should be added here 												  #
# Author:      KO WebTeam - Reggie de Veas                                            #
#######################################################################################

import java.util as util 
import java.io as javaio 
import sys, getopt, re;
import time
import string

global lineSeparator
lineSeparator = java.lang.System.getProperty('line.separator')

def initCommonCfg():
	cellNameVar	= AdminControl.getCell()

def clearscreen():
     print  "\n"*500
     
def quit():
    sys.exit()

def try_cmd(cmdvar):
	#print cmdvar
	buff = ""
	try:
		excp = 0
		cmdval = cmdvar
		#excp = 0 #reset (in case of nested exceptions)
	except:
		excp = 1
	if (excp == 0):
		return buff
		print "return buff"
	else:
		return cmdval
		return "cmdval"

def getListArray(l):
    return l.splitlines()	

def getServerName(s):
    return AdminConfig.showAttribute(s, 'name')

def getServerId(a):
	global serverId
	serverId = AdminConfig.getid('/Server:' + a + '/')
	#return serverId

def getNode(s):
	global nodeName
	try:
		objNameString = AdminControl.completeObjectName('WebSphere:type=Server,process='+s+',*')
		AdminControl.getAttribute(objNameString, 'nodeName')
	except:
		#print "Server %s is not running" % appServerName
		nodeName = 'NULL'
		return nodeName
	else:
		objNameString = AdminControl.completeObjectName('WebSphere:type=Server,process='+s+',*')
		nodeName = AdminControl.getAttribute(objNameString, 'nodeName')
		return nodeName

		
def getJVMId(s):
	global JVMId
	JVMId = AdminConfig.list('JavaVirtualMachine', s)	
	#return JVMId
	
def getPropertyList(w):
	global PropertyList
	PropertyList = AdminConfig.list('Property', w)
	#return PropertyList
	
def is_digit(s):
    try:
        float(s)
        return 0
    except ValueError:
        return 1

def showMenu():
	#clearscreen()
	optionNum = 4
	print "\n\t\t\t JVM Settings Menu:\n"
	print "\t\t\t 1. Set HeapSize "
	print "\t\t\t 2. Generic JVM Arguments "
	print "\t\t\t 3. JVM Custom Properties "
	print "\n\t\t\t 4. Exit "
	choice = raw_input("\n\t\t\t Select by pressing the option number and then ENTER: ")
	#print choice, optionNum
	if is_digit(choice) == 0:
		if int(choice) > optionNum:
			print raw_input("\n\t\t\t Please stick with the options in the list..")
			showMenu()
		elif int(choice) == 1:
			setHeap()
		elif int(choice) == 2:
			setJVMArg()
		elif int(choice) == 3:
			setCustProperty()
		elif int(choice) == 4:
			quit()
	else:
		print raw_input("\n\t\t Please stick with the options in the list..")
		showMenu()			
		
def setHeap():
	#clearscreen()
	print "\n\t\t\t Min|Max Heap Settings.."
	whichApp()
	print "\n\t\t\t Modifying Heap for %s.. \n" % appServerName
	getServerId(appServerName)
	getJVMId(serverId)
	initialHeap = AdminConfig.showAttribute(JVMId, "initialHeapSize")
	maxHeap = AdminConfig.showAttribute(JVMId, "maximumHeapSize")
	flag_out = ""
	while (flag_out != 0):
		flag = ""
		while (flag != 0):
			newMinHeap = raw_input("\t\t Min Heap ["+initialHeap+"] : ")
			if newMinHeap == "":
				newMinHeap = initialHeap
				break
			else:
				if is_digit(newMinHeap) != 0:
					print "\n\t\t\t Invalid Input!!"
					flag = 1
				else:
					flag = 0
			#print newMinHeap			
		flag = ""	
		while (flag != 0):	
			newMaxHeap = raw_input("\t\t Max Heap ["+maxHeap+"] : ")
			if newMaxHeap == "":
				newMaxHeap = maxHeap
				break
			else:
				if is_digit(newMaxHeap) != 0:
					print "\n\t\t\t Invalid Input!!"
					flag = 1
				else:
					flag = 0
		if (int(newMinHeap) <= int(newMaxHeap)):
			setMin = ["initialHeapSize", newMinHeap]
			setMax = ["maximumHeapSize", newMaxHeap]
			attrib = [setMin, setMax]
			print "\n\t\t\t Setting min=%s max=%s Heap for server %s" % (newMinHeap, newMaxHeap, appServerName)
			askQuestionLoopYN("\n\t\t Proceed with the changes? [Y|N]: ")
			if (REPLY == "N"):
				x = raw_input("\n\t\t\t Aborting...Press Enter to continue..")
				setHeap()
			elif (REPLY == "Y"):
				AdminConfig.modify(JVMId, attrib)
				AdminConfig.save()
				sync_node()
				showMenu()
				break
		else:
			x = raw_input("\n\t\t\t Invalid Input.. "+newMinHeap+" is larger than "+newMaxHeap+". Please try again..")
			flag_out = 1

def setJVMArg():
	print "\n\t\t Generic JVM Argument Settings.."
	whichApp()
	print "\n\t\t Setting Generic JVM Argument for %s.. \n" % appServerName
	getServerId(appServerName)
	getJVMId(serverId)
	arg1 = 'genericJvmArguments'
	arg2 = AdminConfig.showAttribute(JVMId, arg1)
	if not arg2:
		arg2 = ""
		print "\n\t\t Old generic JVM args = <Null>" 
		print "\t\t Setting new JVM args..."
		arg3 = raw_input("\n\t\t JVM args to Add: ")
		addJVMARg(arg1,arg2,arg3)
	else:
		flag = ""
		while flag != 0:
			print "\n\t\t Old generic JVM args: %s" %arg2
			choice = raw_input("\n\t\t What modification do you want to do? [A]dd, [M]odify or [D]elete? : ")
			if is_digit(choice) != 0:
					if ((choice == "A") | (choice == "a")):
						choice = raw_input("\n\t\t You have selected to ADD New JVM Argument. Press Enter to proceed..")
						arg3 = raw_input("\n\t\t JVM args to Add: ")
						addJVMARg(arg1,arg2,arg3)
					if ((choice == "M") | (choice == "m")):
						choice = raw_input("\n\t\t You have selected to MODIFY JVM Argument. Press Enter to proceed..")
						arg3 = arg2.split()
						arrayLen = len(arg3)
						action = 'Modify'
						modifyJVMarg(action,arg1,arg3,arrayLen)
					if ((choice == "D") | (choice == "d")):
						choice = raw_input("\n\t\t You have selected to DELETE JVM Argument. Press Enter to proceed..")
						arg3 = arg2.split()
						arrayLen = len(arg3)
						action = 'Delete'
						delJVMarg(action,arg1,arg3,arrayLen)
					else:
						x = raw_input("\n\t\t Please stick with the options in the list..")
						flag = 1
			else:
				x = raw_input("\n\t\t Please stick with the options in the list..")
				flag = 1
		
		
def addJVMARg(a1,a2,a3):		
	#arg3 = raw_input("\n\t\t JVM args to Add: ")
	a2 = a2 + " " + a3
	a2 = a2.strip()
	print "\n\t\t New generic JVM args = %s" % a2	
	askQuestionLoopYN("\n\t\t Proceed with the changes? [Y|N]: ")
	if (REPLY == "N"):
		x = raw_input("\n\t\t\t Aborting...Press Enter to continue...")
		setJVMArg()
	elif (REPLY == "Y"):
		AdminConfig.modify(JVMId, [[a1, a2]])
		AdminConfig.save()
		sync_node()
		showMenu()

def dispGenerigcArgs(action, a3, aL):
	global oldarg
	flag = ""
	while (flag != 0):
		print "\n\t\t\t List of Generic JVM Arguments: "
		for i in range(0, aL):
				optionNum = i + 1
				print "\t\t\t %s. %s"   % (str(optionNum),a3[i])
		choice = raw_input("\n\t\t\t Please select which Argument to "+action+" : ")
		if is_digit(choice) == 0:
				if int(choice) <= aL :
						choice = int(choice) - 1
						#oldarg = a3[choice]
						return choice
				else:
						x = raw_input("\n\t\t Please stick with the options in the list..")
						flag = 1
		else:
				x = raw_input("\n\t\t Please stick with the options in the list..")
				flag = 1


def modifyJVMarg(a, a1, a3, aL):
	index = dispGenerigcArgs(a, a3, aL)
	#print index
	oldArg = a3.pop(index)
	#print a3
	newArg = raw_input("\n\t\t New generic JVM args ["+oldArg+"]: ")
	if not newArg:
		newArg = oldArg
	#print newArg
	a3.insert(index, newArg)
	a3_new = ""
	#for x in a3:
	#	a3_new = a3_new + " " + x
	#a3_new = a3_new.strip()
	#a3_new = ' '.join(a3)
	a3 = ' '.join(a3)
	print "\n\t\t New generic JVM args = %s" %a3
	askQuestionLoopYN("\n\t\t Proceed with the changes? [Y|N]: ")
	if (REPLY == "N"):
		x = raw_input("\n\t\t\t Aborting...Press Enter to continue...")
		setJVMArg()
	elif (REPLY == "Y"):
		AdminConfig.modify(JVMId, [[a1, a3]])
		AdminConfig.save()
		sync_node()
		showMenu()

		
def delJVMarg(a, a1, a3, aL):
	index = dispGenerigcArgs(a, a3, aL)
	toremArg = a3[index]
	print "\n\t\t Argument to remove = %s" % toremArg
	a3.remove(toremArg)
	a3 = ' '.join(a3)
	print "\n\t\t New generic JVM args = %s" % a3
	askQuestionLoopYN("\n\t\t Proceed with the changes? [Y|N]: ")
	if (REPLY == "N"):
		x = raw_input("\n\t\t\t Aborting...Press Enter to continue...")
		setJVMArg()
	elif (REPLY == "Y"):
		AdminConfig.modify(JVMId, [[a1, a3]])
		AdminConfig.save()
		sync_node()
		showMenu()
	
			
			
def setCustProperty():
	#clearscreen()
	print "\n\t\t JVM Custom Property Settings.."
	whichApp()
	print "\n\t\t Setting Custom Property for %s.. \n" % appServerName
	getServerId(appServerName)
	getJVMId(serverId)
	getPropertyList(JVMId)
	flag = ""	
	while (flag != 0):
		if (len(PropertyList)) == 0:
			choice1 = raw_input("\n\t\t You have selected '"+appServerName+"' application which does not contain any custom Property. Please press ENTER to Add a custom Property: ")
			if (choice1 == ""):
				addJVMCustomProperty(appServerName)
				sync_node()
				break
			else:
				print raw_input("\n\t\t Please stick with the options in the list..")
				flag = 1
		else:	
			choice1 = raw_input("\n\t\t You have selected '"+appServerName+"' application. Please select to (A)dd (M)odify (D)elete custom Property: ")
			if is_digit(choice1) != 0:
				if ((choice1 == "A") | (choice1 == "a")):
					choice = raw_input("\n\t\t You have selected to Add New Custom Property. Press Enter to proceed..")
					addJVMCustomProperty(appServerName)
					sync_node()
					break
				elif ((choice1 == "M") | (choice1 == "m")):
					choice = raw_input("\n\t\t You have selected to Modify Existing Custom Property. Press Enter to proceed..")
					flag = ""
					while (flag != 0):
						updateJVMCustomProperty(appServerName)
						askQuestionLoopYN("\n\t\t Update another one? [Y|N]: ")
						if (REPLY == "Y"):
							flag = 1
						elif (REPLY == "N"):
							flag = 0
							sync_node()
							#showMenu()
				elif ((choice1 == "D") | (choice1 == "d")):
					choice = raw_input("\n\t\t You have selected to Delete Existing Custom Property. Press Enter to proceed..")
					flag = ""
					while (flag != 0):
						removeJVMCustomProperty()
						if (int(NewArrayLen) != 0):
							askQuestionLoopYN("\n\t\t Delete another one? [Y|N]: ")
							if (REPLY == "Y"):
								flag = 1
							elif (REPLY == "N"):
								flag = 0
								sync_node()
								#showMenu()
						else:
							x = raw_input("\n\t\t No More Custom Properties Left. Going back to Main Menu.. Press Enter to Continue..")
							sync_node()
							showMenu()
					#break
				else:
					print raw_input("\n\t\t Please stick with the options in the list..")
					flag = 1
			else:
				print raw_input("\n\t\t Please stick with the options in the list..")
				flag = 1
	showMenu()

def showCustomProperty(serverId):
	global arrayLen, NameList, ValList, propList
	propList = []
	NameList = []
	ValList = []
	getJVMId(serverId)
	#print JVMId
	propList = AdminConfig.list('Property', JVMId)
	#print propList
	for prop in getListArray(propList):
		NameVar = AdminConfig.showAttribute(prop, "name")
		ValVar = AdminConfig.showAttribute(prop, "value")
		NameList.append(NameVar)
		ValList.append(ValVar)
	arrayLen = len(NameList)
	#print NameList
	print "\n\t\t\t List of JVM Custom Properties:"
	for i in range(0, arrayLen):
		optionNum = i + 1
		print "\t\t\t %s. Name: %s \t Value: %s"   % (str(optionNum),NameList[i],ValList[i])
	
def selectCustomProperty():
	showCustomProperty(serverId)
	choice = raw_input("\n\t\t\t Please Enter your choice: ")
	global CustPropNameVar, CustPropValVar, SelectedPropList
	if is_digit(choice) == 0:
		if int(choice) <= arrayLen :
			choice = int(choice) - 1
			CustPropNameVar = NameList[choice]
			CustPropValVar = ValList[choice]
			SelectedPropList = getListArray(propList)[choice]
		if int(choice) > arrayLen :
			print raw_input("\n\t\tPlease stick with the options in the list..")
			selectCustomProperty()
	else:
		print raw_input("\n\t\tPlease stick with the options in the list..")
		#clearscreen()
		selectCustomProperty()
				
def addNewCustProperty():
	global newCustPropList
	newCustPropList = {}
	flag = ""
	while (flag != 0):
		name = raw_input("\n\t\t\t Property Name? : ")
		value = raw_input("\n\t\t\t Property Value? : ")
		newCustPropList[name] = value
		askQuestionLoopYN("\n\t\t Add another? [Y|N]: ")
		if (REPLY == "Y"):
			flag = 1
		if (REPLY == "N"):
			flag = 0
			break
	#print len(newCustPropList)
	
			
def addJVMCustomProperty(appServerName):
	addNewCustProperty()
	#print "\n\t\t The following will be added:"
	#getServerId(appServerName)
	#serverId = AdminConfig.getid('/Cell:' + cellNameVar + '/Node:/Server:' + appServerName + '/')	
	#print serverId
	for key,value in newCustPropList.items():
		CustPropNameVar = key
		CustPropValVar = value
		name = ['name', CustPropNameVar]
		value = ['value', CustPropValVar]
		attrib = [name, value]
		#print attrib
		#JVMId = AdminConfig.list('WebContainer', serverId)
		#print JVMId
		AdminConfig.create('Property', JVMId, attrib)
		print "\n\t\t\t Adding Property %s=%s to server %s" % (CustPropNameVar,CustPropValVar,getServerName(serverId))
	x = raw_input("\t\t\t Press Enter to Continue...")
	AdminConfig.save()
	#showCustomProperty(serverId)
	
def updateJVMCustomProperty(appServerName):
	selectCustomProperty()
	NewName = raw_input("\n\t\t\t New Property Name? ["+CustPropNameVar+"] : ")
	if (NewName == ""):
		NewName = CustPropNameVar
	NewValue = raw_input("\n\t\t\t New Property Value? ["+CustPropValVar+"] : ")
	if (NewValue == ""):
		NewValue = CustPropValVar
	name = ['name', NewName]
	value = ['value', NewValue]
	attrib = [name, value]
	#print attrib
	#serverId = AdminConfig.getid('/Cell:' + cellNameVar + '/Node:' + nodeNameVar + '/Server:' + appServerName + '/')
	#JVMId = AdminConfig.list('WebContainer', serverId)
	#PropertyId = (re.search("^"+CustPropNameVar, (AdminConfig.list('Property', JVMId))))
	PropertyId = SelectedPropList
	#print PropertyId
	AdminConfig.modify(PropertyId, attrib)		
	AdminConfig.save()
	print "\n\t\t\t Custom Property %s=%s has been added to server %s" % (NewName,NewValue,getServerName(serverId))
	
def removeJVMCustomProperty():
	global NewArrayLen
	selectCustomProperty()
	#print SelectedPropLis
	askQuestionLoopYN("\n\t\t You have selected to remove "+CustPropNameVar+"="+CustPropValVar+" from server "+getServerName(serverId)+". Proceed with the changes? [Y|N]: ")
	if (REPLY == "N"):
		x = raw_input("\n\t\t\t Aborting...Press Enter to continue..")
		removeJVMCustomProperty()
	elif (REPLY == "Y"):
		AdminConfig.remove(SelectedPropList)
		AdminConfig.save()
		print "\n\t\t\t Custom Property %s=%s has been deleted in server %s"  % (CustPropNameVar,CustPropValVar,getServerName(serverId))
	NewArrayLen = arrayLen - 1
	#return NewArrayLen

def restartServer():
	print "\n\t\t Restart AppServer.."
	whichApp()
	print "\n\t\t Restarting AppServer %s.. \n" % appServerName
	getServerId(appServerName)
	#print (getServerName(serverId), appServerName)
	getNode(getServerName(serverId))
	#print nodeName
	#getNode(appServerName)
	#print "\n\t\t Checking if appServer %s is running on node %s.. \n" % (appServerName, nodeName)
	#if len(try_cmd("AdminControl.completeObjectName('type=Server,node=' + nodeName + ',process=' + appServerName + ',*')")) != 0:
	if nodeName == 'NULL':
		print "\t\t Server %s is not running" % appServerName
		x = raw_input("\n\t\t Press Enter to choose another")
		restartServer()
	else:
		try:
			runningServer = AdminControl.completeObjectName('type=Server,node=' + nodeName + ',process=' + appServerName + ',*')
		except:
			print "\t\t Server %s is not running" % appServerName
			x = raw_input("\n\t\t Press Enter to choose another")
			restartServer()
		else:
			x = raw_input("\n\t\t You have chosen to restart "+appServerName+". Press Enter to continue")
			print "\n\t\t Stopping server %s ..." % appServerName
			AdminControl.stopServer(appServerName, nodeName)
			print "\n\t\t Done."
			print "\n\t\t Starting server %s ..." % appServerName
			AdminControl.startServer(appServerName, nodeName)
			print "\n\t\t Done."	
			x = raw_input("\n\t\t Press Enter to continue..")
			showMenu()

def whichApp():
	siteID = raw_input("\n\t\tPlease Enter the Site ID: ")
	#if is_digit(siteID) != 0 :
	#	print "\n\t\t Invalid site ID!!! Please try again..."
	#	whichApp()
	#else:
	#	searchApp(siteID)
	searchAppServer(siteID)

def searchAppServer(ID):
	global appServerName
	app = []
	plist = "[-serverType APPLICATION_SERVER]"
	aList = AdminTask.listServers(plist)
	for a in getListArray(aList):
		if re.search("^"+ID, getServerName(a)):
			app.append(getServerName(a))
	aLen = len(app)
	if aLen == 0:
		print "\n\t\t Site ID does not exist!!!"
		x = raw_input("\n\t\t Press Enter to Continue...")
		whichApp()
	else:
		flag = 1
		while (flag != 0):
			#clearscreen()
			print "\n\t\t AppServers Found: \n"
			for i in range(0, aLen):
				optionNum = i + 1
				print "\t\t " + str(optionNum) + " > " + app[i] 
			choice = raw_input("\n\t\t * Please select your option : ")
			if is_digit(choice) == 0:
				if int(choice) <= aLen :
					choice = int(choice) - 1			
					appServerName = app[choice]
					return appServerName
					break
				else:
					print raw_input("\n\t\t Please stick with the options in the list..")
					flag = 1
			else:
				print raw_input("\n\t\t Please stick with the options in the list..")
				flag = 1

def askQuestionLoopYN(question):
	global REPLY
	REPLY = ''
	while ((REPLY != "Y") | (REPLY != "N")):
		REPLY = raw_input(question)
		REPLY = string.upper(REPLY)
		if ((REPLY == "Y") | (REPLY == "N")):
			return REPLY
			break
		else:
			print  "\n\t\t Invalid response! Please try again."

def choice_N():
	askQuestionLoopYN("\n\t\tYou have chosen to abort.. Please press Y to start from the beginning, or press N to exit.")
	if (REPLY == "Y"):
		#clearscreen()
		initCommonCfg()
		showMenu()
	elif (REPLY == "N"):
		quit()							

def sync_node():
	choice = ""
	cell = AdminControl.getCell()
	while (choice != "Y|N"):	
		choice = raw_input("\n\t\t Synchronize changes with the Nodes? [Y|N]: ")
		choice = string.upper(choice)
		if (choice == "Y"):	
			## Full Syncronization ##
			print "\n\t\t Synchronizing configuration with Master Repository "
			nodelist = AdminTask.listManagedNodes()
			for nodename in getListArray(nodelist):
				print "\t\t Doing Full Resynchronization of node %s" % nodename
				####################Identifying the ConfigRepository MBean and assign it to variable######################
				#repo = AdminControl.completeObjectName('type=ConfigRepository,process=nodeagent,node='+ nodename +',*')
				#AdminControl.invoke(repo, 'refreshRepositoryEpoch')
				sync = AdminControl.completeObjectName('cell='+ cell +',node='+ nodename +',type=NodeSync,*')
				try:
					AdminControl.invoke(sync , 'sync')
				except:
					print "\t\t Invalid node Name or Node Not Running.. Skipping"						
				else:	
					AdminControl.invoke(sync , 'sync')
				#time.sleep(3)
			print "\t\t ----------------------------------------------------------------------------------------- "
			print "\t\t Full Resynchronization completed "
			print "\t\t ----------------------------------------------------------------------------------------- "
			x = raw_input("\n\t\tPress Enter to Continue...")
			break
		elif (choice == "N"):
			choice_N()		
				
				
#main
initCommonCfg()
showMenu()