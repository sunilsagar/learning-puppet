###############################################################################
# Script:      Jython script to be used on app server related tasks           #
# Name:        appserver.py                                                   #
# Description: Any new tasks related to appserver should be added here        #
# Author:      KO WebTeam - Ariel Santiago                                    #
###############################################################################

import sys, getopt, re;

#Create the 1st AppServer
def createappsrv(clusterNameVar, nodeNameVar, serverNameVar, genUniquePortsVar, templateNameVar):

  AdminTask.createApplicationServer(nodeNameVar, '[-name ' +  serverNameVar + ' -templateName ' + templateNameVar + ' -genUniquePorts true ]')

# Create the 1st cluster member (Original)`
#--------------------------------------------------------------------------------------------
#def create(clusterNameVar, nodeNameVar, serverNameVar, genUniquePortsVar, templateNameVar):

#  AdminTask.createClusterMember('[-clusterName ' + clusterNameVar + ' -memberConfig [-memberNode ' +  nodeNameVar + ' -memberName ' +  serverNameVar + ' -genUniquePorts ' + genUniquePortsVar + '] -firstMember [-templateName ' + templateNameVar + ']]')

# Create the 1st cluster member (Original)
#--------------------------------------------------------------------------------------------
def create(clusterNameVar, nodeNameVar, serverNameVar, genUniquePortsVar, templateNameVar):

  AdminTask.createCluster('[-clusterConfig [-clusterName ' + clusterNameVar + ' -preferLocal true] -convertServer [-serverNode ' + nodeNameVar + ' -serverName ' +  serverNameVar + ' -memberWeight 2 -nodeGroup DefaultNodeGroup -replicatorEntry false]]') 

# Create the next cluster member
#--------------------------------------------------------------------------------------------
def createNext(clusterNameVar, nodeNameVar, serverNameVar, genUniquePortsVar):

  AdminTask.createClusterMember('[-clusterName ' + clusterNameVar + ' -memberConfig [-memberNode ' +  nodeNameVar + ' -memberName ' +  serverNameVar + ' -genUniquePorts ' + genUniquePortsVar + ']]')

# Create a new custom property HttpSessionCloneId 
#--------------------------------------------------------------------------------------------
def addHttpSessionCloneId(cellNameVar, nodeNameVar, serverNameVar, httpSessionCloneNameVar, httpSessionCloneValVar):

  name = ['name', httpSessionCloneNameVar]
  value = ['value', httpSessionCloneValVar]
  attrib = [name, value]
  serverId = AdminConfig.getid('/Cell:' + cellNameVar + '/Node:' + nodeNameVar + '/Server:' + serverNameVar + '/')
  webContainerId = AdminConfig.list('WebContainer', serverId)
  AdminConfig.create('Property', webContainerId, attrib)

def updateHttpSessionCloneId(cellNameVar, nodeNameVar, serverNameVar, httpSessionCloneNameVar, httpSessionCloneValVar, PropertyId):
  name = ['name', httpSessionCloneNameVar]
  value = ['value', httpSessionCloneValVar]
  attrib = [name, value]
  serverId = AdminConfig.getid('/Cell:' + cellNameVar + '/Node:' + nodeNameVar + '/Server:' + serverNameVar + '/')
  webContainerId = AdminConfig.list('WebContainer', serverId)
  #PropertyId = AdminConfig.list('Property', webContainerId)
  AdminConfig.modify(PropertyId, attrib)			    
  
# Update the maximumHeapSize
#--------------------------------------------------------------------------------------------
def updateMaxHeapSize(maxHeapSizeVar, cellNameVar, nodeNameVar, serverNameVar):

  jvm = AdminConfig.getid('/Cell:' + cellNameVar + '/Node:' + nodeNameVar + '/Server:' + serverNameVar + '/JavaProcessDef:/JavaVirtualMachine:/') 
  AdminConfig.modify(jvm, [['maximumHeapSize', maxHeapSizeVar]])

# Update the application server's logs working directory
#--------------------------------------------------------------------------------------------
def updateLogDirectory(cellNameVar, nodeNameVar, serverNameVar, baseWorkingDirectoryVar):

  serverId = AdminConfig.getid('/Cell:' + cellNameVar + '/Node:' + nodeNameVar + '/Server:' + serverNameVar + '/')
  processDef = AdminConfig.list('JavaProcessDef', serverId)

  AdminConfig.modify(processDef, [['workingDirectory', baseWorkingDirectoryVar + serverNameVar]])

  
#----------------------------------------------------------------------------------
# Main
#----------------------------------------------------------------------------------
procNameVar = sys.argv[0]
saveVar = sys.argv[1]

if procNameVar == 'createappsrv':
  clusterNameVar = sys.argv[2]
  nodeNameVar = sys.argv[3]
  serverNameVar = sys.argv[4]
  genUniquePortsVar = sys.argv[5]
  serverTemplateNameVar = sys.argv[6]
  createappsrv(clusterNameVar, nodeNameVar, serverNameVar, genUniquePortsVar, serverTemplateNameVar)
elif procNameVar == 'create':
  clusterNameVar = sys.argv[2]
  nodeNameVar = sys.argv[3]
  serverNameVar = sys.argv[4]
  genUniquePortsVar = sys.argv[5]
  serverTemplateNameVar = sys.argv[6]
  create(clusterNameVar, nodeNameVar, serverNameVar, genUniquePortsVar, serverTemplateNameVar)
elif procNameVar == 'createNext':
  clusterNameVar = sys.argv[2]
  nodeNameVar = sys.argv[3]
  serverNameVar = sys.argv[4]
  genUniquePortsVar = sys.argv[5]
  createNext(clusterNameVar, nodeNameVar, serverNameVar, genUniquePortsVar)
elif procNameVar == 'update':
  PropertyId = []
  nodeNameVar = sys.argv[2]
  serverNameVar = sys.argv[3]
  cellNameVar = sys.argv[4]
  httpSessionCloneNameVar = sys.argv[5]
  httpSessionCloneValVar = sys.argv[6]
  baseWorkingDirectoryVar = sys.argv[7]
#  maxHeapSizeVar = sys.argv[8]
  serverId = AdminConfig.getid('/Cell:' + cellNameVar + '/Node:' + nodeNameVar + '/Server:' + serverNameVar + '/')
  webContainerId = AdminConfig.list('WebContainer', serverId)
  #PropertyId = AdminConfig.list('Property', webContainerId)
  PropertyList = AdminConfig.list('Property', webContainerId).split(lineSeparator)
  for Property in PropertyList:
	if re.search("^"+httpSessionCloneNameVar, Property):
		PropertyId.append(Property)
  if (len(PropertyId) != 0):
	updateHttpSessionCloneId(cellNameVar, nodeNameVar, serverNameVar, httpSessionCloneNameVar, httpSessionCloneValVar, PropertyId[0])
#  updateMaxHeapSize(maxHeapSizeVar, cellNameVar, nodeNameVar, serverNameVar)
  else:
	addHttpSessionCloneId(cellNameVar, nodeNameVar, serverNameVar, httpSessionCloneNameVar, httpSessionCloneValVar)
  updateLogDirectory(cellNameVar, nodeNameVar, serverNameVar, baseWorkingDirectoryVar)
else:
  print "Invalid method call"

if saveVar == 'yes':
  AdminConfig.save()

