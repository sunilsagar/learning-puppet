#!/bin/sh

applicationID=$1

if [ $applicationID = "" ] ; then
   echo "Please specfify application ID"
else
   /data02/ibm/websphere/appserver/7.0-64/bin/wsadmin.sh -lang jython -f  /data02/ibm/websphere/scripts/sitesetup/config.jy $applicationID
fi
