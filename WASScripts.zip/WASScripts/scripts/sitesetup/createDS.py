##################################################################################
# Script:      Jython script to be used to create DataSources at cell level      #
# Name:        createDS.py                                                       #
# Description: Any new tasks related to datasource creation should be added here #
# Author:      KO WebTeam - Reggie de Veas                                       #
##################################################################################

import java.util as util 
import java.io as javaio 
import java.util.HashSet as HashSet
import java.util.HashMap as HashMap
import java.util.TreeMap as TreeMap
import java.util.TreeSet as TreeSet
import java.lang.Integer as Integer
import java.lang.Comparable as Comparable
import time
import string
from time import sleep
import sys, java
from sys import argv
import os

lineSeparator = java.lang.System.getProperty('line.separator')
outlist=[]

# Declare global variables

global AdminConfig, AdminControl, selectedJDBCP, JDBCPName, properties, connectString, url, appName

def clearscreen():
     print  "\n"*500
     

def quit():
    sys.exit()

def convertToList(inlist):
     outlist=[]
     if (len(inlist)>0 and inlist[0]=='[' and inlist[len(inlist)-1]==']'):
        inlist = inlist[1:len(inlist)-1]
        clist = inlist.split("\"")
     else:
        clist = inlist.split("\n")
     for elem in clist:
        elem=elem.rstrip();
        if (len(elem)>0):
           outlist.append(elem)
     return outlist

def convertToList2(inlist):
     outlist=[]
     if (len(inlist)>0 and inlist[0]=='[' and inlist[len(inlist)-1]==']'):
        inlist = inlist[1:len(inlist)-1]
        clist = inlist.split(" ")
     else:
        clist = inlist.split("\n")
     for elem in clist:
        elem=elem.rstrip();
        if (len(elem)>0):
           outlist.append(elem)
     return outlist
	 
def _splitlist(s):
    if s[0] != '[' or s[-1] != ']':
        raise "Invalid string: %s" % s
    return s[1:-1].split(' ')

def _splitlines(s):
  rv = [s]
  if '\r' in s:
    rv = s.split('\r\n')
  elif '\n' in s:
    rv = s.split('\n')
  if rv[-1] == '':
    rv = rv[:-1]
  return rv	

def is_digit(s):
    try:
        float(s)
        return 0
    except ValueError:
        return 1

def getListArray(l):
    return l.splitlines()			
		
def choice_N():
	choice1 = ""
	while (choice1 != "Y|N"):
		choice1 = raw_input("\n\t\tYou have chosen to abort.. Please press Y to start from the beginning, or press N to exit.")
		choice1 = string.upper(choice1)
		if (choice1 == "Y"):
			x = raw_input("\nPress Enter to Continue...")
			#clearscreen()
			appName = raw_input("\t\t Enter the DataSource Name: ")
			getJDBCProvider()
			getConnectString()
			createJ2C()
			createDS()
			sync_node()
			testDS()
			quit()	
		elif (choice1 == "N"):
			quit()		
		
def sync_node():
	choice = ""
	cell = AdminControl.getCell()
	while (choice != "Y|N"):	
		choice = raw_input("\n\t\t Synchronize changes with the Nodes? [Y|N]: ")
		choice = string.upper(choice)
		if (choice == "Y"):	
			## Full Syncronization ##
			print "\n\t\t Synchronizing configuration with Master Repository "
			nodelist = AdminTask.listManagedNodes()
			for nodename in getListArray(nodelist):
				print "\t\t Doing Full Resynchronization of node %s" % nodename
				####################Identifying the ConfigRepository MBean and assign it to variable######################
				#repo = AdminControl.completeObjectName('type=ConfigRepository,process=nodeagent,node='+ nodename +',*')
				#AdminControl.invoke(repo, 'refreshRepositoryEpoch')
				sync = AdminControl.completeObjectName('cell='+ cell +',node='+ nodename +',type=NodeSync,*')
				try:
					AdminControl.invoke(sync , 'sync')
				except:
					print "\t\t Invalid node Name or Node Not Running.. Skipping"						
				else:	
					AdminControl.invoke(sync , 'sync')
				#time.sleep(3)
			print "\t\t ----------------------------------------------------------------------------------------- "
			print "\t\t Full Resynchronization completed "
			print "\t\t ----------------------------------------------------------------------------------------- "
			x = raw_input("\n\t\tPress Enter to Continue...")
			break
		elif (choice == "N"):
			choice_N()
			
def getJDBCProvider():
	import sys, java, re
	global JDBCPName
	print "\n\t\t\t Checking for the List of Providers:"
	OraJDBC = []
	PClassPath = []
	JDBCArray = {}
	#Get JDBC Provider List
	JDBCPList = convertToList(AdminConfig.list("JDBCProvider"))
	for JDBCP in JDBCPList:
		pName = AdminConfig.showAttribute(JDBCP, 'name')
		providerClasspath = AdminConfig.showAttribute(JDBCP, "classpath")
		if re.search("^[Oo]racle", pName):
			OraJDBC.append(pName)
			PClassPath.append(providerClasspath)
			JDBCArray[pName] = JDBCP
	print "\n\t\t\t Done..."		
	print "\n\t\t\t List of JDBC Providers:"
	arrayLen = len(OraJDBC)
	for i in range(0, arrayLen):
		optionNum = i + 1
		print "\t\t\t" + str(optionNum) + " > " + OraJDBC[i] + "\t(" + PClassPath[i] + ")"
	choice = raw_input("\n\t\t * Please select the JDBC Provider You want to use (..or press ENTER to create a new one) : ")
	if is_digit(choice) == 0:
		if int(choice) <= arrayLen :
			choice = int(choice) - 1
			JDBCPName = OraJDBC[choice]
			selectedJDBCP = JDBCArray[OraJDBC[choice]]
			#print selectedJDBCP
		if int(choice) > arrayLen :
			print raw_input("\n\t\t Please stick with the options in the list..")
			#clearscreen()
			getJDBCProvider()
	elif (choice == ""):
			createJDBC()
	else:
		print raw_input("\n\t\t Please stick with the options in the list..")
		#clearscreen()
		getJDBCProvider()

def createJDBC():
	#global cell
	#name = "jdbcOracle"+ env
	global JDBCPName
	print "\n\t\t ***********************"
	print "\t\t Creating JDBC Provider"
	print "\t\t ***********************"
	JDBCPName = raw_input("\n\t\t * Enter the JDBC Provider Name to create: ")
	print "\n\t\t Name of JDBC Provider which will be created ---> " + JDBCPName
	#print " ----------------------------------------------------------------------------------------- "
	# Get the name of cell
	cell = AdminControl.getCell()
	cellid = AdminConfig.getid('/Cell:'+ cell +'/')
	#print " ----------------------------------------------------------------------------------------- "
	Serverid = AdminConfig.getid('/Cell:'+ cell)
	
	## Checking for the existence of JDBC Provider 
	print "\n\t\t Checking for the existence of JDBC Provider :"+ JDBCPName
	J2 = AdminConfig.getid('/Cell:'+ cell +'/JDBCProvider:'+ JDBCPName)
	print "\n\t\t*******************************************************************************************************"
	if len(J2) > 0:
		print "\n\t\t JDBC Provider exists with name :"+ JDBCPName +" !!!"
		print "\t\t Please select a different name..."
		x = raw_input("\n\t\t Press Enter to Continue...")
		#clearscreen()
		createJDBC()
	else:
		print "\n\t\t JDBC Provider name Does not exist. Continuing with creation.."
		choice = ""
		while (choice != "Y|N"):
			print "\n\t\t*******************************************************************************************************"
			print "\n\t\t JDBC Provider details\n"
			print "\n\t\t Name		: " +  JDBCPName		
			print "\t\t JDBC Driver	: " +  jdbc_driver
			choice = raw_input("\n\t\t Create the JDBC Provider based on above information? [Y|N]: "	)
			choice = string.upper(choice)
			if (choice == "Y"):	
				## Creating New JDBC Provider ##
				print "\n\t\t Creating New JDBC Provider :"+ JDBCPName
				n1 = ["name" , JDBCPName ]
				desc = ["description" , "Oracle JDBC Driver"]
				impn = ["implementationClassName" , "oracle.jdbc.pool.OracleConnectionPoolDataSource"]
				classpath = ["classpath" , jdbc_driver ]
				attrs1 = [n1 , impn , desc , classpath]
				jdbc = AdminConfig.create('JDBCProvider' , Serverid , attrs1)
				#print " New JDBC Provider created :"+ JDBCPName
				AdminConfig.save()
				print "\n\t\t Saving Configuration "
				print "\t\t----------------------------------------------------------------------------------------- "
				break
			elif (choice == "N"):
				choice_N()			
		
def createJ2C():
	global appAlias, userName, passWord
	matchFound = ""
	dataSource = appName
	while (matchFound != 0):
		matchFound = 0
		if (dataSource == ""):
			dataSource = raw_input("\n\t\t * J2C Name to Create : ")
		dNode = AdminControl.getNode()
		appAlias = dNode +"/"+ dataSource
		## checking for the existence of JAASAuthData ## 
		jaasAuthDataList = AdminConfig.list("JAASAuthData") 
		jaasAuthDataList=jaasAuthDataList.split(lineSeparator)
		for jaasAuthId in jaasAuthDataList:
			getAlias = AdminConfig.showAttribute(jaasAuthId, "alias")
			if (cmp(getAlias,appAlias) == 0):
				matchFound = matchFound + 1
		if (matchFound != 0):
			print "\n\t\t J2C AuthAlias with name :"+ appAlias +" exist!!! Please select another name..."
			dataSource = ""
		#else:
		#	print "\n\t\tName does not exist. Continuing with setup..."
	print "\n\t\t\t*** Please provide DB Credentials ***"
	userName = raw_input("\n\t\t * UserName : ")
	passWord = raw_input("\n\t\t * PassWord : ")

	cell = AdminControl.getCell()
	sec = AdminConfig.getid("/Cell:" + cell + "/Security:/")
	attrs = []
	aliasAttr = ["alias", appAlias]
	descAttr = ["description", "authentication information when component-managed"]
	useridAttr = ["userId", userName]
	passwordAttr = ["password", passWord]
	attrs = [aliasAttr , descAttr , useridAttr , passwordAttr ]
	choice = ""
	while (choice != "Y|N"):
		print "\n\t\t*******************************************************************************************************"
		print "\n\t\t JAAS Auth details\n"
		print "\n\t\t Name		: " +  appAlias		
		print "\t\t UserName	: " +  userName
		print "\t\t PassWord 	: " +  passWord
		choice = raw_input("\n\t\t Create the J2C Auth based on above information? [Y|N]: "	)
		choice = string.upper(choice)
		if (choice == "Y"):
			appauthdata = AdminConfig.create("JAASAuthData", sec , attrs)
			print "\n\t\tCreated new JASSAuthData with Alias name :"+ appAlias
			#AdminTask.createAuthDataEntry('[-alias 123456 -user test -password ******** -description  ]')
			AdminConfig.save()
			print "\n\t\tSaving Configuration "
			#x = raw_input("\n\t\t Press Enter to Continue...")
			break
		elif (choice == "N"):
			choice_N()	

			
def getConnectString():
	global url, connectString
	properties = util.Properties()
	propertiesfis = javaio.FileInputStream(scriptDir+"/JDBC.connectstring")
	properties.load(propertiesfis)
	result= {}
	for entry in properties.entrySet():
		result[entry.key] = entry.value
	connectString = raw_input("\n\t\t * Database (e.g. KONAT, KONAP..) : ")
	connectString = string.upper(connectString)
	if (properties[connectString] == None):
		print "\n\t\t\t Invalid DB Name!!! Please try again.."
		getConnectString()
	else:
		url = properties[connectString]

	
def createDS():
	global cell
	datasource = appName
	cell = AdminControl.getCell()
	dNode = AdminControl.getNode()
	ds = AdminConfig.getid('/Cell:'+ cell +'/JDBCProvider:'+ JDBCPName)
	name1 = ["name" , datasource]
	desc = ["description", "New JDBC Datasource"]
	matchFound = "" 
	while (matchFound != 0):
		matchFound = 0
		jndiName = raw_input("\n\t\t * Enter the JNDI Name: e.g jdbc/mydb : ")
		dsList = AdminTask.listDatasources()
		dsList = dsList.split(lineSeparator)
		for dsName in dsList:
			getJNDI = AdminConfig.showAttribute(dsName, "jndiName")
			if (cmp(getJNDI,jndiName) == 0):
				matchFound = matchFound + 1
		if (matchFound != 0):		
			print "\n\t\t JNDI Alias with name :"+ jndiName +" exist!!! Please try another name..."
		#else:
		#	print "\n\t\t Name does not exist. Continuing with setup..."
					
	#matchFound = 0 
	#while (matchFound == 0):
	#	J2CAlias = raw_input("\n\t\t5.) Enter the the J2C Auth Alias : ")
	#	J2CFull = dNode + "/" + J2CAlias
	J2CFull = appAlias
	#	## checking for the existence of JAASAuthData ## 
	#	jaasAuthDataList = AdminConfig.list("JAASAuthData") 
	#	jaasAuthDataList=jaasAuthDataList.split(lineSeparator)
	#	for jaasAuthId in jaasAuthDataList:
	#		getAlias = AdminConfig.showAttribute(jaasAuthId, "alias")
	#		#print getAlias
	#		#print J2CFull
	#		if (cmp(getAlias,J2CFull) == 0):
	#			print "\n\t\tJ2C AuthAlias with name :"+ J2CAlias +" exist."
	#			matchFound = matchFound + 1
	#			#print matchFound
	#	if (matchFound == 0):
	#		print "\n\t\tJ2C AuthAlias with name :"+ J2CAlias +" does not exist!!! Please select another name..."
	#		#x = raw_input("\n\t\tPress Enter to Continue...")
	#		#sys.exit()
	#print "\n\t\t Name of datasource which will be created on JDBC Provider :"+ JDBCPName +" is :"+ datasource	
	jndiNameAttr = ["jndiName", jndiName]
	authentication = ["authDataAlias" , J2CFull]
	st_cachesize = ["statementCacheSize" , "10"]
	ds_hlpclass = ["datasourceHelperClassname" , "com.ibm.websphere.rsadapter.Oracle11gDataStoreHelper"]
	map_configalias_attr=["mappingConfigAlias" , ""]
	map_attrs=[authentication , map_configalias_attr]
	mapping_attr=["mapping", map_attrs]
	ds_attr = [name1 , desc , jndiNameAttr , authentication , st_cachesize , ds_hlpclass , mapping_attr]
	choice = ""
	while (choice != "Y|N"):
		print "\n\t\t*******************************************************************************************************"
		print "\n\t\t DataSource details\n"
		print "\n\t\t JDBC Provider  	: " +  JDBCPName		
		print "\t\t DataSource Name	: " +  datasource
		print "\t\t JNDI Name	     	: " +  jndiName
		print "\t\t J2C Auth Alias 	: " +  J2CFull
		print "\t\t Database URL   	: " +  connectString + " --> " + url
		choice = raw_input("\n\t\t Create the DataSource based on above information? [Y|N]: "	)
		choice = string.upper(choice)
		if (choice == "Y"):
			newds = AdminConfig.create('DataSource' , ds , ds_attr)
			print "\n\t\t New DataSource created with name :"+ datasource
			AdminConfig.save()
			print "\t\t Saving Configuration "
			print "\t\t ----------------------------------------------------------------------------------------- "
			## set the properties for the datasource ##
			print "\t\t Setting the properties for DataSource :"+ datasource
			newds1 = AdminConfig.getid('/Cell:'+ cell +'/JDBCProvider:'+ JDBCPName +'/DataSource:'+ datasource)
			propSet = AdminConfig.create('J2EEResourcePropertySet' , newds1 , [])
			name3 = ["name" , "URL"]
			type = ["type" , "java.lang.String"]
			required = ["required" , "true"]
			value = ["value" , url]
			rpAttrs = [name3 , type , required , value]
			jrp = AdminConfig.create('J2EEResourceProperty' , propSet , rpAttrs)
			print "\t\t Properties created for DataSource :"+ datasource
			AdminConfig.save()
			print "\t\t Saving Configuration "
			print "\t\t ----------------------------------------------------------------------------------------- "
			
			#Create an associated connection pool for the new DataSource#
			print "\t\t Creating Connection Pool Setting for DataSource :"+ datasource
			connPool = AdminConfig.list('ConnectionPool' , newds1)
			timeout = ["connectionTimeout" , "180"]
			maxconn = ["maxConnections" , "10"]
			minconn = ["minConnections" , "1"]
			reaptime = ["reapTime" , "180"]
			unusedtimeout = ["unusedTimeout" , "1800"]
			agedtimeout = ["agedTimeout" , "0"]
			purgepolicy = ["purgePolicy" , "EntirePool"]
			connPoolAttrs = [timeout , maxconn , minconn , reaptime , unusedtimeout , agedtimeout , purgepolicy]
			#AdminConfig.create("ConnectionPool", newds , connPoolAttrs)
			AdminConfig.modify(connPool , connPoolAttrs)
			print "\t\t Connection Pool Setting created for DataSource :"+ datasource
			AdminConfig.save()
			print "\t\t Saving Configuration "
			print "\t\t ----------------------------------------------------------------------------------------- "
			#x = raw_input("\n\t\t Press Enter to Continue...")
			
			break
		elif (choice == "N"):
			choice_N()

def testDS():
	##########Testing Database Connection################
	#datasource = raw_input("\n\t\tWhich DataSource do you want to TEST? ")
	datasource = appName
	cell = AdminControl.getCell()
	dsid = AdminConfig.getid('/Cell:'+ cell +'/JDBCProvider:'+ JDBCPName +'/DataSource:'+ datasource +'/')

	print "\n\t\t Testing Database Connection"

	print AdminControl.testConnection(dsid)

	print " ----------------------------------------------------------------------------------------- "
	x = raw_input("\n\t\tPress Enter to Continue...")
	########################################################
			

#Main
global scriptDir, appName, jdbc_driver
scriptDir = sys.argv[0]
jdbc_driver = "/usr/lib/oracle/11.2/client64/lib/ojdbc6.jar"
#clearscreen()
appName = raw_input("\n\t\t * Enter the DataSource Name (e.g. 9467-us-mycokerewards): ")
getJDBCProvider()
getConnectString()
createJ2C()
createDS()
sync_node()
#testDS()
quit()