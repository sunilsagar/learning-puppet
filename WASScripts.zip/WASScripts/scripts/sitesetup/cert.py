import sys
URL = sys.argv[0]
PORT = sys.argv[1]
ALIAS = sys.argv[2]
cell = AdminControl.getCell()
import string

def getListArray(l):
    return l.splitlines()

def sync_node():
        choice = ""
        cell = AdminControl.getCell()
        while (choice != "Y|N"):
                choice = raw_input("\n\t\t Synchronize changes with the Nodes? [Y|N]: ")
                choice = string.upper(choice)
                if (choice == "Y"):
                        ## Full Syncronization ##
                        print "\n\t\t Synchronizing configuration with Master Repository "
                        nodelist = AdminTask.listManagedNodes()
                        for nodename in getListArray(nodelist):
                                print "\t\t Doing Full Resynchronization of node %s" % nodename
                                ####################Identifying the ConfigRepository MBean and assign it to variable######################
                                #repo = AdminControl.completeObjectName('type=ConfigRepository,process=nodeagent,node='+ nodename +',*')
                                #AdminControl.invoke(repo, 'refreshRepositoryEpoch')
                                sync = AdminControl.completeObjectName('cell='+ cell +',node='+ nodename +',type=NodeSync,*')
                                try:
                                        AdminControl.invoke(sync , 'sync')
                                except:
                                        print "\t\t Invalid node Name or Node Not Running.. Skipping"
                                else:
                                        AdminControl.invoke(sync , 'sync')
                                #time.sleep(3)
                        print "\t\t ----------------------------------------------------------------------------------------- "
                        print "\t\t Full Resynchronization completed "
                        print "\t\t ----------------------------------------------------------------------------------------- "
                        x = raw_input("\n\t\tPress Enter to Continue...")
                        break
                elif (choice == "N"):
                        quit


AdminTask.retrieveSignerFromPort('[-keyStoreName CellDefaultTrustStore -keyStoreScope (cell):' + cell +' -host '+ URL +' -port '+ PORT +' -certificateAlias '+ ALIAS +' -sslConfigName CellDefaultSSLSettings -sslConfigScopeName (cell):' + cell +' ]')

AdminConfig.save()

print AdminTask.getSignerCertificate ('[-keyStoreName CellDefaultTrustStore -keyStoreScope (cell):' + cell +' -certificateAlias '+ ALIAS +']')

sync_node()
