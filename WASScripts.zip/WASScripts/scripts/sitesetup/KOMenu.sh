#!/bin/sh

###############################################################################
# Script:      Script to automate the KO Websphere initial site setup process #
# Name:        KOMenu.sh                                                      #
# Description: Calls jython scripts to create AppServer and Datasources       #
# Author:      KO WebTeam - Reggie de Veas                                    #
###############################################################################

WAS_HOME=/data02/ibm/websphere/appserver/7.0-64/profiles/dmgr
scriptsDir=/data02/ibm/websphere/scripts/sitesetup
LOGO="`hostname -a` Operations Menu"
TERM=linux; export TERM

createDS() {
echo "start \"Create DataSource\" at `date +%d%m%y-%H%M%S`" >> ${scriptsDir}/logs/KOMenu.log
$WAS_HOME/bin/wsadmin.sh -lang jython -f ${scriptsDir}/createDS.py ${scriptsDir}
echo -e "\n\t\t Restarting DMGR to complete DataSource creation..Press Enter to continue..\c"
read buffer
echo -e "\n\t\t Stopping DMGR..\n"; $WAS_HOME/bin/stopManager.sh; echo -e "\n\t\t Starting DMGR..\n"; $WAS_HOME/bin/startManager.sh
echo "end \"Create DataSource\" at `date +%d%m%y-%H%M%S`" >> ${scriptsDir}/logs/KOMenu.log
}

checkDMGR() {
PID=`cat $WAS_HOME/logs/dmgr/dmgr.pid`
if [ `echo $?` == "0" ]; then
	ps -ef | grep $PID 2>&1 > /dev/null
	if [ `echo $?` == "0" ]; then
		echo -e "\n\t\t\t DMGR OK... Proceeding with the script execution...\c"
		echo -e "\n"
	else
		echo -e "\n\t\t\t DMGR Process not Running!!! Please check... \c"
		read buffer
		menu
	fi
else
	echo -e  "\n\t\t\t DMGR Process not Running!!! Please check... \c"
	read buffer
	menu
fi
}	


testDS() {
echo "start \"Test DS\" at `date +%d%m%y-%H%M%S`" >> ${scriptsDir}/logs/KOMenu.log
$WAS_HOME/bin/wsadmin.sh -lang jython -f ${scriptsDir}/testConnect.py
echo "end \"Test DS\" at `date +%d%m%y-%H%M%S`" >> ${scriptsDir}/logs/KOMenu.log
}

addMember() {
echo "start \"Add Cluster Member\" at `date +%d%m%y-%H%M%S`" >> ${scriptsDir}/logs/KOMenu.log
$WAS_HOME/bin/wsadmin.sh -lang jython -f ${scriptsDir}/addClusterMember.py
echo "end \"Add Cluster Member\" at `date +%d%m%y-%H%M%S`" >> ${scriptsDir}/logs/KOMenu.log
}

WCCustomProps() {
echo "start \"WebContainer Custom Property\" at `date +%d%m%y-%H%M%S`" >> ${scriptsDir}/logs/KOMenu.log
$WAS_HOME/bin/wsadmin.sh -lang jython -f ${scriptsDir}/AddWCCustomProps.py
echo "end \"WebContainer Custom Property\" at `date +%d%m%y-%H%M%S`" >> ${scriptsDir}/logs/KOMenu.log
}

setJVM() {
echo "start \"JVM Settings\" at `date +%d%m%y-%H%M%S`" >> ${scriptsDir}/logs/KOMenu.log
$WAS_HOME/bin/wsadmin.sh -lang jython -f ${scriptsDir}/JVMSettings.py
echo "end \"JVM Settings\" at `date +%d%m%y-%H%M%S`" >> ${scriptsDir}/logs/KOMenu.log
}

addcert() {
echo "start \"3rd party SSL Cert\" at `date +%d%m%y-%H%M%S`" >> ${scriptsDir}/logs/KOMenu.log
echo "Please enter the URL from which you want to retreive the cert"
read URL

echo "Please enter the port for the URL from which you want to retreive the cert"
read PORT

echo "Please enter the alias for the cert with siteid and the cert that you want to add " eg:-11807-google " "
read ALIAS

if [ -z $URL ]; then echo "You did not enter either the alias or URL or the Port. Exiting!!"; exit 1;  fi

if [ -z $ALIAS ]; then echo "You did not enter either the alias or URL or the Port.. Exiting!!"; exit 1;  fi

if [ -z $PORT ]; then echo "You did not enter either the alias or URL or the Port.. Exiting!!"; exit 1;  fi
if [ ! -f ${scriptsDir}/cert.py ]; then echo "Jython script does not exist. Exiting!!"; exit 1; fi
$WAS_HOME/bin/wsadmin.sh -lang jython -f ${scriptsDir}/cert.py $URL $PORT $ALIAS
echo "end \"3rd party SSL Cert\" at `date +%d%m%y-%H%M%S`" >> ${scriptsDir}/logs/KOMenu.log
}

badchoice () { echo -e "\n\t\t\tInvalid Selection ... Please Try Again. Press any key to continue.." ; read junk; }

resetGlobal ()
{
	userId=`whoami`
	answer=""
}

askQuestionLoopYN () {
  while true
  do
      echo -n "$1 "
      read answer
      REPLY=${answer}
      if [[ ( ${REPLY} == "y" ) || ( ${REPLY} == "n" ) ]] ; then
         break
      else
         echo "Invalid response! Please try again."
      fi
  done
}

menu() {
clear
#answer=
echo `date`
echo
echo -e "\t\t\t" $LOGO
echo
echo -e "\t\tPlease Select:"
echo
echo -e "\t\t\t 1.  Create AppServer"
echo -e "\t\t\t 2.  Execute 2nd script for Appserver creation"
echo -e "\t\t\t 3.  Add Cluster Member(s)"
echo -e "\t\t\t 4.  Create DataSource"
echo -e "\t\t\t 5.  Test DS Connectivity"
echo -e "\t\t\t 6.  Add|Modify|Delete WebContainer Custom Property"
echo -e "\t\t\t 7.  JVM Settings"
echo -e "\t\t\t 8.  Add 3rd party SSL Cert"
echo
echo -e "\t\t\t x.  Exit"
echo
echo -e "\t\t\t Select by pressing the option number and then ENTER: \c"
read answer

case $answer in
1) checkDMGR; echo "start \"Create Appserver Script 1\" at `date +%d%m%y-%H%M%S`" >> ${scriptsDir}/logs/KOMenu.log; ${scriptsDir}/sitesetup.sh; echo "end \"Create Appserver Script 1\" at `date +%d%m%y-%H%M%S`" >> ${scriptsDir}/logs/KOMenu.log; menu;;
2) checkDMGR; echo "start \"Create Appserver Script 2\" at `date +%d%m%y-%H%M%S`" >> ${scriptsDir}/logs/KOMenu.log; ${scriptsDir}/sitesetup2.sh; echo "end \"Create Appserver Script 2\" at `date +%d%m%y-%H%M%S`" >> ${scriptsDir}/logs/KOMenu.log; menu;;
3) checkDMGR; addMember; menu;;
4) checkDMGR; createDS; menu;;
5) checkDMGR; testDS; menu;;
6) checkDMGR; WCCustomProps; menu;;
7) checkDMGR; setJVM; menu;;
8) checkDMGR; addcert; menu;;
x|X) break;;
*) badchoice; menu;;
esac
}

#main
while true
do
  resetGlobal
  clear
  #echo "NOTE: Please refrain from using this script until further notice!!!"
  #exit
  case $userId in
	wasadm) askQuestionLoopYN "You are logged in as $userId to setup a WAS 7.0 site. Please enter 'y' to continue OR enter 'n' and login as wasadm instead (y/n):";;
#	was61) askQuestionLoopYN "You are logged in as $userId and setting up a WAS 6.1 site. Please enter 'y' to continue OR enter 'n' and login as wasadmin instead (y/n):";;
#	*) echo "You have to login as wasadm OR was61 in order to use this script!"; exit ;;
	*) echo "You have to login as wasadm in order to use this script!"; exit ;;
  esac

  if [[ "${REPLY}" == "n" ]]; then
	exit
  fi
  menu
done 
#checkDMGR
