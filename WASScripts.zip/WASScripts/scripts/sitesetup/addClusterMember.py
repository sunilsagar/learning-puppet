######################################################################################
# Script:      Jython script to be used to Add Members to Existing Clusters          #
# Name:        addClusterMembers.py                                                  #
# Description: Any new tasks related to adding cluster members should be added here  #
# Author:      KO WebTeam - Reggie de Veas                                           #
######################################################################################

import java.util as util 
import java.io as javaio 
import sys, getopt, re;
import time
import string

global lineSeparator
lineSeparator = java.lang.System.getProperty('line.separator')

def initCommonCfg():
	global genUniquePortsVar, baseWorkingDirectoryVar, httpSessionCloneNameVar, cellNameVar
	genUniquePortsVar = 'false'
	baseWorkingDirectoryVar = '${USER_INSTALL_ROOT}/logs/'
	httpSessionCloneNameVar = 'HttpSessionCloneId'
	cellNameVar	= AdminControl.getCell()

def clearscreen():
     print  "\n"*500
     
def quit():
    sys.exit()

def is_digit(s):
    try:
        float(s)
        return 0
    except ValueError:
        return 1

def getListArray(l):
    return l.splitlines()	
	
def askQuestionLoopYN(question):
	global REPLY
	REPLY = ''
	while ((REPLY != "Y") | (REPLY != "N")):
		REPLY = raw_input(question)
		REPLY = string.upper(REPLY)
		if ((REPLY == "Y") | (REPLY == "N")):
			return REPLY
			break
		else:
			print  "\n\t\t Invalid response! Please try again."

def choice_N():
	askQuestionLoopYN("\n\t\tYou have chosen to abort.. Please press Y to start from the beginning, or press N to exit.")
	if (REPLY == "Y"):
		clearscreen()
		whichApp()
		sync_node()
	elif (REPLY == "N"):
		quit()			

def show_ClusterMembers(clusterName):
	print "\n\t\t Cluster Found with the Following Details : "
	clusterMemberList = AdminConfig.list('ClusterMember', AdminConfig.getid( '/Cell:'+cellNameVar+'/ServerCluster:'+clusterName+'/')).split(lineSeparator)
	print "\n\t\t Cluster Name: " + clusterName	
	print "\t\t Members:"
	print "\t\t Node Name:\t\t MemberName:\t Cluster Weight:\n"
	for member in clusterMemberList:
		memberName = AdminConfig.showAttribute(member, 'memberName')
		nodeName = AdminConfig.showAttribute(member, 'nodeName')
		weight = AdminConfig.showAttribute(member, 'weight')
		print "\t\t "+ nodeName + "\t"+ memberName +"\t\t"+ weight
	askQuestionLoopYN("\n\t\t Is this correct? [Y|N]: ")
	if (REPLY == "Y"):
		select_Nodes()
	if (REPLY == "N"):
		clearscreen(); whichApp()

def show_Nodes(nLen, nodeList):
	newMemberList = {}
	global newMemberList
	clearscreen()
	choice1 = "Y"
	flag = ""
	while (flag != 0):
		print "\n\t\t\t List of Available Nodes:\n"	
		for i in range(0, nLen):	
			optionNum = i + 1
			print "\t\t" + str(optionNum) + " > " + nodeList[i]		
		choice = raw_input("\n\t\t * Please select which node(s) to add member(s): ")
		if is_digit(choice) == 0:
			if int(choice) <= nLen :
				choice = int(choice) - 1			
				nodeName = nodeList[choice]
				#nodeSelect.append(nodeName)
				memberName = raw_input("\n\t\t * Member Name?: ")
				#newMember = [nodeName, memberName]
				newMemberList[nodeName] = memberName
				askQuestionLoopYN("\n\t\t Add some more members? [Y|N]: ")
				if (REPLY == "Y"):
					flag = 1
				if (REPLY == "N"):
					flag = 0
					break
			if int(choice) > nLen :
				#clearscreen()
				print raw_input("\n\t\t Please stick with the options in the list..")
				flag = 1
		else:
			print raw_input("\n\t\tPlease stick with the options in the list..")
			flag = 1

def createNext(clusterNameVar, nodeNameVar, serverNameVar, genUniquePortsVar):
	AdminTask.createClusterMember('[-clusterName ' + clusterNameVar + ' -memberConfig [-memberNode ' +  nodeNameVar + ' -memberName ' +  serverNameVar + ' -genUniquePorts ' + genUniquePortsVar + ']]')
				
				
def addHttpSessionCloneId(cellNameVar, nodeNameVar, serverNameVar, httpSessionCloneNameVar, httpSessionCloneValVar):
	name = ['name', httpSessionCloneNameVar]
	value = ['value', httpSessionCloneValVar]
	attrib = [name, value]
	serverId = AdminConfig.getid('/Cell:' + cellNameVar + '/Node:' + nodeNameVar + '/Server:' + serverNameVar + '/')
	webContainerId = AdminConfig.list('WebContainer', serverId)
	AdminConfig.create('Property', webContainerId, attrib)			
	
def updateHttpSessionCloneId(cellNameVar, nodeNameVar, serverNameVar, httpSessionCloneNameVar, httpSessionCloneValVar, PropertyId):
	name = ['name', httpSessionCloneNameVar]
	value = ['value', httpSessionCloneValVar]
	attrib = [name, value]
	serverId = AdminConfig.getid('/Cell:' + cellNameVar + '/Node:' + nodeNameVar + '/Server:' + serverNameVar + '/')
	webContainerId = AdminConfig.list('WebContainer', serverId)
	#PropertyId = (re.search("^HttpSessionCloneId", (AdminConfig.list('Property', webContainerId))))
	#print PropertyId
	AdminConfig.modify(PropertyId, attrib)				

def updateLogDirectory(cellNameVar, nodeNameVar, serverNameVar, baseWorkingDirectoryVar):
	serverId = AdminConfig.getid('/Cell:' + cellNameVar + '/Node:' + nodeNameVar + '/Server:' + serverNameVar + '/')
	processDef = AdminConfig.list('JavaProcessDef', serverId)
	AdminConfig.modify(processDef, [['workingDirectory', baseWorkingDirectoryVar + serverNameVar]])	
			
def whichApp():
	siteID = raw_input("\n\t\tPlease Enter the Site ID: ")
	if is_digit(siteID) != 0 :
		print "\n\t\t Invalid site ID!!! Please try again..."
		whichApp()
	else:
		searchCluster(siteID)
#	searchCluster(siteID)
	
def searchCluster(siteID):
	global clusterName
	cluster = []
	cList = AdminConfig.list('ServerCluster').split(lineSeparator)
	for c in cList:
		cName = AdminConfig.showAttribute(c, "name")
		if re.search("^"+siteID, cName):
			cluster.append(cName)
	cLen = len(cluster)
	if cLen == 0:
		print "\n\t\t Cluster Corresponding to Site ID does not exist!!!"
		x = raw_input("\n\t\t Press Enter to Continue...")
		whichApp()
	elif cLen == 1:
		clusterName = cluster[0]
		show_ClusterMembers(clusterName)
	if cLen > 1:
		flag = ""
		while (flag != 0):
			clearscreen()
			print "\n\t\t More than one cluster exist. Please select which one to modify"
			for i in range(0, cLen):
				optionNum = i + 1
				print "\t\t" + str(optionNum) + " > " + cluster[i] 
			choice = raw_input("\n\t\t * Please select your option : ")
			if is_digit(choice) == 0:
				if int(choice) <= cLen :
					choice = int(choice) - 1			
					clusterName = cluster[choice]
					#x = raw_input("\n\t\t Selected cluster "+ clusterName +". Press Enter to Continue...")
					flag = 0
					show_ClusterMembers(clusterName)
					break
				if int(choice) > cLen :
					clearscreen()
					print raw_input("\n\t\t Please stick with the options in the list..")
					flag = 1
			else:
				clearscreen()
				print raw_input("\n\t\t Please stick with the options in the list..")
				flag = 1
	
def select_Nodes():
	nodeList = []
	PropertyId = []
	nodelist = AdminTask.listManagedNodes().split(lineSeparator)
	for nodename in nodelist:
		nodeList.append(nodename)
	nLen = len(nodeList)
	if nLen == 0:
		clearscreen()
		print "\n\t\t No Available Nodes in the Cell!!!"
		x = raw_input("\t\t Press Enter to Continue...")
		quit()
	elif nLen >= 1:	
		show_Nodes(nLen, nodeList)
	clearscreen()	
	print "\n\t\t Cluster Member(s) to Add:\n"
	item = 0
	for key,value in newMemberList.items():
		node = key
		member = value	
		item = item + 1
		print "\t\t"+ str(item) +"> NodeName: " + node + "\tMember Name: "+ member
	askQuestionLoopYN("\n\t\t Is this correct? [Y|N]: ")
	if (REPLY == "Y"):
		for key,value in newMemberList.items():
			PropertyId = []		
			nodeNameVar = key
			serverNameVar = value
			httpSessionCloneValVar = value
			createNext(clusterName, nodeNameVar, serverNameVar, genUniquePortsVar)
			serverId = AdminConfig.getid('/Cell:' + cellNameVar + '/Node:' + nodeNameVar + '/Server:' + serverNameVar + '/')
			webContainerId = AdminConfig.list('WebContainer', serverId)
			PropertyList = AdminConfig.list('Property', webContainerId).split(lineSeparator)
			for Property in PropertyList:
				if re.search("^HttpSessionCloneId", Property):
					PropertyId.append(Property)
			if (len(PropertyId) != 0):
				updateHttpSessionCloneId(cellNameVar, nodeNameVar, serverNameVar, httpSessionCloneNameVar, httpSessionCloneValVar, PropertyId[0])
			else:
				addHttpSessionCloneId(cellNameVar, nodeNameVar, serverNameVar, httpSessionCloneNameVar, httpSessionCloneValVar)
			updateLogDirectory(cellNameVar, nodeNameVar, serverNameVar, baseWorkingDirectoryVar)
			print "\t\t Created clustermember "+ serverNameVar
			print "\t\t ----------------------------------------------------------------------------------------- "
		AdminConfig.save()
		print "\t\t Saving Configuration "
		print "\t\t ----------------------------------------------------------------------------------------- "

	if (REPLY == "N"):
			clearscreen(); whichApp()
	
def sync_node():
	choice = ""
	cell = AdminControl.getCell()
	while (choice != "Y|N"):	
		choice = raw_input("\n\t\t Synchronize changes with the Nodes? [Y|N]: ")
		choice = string.upper(choice)
		if (choice == "Y"):	
			## Full Syncronization ##
			print "\n\t\t Synchronizing configuration with Master Repository "
			nodelist = AdminTask.listManagedNodes()
			for nodename in getListArray(nodelist):
				print "\t\t Doing Full Resynchronization of node %s" % nodename
				####################Identifying the ConfigRepository MBean and assign it to variable######################
				#repo = AdminControl.completeObjectName('type=ConfigRepository,process=nodeagent,node='+ nodename +',*')
				#AdminControl.invoke(repo, 'refreshRepositoryEpoch')
				sync = AdminControl.completeObjectName('cell='+ cell +',node='+ nodename +',type=NodeSync,*')
				try:
					AdminControl.invoke(sync , 'sync')
				except:
					print "\t\t Invalid node Name or Node Not Running.. Skipping"						
				else:	
					AdminControl.invoke(sync , 'sync')
				#time.sleep(3)
			print "\t\t ----------------------------------------------------------------------------------------- "
			print "\t\t Full Resynchronization completed "
			print "\t\t ----------------------------------------------------------------------------------------- "
			x = raw_input("\n\t\tPress Enter to Continue...")
			break
		elif (choice == "N"):
			choice_N()
		

#main
initCommonCfg()
clearscreen()
whichApp()
sync_node()
quit()