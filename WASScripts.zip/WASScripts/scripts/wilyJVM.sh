/data01/websphere/appserver/7.0-64/bin/wsadmin.sh -lang jython -f ./wilyJVM.py
