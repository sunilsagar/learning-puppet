#!/bin/bash

#installDir=`cell`
#logDir=`logs`

scriptDir=/data01/websphere/scripts
installDir=/data01/websphere/appserver/7.0-64/profiles/appserver/installedApps/s262381ch3vl194Cell01
wilyDir=/data01/websphere/share/wily
logDir=/data01/websphere/appserver/7.0-64/profiles/appserver/logs

ls -d $installDir/*-*.ear > $scriptDir/earList.txt
appCtr=`cat ${scriptDir}/earList.txt | wc -l`
echo $appCtr

logFileDate=`date +%Y%m%d_%H%M%S`
calledDateTime="`date '+%b %e %H:%M:%S'`"

echo "$calledDateTime ********* " > $scriptDir/wasProfile.${logFileDate}.log

for (( tmpCtr = ${appCtr} ; tmpCtr > 0 ; tmpCtr-- ))
do
        sedVar=`sed -n "${tmpCtr} p" ${scriptDir}/earList.txt`
        currentLine=(`echo ${sedVar} | sed "s/\// /g"`)
        targetAppIndex=`expr ${#currentLine[*]} - 1`
        targetApp=${currentLine[$targetAppIndex]}

        lengthTemp=`expr length ${targetApp}`
        lengthTemp=`expr $lengthTemp - 4`
        targetApp=`echo ${targetApp:0:lengthTemp}`

	echo "" >> $scriptDir/wasProfile.${logFileDate}.log
	echo "Checking $targetApp" >> $scriptDir/wasProfile.${logFileDate}.log

	targetSrv=`ls -d $logDir/$targetApp* > ${scriptDir}/tempServer.txt`
	serverCtr=`ls -d $logDir/$targetApp* | wc -l`

	if [[ ${serverCtr} -eq 0 ]]; then	
		echo "APPSERVER NOT FOUND FOR $targetApp" >> $scriptDir/wasProfile.${logFileDate}.log
	else
		for (( tmpCtr2 = ${serverCtr} ; tmpCtr2 > 0 ; tmpCtr2-- ))
		do
		        sedVar=`sed -n "${tmpCtr2} p" ${scriptDir}/tempServer.txt`
		        currentLine=(`echo ${sedVar} | sed "s/\// /g"`)
		        targetSrvIndex=`expr ${#currentLine[*]} - 1`
		        targetSrv=${currentLine[$targetSrvIndex]}
			echo "Found $targetSrv" >> $scriptDir/wasProfile.${logFileDate}.log
			cd $wilyDir
		 	./makeProfile.sh $targetSrv $targetApp >> $scriptDir/wasProfile.${logFileDate}.log
		done
	fi
done
