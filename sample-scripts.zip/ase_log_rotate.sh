#!/bin/sh
# ASE Dataserver, Backupserver, Jobserver log rotation.
# Copies/compresses logs, clears in use logs, removes old gzipped logs.
# John Powell 09042017
# Usage: Crontab entry with DS/BS/JS log retention (days) as variable.
# ASE Dataserver,Backupserver,Jobserver log rotation.
# 00 1 1 * * /data01/home/sybase/scripts/ase_log_rotate.sh 365 >> /data01/home/sybase/logs/ase_log_rotate.log 2>&1

DATE=`date +%Y%m%d_%H%M`
. ~/SYBASE.sh

# Find SID
SID=`echo $SYBASE | sed 's/\/sybase\///g'`

# Find the dataserver log path.
DSLOG=`ps -ef | grep dataserver |  grep "$SID" | sed 's/.*-e//' | grep -v grep | awk '{print $1}'`
# Find the backupserver log path.
BSLOG=`ps -ef | grep backupserver |  grep "$SID" | sed 's/.*-e//' | grep -v grep | awk '{print $1}'`
# Find the jobserver log path.
JSLOG=`ps -ef | grep jsagent |  grep "$SID" | sed 's/.*-e//' | grep -v grep | awk '{print $1}'`
# Find the dataserver log directory.
DS_DIR=`ps -ef | grep dataserver |  grep "$SID" | sed 's/.*-e//' | grep -v grep | awk '{print $1}' | sed 's:/[^/]*$::'`
# Find the backupserver log directory.
BS_DIR=`ps -ef | grep backup |  grep "$SID" | sed 's/.*-e//' | grep -v grep | awk '{print $1}' | sed 's:/[^/]*$::'`
# Find the jobserver log directory.
JS_DIR=`ps -ef | grep jsagent |  grep "$SID" | sed 's/.*-e//' | grep -v grep | awk '{print $1}' | sed 's:/[^/]*$::'`

# Verify the dataserver file exists, rotate, write null to log, gzip
for i in $DSLOG; do
if [ -e $i ]; then
echo "Dataserver log=$i copied to $i.$DATE.gz"
  cp $i $i.$DATE
  cp /dev/null $i
  gzip $i.$DATE
fi
done

# Verify the backupserver file exists, rotate, write null to log, gzip
for i in $BSLOG; do
if [ -e $i ]; then
echo "Backupserver log=$i copied to $i.$DATE.gz"
  cp $i $i.$DATE
  cp /dev/null $i
  gzip $i.$DATE
fi
done

# Verify the jobserver file exists, rotate, write null to log, gzip
for i in $JSLOG; do
if [ -e $i ]; then
echo "Jobserver log=$i copied to $i.$DATE.gz"
  cp $i $i.$DATE
  cp /dev/null $i
  gzip $i.$DATE
fi
done

# Verify the dataserver log directory exists removes gzipped logs based on retention variable
for i in $DS_DIR; do
if [ -e $i ]; then
#Alert for null retention value
if [ -z "$1" ];then
echo "RETENTION VARIABLE NOT PASSED - LOGS NOT REMOVED."
else
#list files to be removed
REMOVED=`find $i -name "*log*.gz" -mtime +$1;`
echo "Gzipped log files older than $1 days removed from $i:"
echo $REMOVED | grep gz
#remove files
find $i -name "*log*.gz" -mtime +$1 -exec rm {} \;
fi
fi
done

# Verify the backup server log directory exists removes gzipped logs based on retention variable
for i in $BS_DIR; do
if [ -e $i ]; then
#Alert for null retention value
if [ -z "$1" ];then
echo "RETENTION VARIABLE NOT PASSED - LOGS NOT REMOVED."
else
#list files to be removed
REMOVED=`find $i -name "*log*.gz" -mtime +$1;`
echo "Gzipped log Files older than $1 days removed from $i:"
echo $REMOVED | grep gz
#remove files
find $i -name "*log*.gz" -mtime +$1 -exec rm {} \;
fi
fi
done

# Verify the job server log directory exists removes gzipped logs based on retention variable
for i in $JS_DIR; do
if [ -e $i ]; then
#Alert for null retention value
if [ -z "$1" ];then
echo "RETENTION VARIABLE NOT PASSED - LOGS NOT REMOVED."
else
#list files to be removed
REMOVED=`find $i -name "*log*.gz" -mtime +$1;`
echo "Gzipped log Files older than $1 days removed from $i:"
echo $REMOVED | grep gz
#remove files
find $i -name "*log*.gz" -mtime +$1 -exec rm {} \;
fi
fi
done

