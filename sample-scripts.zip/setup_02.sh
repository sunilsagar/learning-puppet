#!/bin/sh

HOST=`hostname`
DBUSER="sa"
DATE=`/bin/date +%Y%m%d%H%M%S`
DIR="/tmp/scripts/"
PWD=`cat ${DIR}*PWD`
SID=`cat ${DIR}*SID`

##Untar script
tar -xvf ${DIR}SQL.tar -C /tmp/scripts

##Setting SID in scripts
sed -i -e "s/SID/$SID/g" ${DIR}crontab.txt
sed -i -e "s/SID/$SID/g" ${DIR}ddl.sql
sed -i -e "s/PWD/$PWD/g" ${DIR}ddl.sql
sed -i -e "s/SID/$SID/g" ${DIR}bash_profile.txt
sed -i -e "s/SID/$SID/g" ${DIR}cshrc.txt

dos2unix ${DIR}prc_cumulative_backup.sql &> /dev/null;
dos2unix ${DIR}prc_cumulative_dumpdb.sql &> /dev/null;
##Creating CTL database objects
check_query()
{
DATABASE="$1"
CMD="$2"
RETVAL=`$SYBASE/$SYBASE_OCS/bin/isql -S ${SID} -U ${DBUSER} -I $SYBASE/interfaces -w 9999 -X -b -P ${PWD} <<EOF
SET NOCOUNT ON
use ${DATABASE}
go
${CMD}
go
EOF`
TEMP=`echo ${RETVAL##+([[:space:]])}`
RETVAL=`echo ${TEMP%%+([[:space:]])}`
}

run_script()
{
DATABASE="$1"
SCRIPT="$2"
$SYBASE/$SYBASE_OCS/bin/isql -I $SYBASE/interfaces -S ${SID} -U ${DBUSER}  -D ${DATABASE} -w9999 -X -i ${SCRIPT} -P ${PWD}
}

check_query "master" "select getdate()"
if [[ $RETVAL =~ failed ]]; then
  echo "ERROR - cannot establish isql connection to $SID as $DBUSER on $HOST at $DATE."
  echo $RETVAL"."
#  exit 1;
elif [[ $RETVAL =~ "server name" ]]; then
  echo "ERROR - cannot find dataserver $SID as $DBUSER on $HOST at $DATE."
  echo "ALERT" $RETVAL"."
#  exit 1;
else
                
		run_script "master" "${DIR}ddl.sql"
				
		check_query "svvstools" "SELECT COUNT(1) FROM sysobjects o, sysusers u WHERE o.uid=u.uid AND o.name = 'usp_dumpdb' AND u.name = 'dbo' AND o.type = 'P'"
                if [ "$RETVAL" -eq "0" ];
                        then
                                run_script "svvstools" "${DIR}usp_dumpdb.sql"
                                check_query "svvstools" "SELECT COUNT(1) FROM sysobjects o, sysusers u WHERE o.uid=u.uid AND o.name = 'usp_dumpdb' AND u.name = 'dbo' AND o.type = 'P'"
                                if [ "$RETVAL" -eq "0" ];
                                        then
                                                echo "FAILED - Unable to create SP usp_dumpdb in svvstools database. Please check log.."
                                else
                                                echo "SUCCESS - SP usp_dumptran is created in svvstools database"
                                fi
                        else
                                echo "SKIPPED - SP usp_dumpdb exists in svvstools database"
                fi
                check_query "svvstools" "SELECT COUNT(1) FROM sysobjects o, sysusers u WHERE o.uid=u.uid AND o.name = 'usp_dumptran' AND u.name = 'dbo' AND o.type = 'P'"
                if [ "$RETVAL" -eq "0" ];
                        then
                                run_script "svvstools" "${DIR}usp_dumptran.sql"
                                check_query "svvstools" "SELECT COUNT(1) FROM sysobjects o, sysusers u WHERE o.uid=u.uid AND o.name = 'usp_dumptran' AND u.name = 'dbo' AND o.type = 'P'"
                                if [ "$RETVAL" -eq "0" ];
                                        then
                                                echo "FAILED - Unable to create SP usp_dumptran svvstools database. Please check log.."
                                else
                                                echo "SUCCESS - SP usp_dumptran is created in svvstools database"
                                fi
                        else
                                echo "SKIPPED - SP usp_dumptran exists in svvstools database"
                fi
                check_query "svvstools" "SELECT COUNT(1) FROM sysobjects o, sysusers u WHERE o.uid=u.uid AND o.name = 'usp_generic_backup_v1' AND u.name = 'dbo' AND o.type = 'P'"
                if [ "$RETVAL" -eq "0" ];
                        then
                                run_script "svvstools" "${DIR}usp_generic_backup_v1.sql"
                                check_query "svvstools" "SELECT COUNT(1) FROM sysobjects o, sysusers u WHERE o.uid=u.uid AND o.name = 'usp_generic_backup_v1' AND u.name = 'dbo' AND o.type = 'P'"
                                if [ "$RETVAL" -eq "0" ];
                                        then
                                                echo "FAILED - Unable to create SP usp_generic_backup_v1 in svvstools database. Please check log.."
                                else
                                                echo "SUCCESS - SP usp_generic_backup_v1 is created in svvstools database"
                                fi
                        else
                                echo "SKIPPED - SP usp_generic_backup_v1 exists in svvstools database"
                fi
		check_query "svvstools" "SELECT COUNT(1) FROM sysobjects o, sysusers u WHERE o.uid=u.uid AND o.name = 'prc_cumulative_dumpdb' AND u.name = 'dbo' AND o.type = 'P'"
                if [ "$RETVAL" -eq "0" ];
                        then
                                run_script "svvstools" "${DIR}prc_cumulative_dumpdb.sql"
                                check_query "svvstools" "SELECT COUNT(1) FROM sysobjects o, sysusers u WHERE o.uid=u.uid AND o.name = 'prc_cumulative_dumpdb' AND u.name = 'dbo' AND o.type = 'P'"
                                if [ "$RETVAL" -eq "0" ];
                                        then
                                                echo "FAILED - Unable to create SP prc_cumulative_dumpdb in svvstools database. Please check log.."
                                else
                                                echo "SUCCESS - SP prc_cumulative_dumpdb is created in svvstools database"
                                fi
                        else
                                echo "SKIPPED - SP prc_cumulative_dumpdb exists in svvstools database"
                fi
                check_query "svvstools" "SELECT COUNT(1) FROM sysobjects o, sysusers u WHERE o.uid=u.uid AND o.name = 'prc_cumulative_backup' AND u.name = 'dbo' AND o.type = 'P'"
                if [ "$RETVAL" -eq "0" ];
                        then
                                run_script "svvstools" "${DIR}prc_cumulative_backup.sql"
                                check_query "svvstools" "SELECT COUNT(1) FROM sysobjects o, sysusers u WHERE o.uid=u.uid AND o.name = 'prc_cumulative_backup' AND u.name = 'dbo' AND o.type = 'P'"
                                if [ "$RETVAL" -eq "0" ];
                                        then
                                                echo "FAILED - Unable to create SP prc_cumulative_backup in svvstools database. Please check log.."
                                else
                                                echo "SUCCESS - SP prc_cumulative_backup is created in svvstools database"
                                fi
                        else
                                echo "SKIPPED - SP prc_cumulative_backup exists in svvstools database"
                fi


		

fi

##Adding alias to profile
cd
FILE=".cshrc"
if [ -f "$FILE" ]
then
                if grep -q "isdba" ~/.cshrc;
                                then
                echo "SKIPPED - CLT variables exists in Sybase cshrc profile"
                                else
                cp ~/.cshrc ~/.cshrc.$DATE
                cat /tmp/scripts/cshrc.txt >> ~/.cshrc
                echo "SUCCESS - Taken backup and created new cshrc"
                                fi
else
                cat /tmp/scripts/cshrc.txt > ~/.cshrc
                echo "SUCCESS - Created new cshrc profile for Sybase"
fi

cd
FILE=".bash_profile"
if [ -f "$FILE" ]
then
                if grep -q "isdba" ~/.bash_profile;
                                then
                echo "SKIPPED - CLT variables exists in Sybase bash profile"
                                else
                cp ~/.bash_profile ~/.bash_profile.$DATE
                cat /tmp/scripts/bash_profile.txt >> ~/.bash_profile
                echo "SUCCESS - Taken backup and created new bash_profile"
                                fi
else
                cat /tmp/scripts/bash_profile.txt > ~/.bash_profile
                echo "SUCCESS - Created new bash profile for Sybase"
fi

##Adding Crontab to profile
CRON=`crontab -l|wc -l`
echo $CRON
if [ $CRON -ne 0 ];
        then
                echo "SKIPPED - crontab exists in Sybase profile"
        else
                crontab /tmp/scripts/crontab.txt
                echo "SUCCESS - crontab created for Sybase profile"
                crontab -l
fi

exit 0;
