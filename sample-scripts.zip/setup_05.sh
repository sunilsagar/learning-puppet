#!/bin/sh

HOST=`hostname`
DATE=`/bin/date +%Y%m%d%H%M%S`
DIR="/tmp/scripts/"
PWD=`cat ${DIR}*PWD`
SID=`cat ${DIR}*SID`
MEM=`cat ${DIR}*MEM`
REP=`cat ${DIR}*REP`

##Copy script to /tmp/directory

FILE="/tmp/qa.sh"
if [ -f "$FILE" ]
then
        echo "SKIPPED - Script $FILE exists"
else
        cp ${DIR}qa.sh ${FILE}
fi

FILE="/tmp/db"
if [ -f "$FILE" ]
then
        echo "SKIPPED - Script $FILE exists"
else
        cp ${DIR}db ${FILE}
fi

##Execute qa.sh
FILE="/tmp/qa.sh"
if [ -f "$FILE" ]
then
       sh /tmp/qa.sh -m $MEM -r $REP;
else
        echo "ERROR - Script $FILE not found"
fi

exit 0;
