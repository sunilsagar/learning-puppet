#!/bin/sh

SID=`cat /tmp/scripts/*SID`
DATE=`/bin/date +%Y%m%d%H%M%S`
ENV=`cat /tmp/scripts/*ENV`
DIR="/tmp/scripts"

## Check for Customized Sybase SIA Monitoring
ALERT=`/etc/init.d/monitor status |grep -i SYBASE_DB_STATUS`
if [ `echo $ALERT | grep "SYBASE_DB_STATUS"  | wc -l` -gt 0 ]; then
        echo "SKIPPED: Customized Sybase SIA Monitoring is already configured"
	exit 0;
else
	ALERT1=`grep "Commented by setup_syb.sh" /usr/local/monitor/gen_events.cfg`
	if [ `echo $ALERT1 | grep "SYBASE_DB_STATUS"  | wc -l` -gt 0 ]; then
		echo "SKIPPED: Customized Sybase SIA Monitoring is commented"
		echo "INFO: Customized Sybase SIA monitoring is commented to suppress false alerts until system is live"
		echo "INFO: To enable Customized Sybase SIA monitoring run below command on `hostname` as root"
		echo "INFO: sed -i 's/#Commented by setup_syb.sh#//g' /usr/local/monitor/gen_events.cfg"
		echo "INFO: /etc/init.d/monitor config_restart"
	else
	
        echo "Info: Configuring Customized Sybase SIA Monitoring"

	##Setting SID in scripts
	sed -i -e "s/<dataserver>/$SID/g" ${DIR}/custom_SIA.txt
	sed -i -e "s/<dataserver>/$SID/g" ${DIR}/custom_LOG_SIA.txt
	sed -i -e "s/<dataserver>/$SID/g" ${DIR}/custom_DR_SIA.txt
	sed -i -e "s/<dataserver>/$SID/g" ${DIR}/custom_PROD_SIA.txt
	sed -i -e "s/<dataserver>/$SID/g" ${DIR}/custom_NON_PROD_SIA.txt
	sed -i -e 's/${2}/'"$SID/g" ${DIR}/sybase_sia.sh

	##Preparing config file 
	case $ENV in
    		"PR"          ) cat ${DIR}/custom_SIA.txt ${DIR}/custom_PROD_SIA.txt ${DIR}/custom_LOG_SIA.txt > ${DIR}/SIA.cfg  ;;
    		"DR"          ) cat ${DIR}/custom_SIA.txt ${DIR}/custom_DR_SIA.txt ${DIR}/custom_LOG_SIA.txt > ${DIR}/SIA.cfg ;;
    		"NONPR"       ) cat ${DIR}/custom_SIA.txt ${DIR}/custom_NON_PROD_SIA.txt ${DIR}/custom_LOG_SIA.txt > ${DIR}/SIA.cfg ;;
   	 	*             ) exit 1   ;;
	esac

	##Copy SIA scripts
	cp ${DIR}/sybase_sia.tar /usr/local/monitor/sql
	cp ${DIR}/sybase_sia.sh /usr/local/monitor/sql
	##Change ownership of scripts
	chown svvsmon:svvsmon /usr/local/monitor/sql/sybase_sia.sh
	##Change permission of scripts
	chmod 755 /usr/local/monitor/sql/sybase_sia.sh

	##Backup of existing scripts 
	cd /usr/local/monitor/sql
	tar -cvf sybase_`date +"%Y-%m-%d%H%M%S"`.tar sybase
	##Untar SIA scripts
	tar -xvf sybase_sia.tar

	##Precheck Sybase SIA Monitoring
		ALERT=`${DIR}/SIA_ASE_precheck.sh |grep -i SYBASE_DB_STATUS`
		if [ `echo $ALERT | grep "SYBASE_DB_STATUS"  | wc -l` -gt 0 ]; then
        		echo "SUCCESS: Sybase SIA Monitoring Precheck succeed"
			echo "INFO: Adding Sybase related parameters in config file [gen_events.cfg]"

			##Backup config file [gen_events.cfg]
			cp /usr/local/monitor/gen_events.cfg /usr/local/monitor/gen_events.cfg_`date +"%Y-%m-%d%H%M%S"`
			cp /usr/local/monitor/gen_events.cfg /usr/local/monitor/gen_events.cfg.commented
			cp ${DIR}/SIA.cfg /usr/local/monitor/

			##Creating commented SIA sub file
			cd /usr/local/monitor/
			cp SIA.cfg commented.SIA.cfg
			sed -i '1,50 s/^/#Commented by setup_syb.sh#/' commented.SIA.cfg
			sed -i '/SYBLOGB_backuposerrors/r commented.SIA.cfg' /usr/local/monitor/gen_events.cfg.commented
			unix2dos /usr/local/monitor/gen_events.cfg.commented
			
			##Adding sybase related parameters
			sed -i '/SYBLOGB_backuposerrors/r SIA.cfg' /usr/local/monitor/gen_events.cfg
			unix2dos /usr/local/monitor/gen_events.cfg
			##Restart SIA monitoring
			/etc/init.d/monitor config_restart;

					##Check for Customized Sybase SIA Monitoring setup	
					ALERT=`/etc/init.d/monitor status |grep -i SYBASE_DB_STATUS`
					if [ `echo $ALERT | grep "SYBASE_DB_STATUS"  | wc -l` -gt 0 ]; then
        					echo "SUCCESS: Customized Sybase SIA Monitoring succeed"
						/etc/init.d/monitor status
						
						##Commenting SIA monitoring
						cp /usr/local/monitor/gen_events.cfg /usr/local/monitor/gen_events.cfg_`date +"%Y-%m-%d%H%M%S"`
						cp /usr/local/monitor/gen_events.cfg.commented /usr/local/monitor/gen_events.cfg

						##Restart SIA monitoring
						/etc/init.d/monitor config_restart;
						
						##Check for Customized Sybase SIA Monitoring is commented
						ALERT1=`/etc/init.d/monitor status |grep -i SYBASE_DB_STATUS`
						if [ `echo $ALERT1 | grep "SYBASE_DB_STATUS"  | wc -l` -gt 0 ]; then
							echo "FAILED: Commenting Customized Sybase SIA Monitoring failed"
						else 
							echo "SUCCESS: Commenting Customized Sybase SIA Monitoring succeed"
							echo "INFO: Customized Sybase SIA monitoring is commented to suppress false alerts until system is live"
					                echo "INFO: To enable Customized Sybase SIA monitoring run below command on `hostname` as root"
                					echo "INFO: sed -i 's/#Commented by setup_syb.sh#//g' /usr/local/monitor/gen_events.cfg"
                					echo "INFO: /etc/init.d/monitor config_restart"

						fi
						
  					else
        					echo "FAILED: Customized Sybase SIA Monitoring failed. Please continue manual troubleshooting.."; 
						echo "INFO: https://confluence.savvis.net/display/GDE/SIA+Monitoring+for+Sybase+ASE";exit 1;
					fi
  		else
        		echo "FAILED:  Sybase SIA Monitoring Precheck failed. Please continue manual troubleshooting.."
			echo "INFO: https://confluence.savvis.net/display/GDE/SIA+Monitoring+for+Sybase+ASE"; exit 1;

		fi
	fi
fi

exit 0;
