#============================================================================================
# HEADER
#============================================================================================
#%
#% DESCRIPTION
#%    This is a script for performing initial CTL DBA setup
#%
#% OPTIONS
#%    -h, --help                   Print this help
#%    -t, --SetupType              Setup type of script
#%    -i, --IPAdress               Server IP address
#%    -s, --SID                    ASE SID
#%    -p, --PWD                    ASE sa password 
#%    -m, --memory                 ASE memory for max memory/data cache/procedure cache
#%    -r, --report                 ASE configuration report type
#%    -v, --Verbose                Verbose output to screen
#%    -d, --DryRun                 Dry run to test the script
#%
#% EXAMPLES
#%    ${SCRIPT_NAME} -t DEFAULT arg1 arg2
#%
#============================================================================================
#  HISTORY
# ------------|-----|----------------------------------------------|-------------------------
# 02 Mar 2018 | 1.0 | Release                                      | Abhishek
# 12 Mar 2018 | 1.0 | setup_syb.sh - Adjusted DBOBJECT_ONLY check  | Zoltan
#             |     | setup_01.sh  - Corrected Permission issue of | Zoltan
#             |     |                NBU package (Feed script)     | 
#             |     | setup_01.sh  - Adjusted copy scripts issue   | Zoltan
#             |     | setup_03.sh  - Adjusted latest SIA monitor   | Zoltan
#             |     |                variable                      | 
# 14 Mar 2018 | 1.1 | setup_syb.sh - Added QA_SH functionality     | Abhishek
#             |     |                to execute qa.sh (setup_05.sh)| 
# 14 Mar 2018 | 1.1 | setup_01.sh  - Added check for SID user      | Abhishek
#             |     |                to set password expire never  | 
# 27 Mar 2018 | 1.1 | setup_syb.sh - Added -r -m                   | Zoltan
# 11 Apr 2018 | 1.1 | ddl.sql      - Added logic to report failure | Abhishek
#             |     | 	             in DB objects creation        | 
# 10 Jul 2018 |     | setup_03.sh  - Added functionality to        | Abhishek
#             |     |                Comment SIA monitoring        |
# 03 Sep 2018 |     | setup_01.sh  - Added cumulative              | Abhishek
#             |     | setup_02.sh    backup scripts                |
#             |     | crontab.txt                                  |
# 07 Sep 2018 |     | custom_SIA.txt  - Added missing LONG_TRAN    | Abhishek
#             |     | trap                                         |
#             |     |                                              |
#             |     |                                              |
#             |     |                                              |
#============================================================================================
#  DEBUG OPTION
#    set -n  # Uncomment to check your syntax, without execution.
#    set -x  # Uncomment to debug this shell script
#
#============================================================================================
# END_OF_HEADER
#============================================================================================
function help() {

  cat <<EOF

  setup_syb.sh 1.1 14-Mar-2018
  ============================
  Usage     : /software/sybase/setup_syb/setup_syb.sh -h[elp]
            : /software/sybase/setup_syb/setup_syb.sh -t   <FULL|SCRIPT_ONLY|DBOBJECT_ONLY|SIA_ONLY|QA_SH>
                                   		  [-i        Server IP address			      ]
                                                  [-s        ASE SID                                  ]
                                   		  [-p        ASE sa password              	      ]
						  [-e	     Environment <PR|DR|NONPR>	   	      ]
                                                  [-v        Verbose output to screen     	      ]
                                    		  [-d        Dry run to test the script   	      ]
                                    		  [-m        ASE memory settings <SHARED|DEDICATED>   ]
                                    		  [-r        ASE configuration report <FIX|LIST|BOTH> ]

EOF

}


function cleanup() {

  alias rm=rm

  rm -f /var/tmp/setup_syb_${gdatetime} ${tmp}create_dir.log

}

trap cleanup INT TERM EXIT

function fetch_params() {

  while [ "$1" != "" ]; do

    case $1 in

      -h|-help        )  help;                                                                           exit 0      ;;

      -t              )  cmd="$cmd $1"; shift; fType=`echo "$1"      | tr '[:lower:]' '[:upper:]'`; cmd="$cmd $1"    ;;
	  
      -i     	      )  cmd="$cmd $1"; shift; SVR=`echo "$1"`; cmd="$cmd $1"                                        ;;

      -s              )  cmd="$cmd $1"; shift; SID=`echo "$1"`; cmd="$cmd $1"                                        ;;

      -p              )  cmd="$cmd $1"; shift; PWD=`echo "$1"`; cmd="$cmd $1"                                        ;;

      -e              )  cmd="$cmd $1"; shift; ENV=`echo "$1"`; cmd="$cmd $1"                                        ;;

      -v              )  cmd="$cmd $1";        verbose="Y"                                                           ;;

      -d              )  cmd="$cmd $1";        dryrun="Y"                                                            ;;

      -m              )  cmd="$cmd $1"; shift; MEM=`echo "$1"`; cmd="$cmd $1"                                        ;;

      -r              )  cmd="$cmd $1"; shift; REP=`echo "$1"`; cmd="$cmd $1"                                        ;;

      *               )  echo "ERROR: Incorrect argument. See -help for info.";                          exit 1      ;;

    esac

  shift

  done

  if [[ -z $MEM ]]; then MEM=SHARED; fi
  if [[ -z $REP ]]; then REP=FIX; fi
}

fetch_params "$@"


function verbose() {

  # This does not generate additional info in the logfile. Use this to show info to the screen so you know which function you are stuck at.

  [[ $verbose == "Y" ]] && echo >&2 "$@" || echo "$@" >/dev/null

}

 

function check_params() {

  verbose "+ func check_params"

  case $fType in

    "FULL"            ) SetupType="FULL" ;;

    "SCRIPT_ONLY"     ) SetupType="SCRIPT_ONLY"  ;;

    "DBOBJECT_ONLY"   ) SetupType="DBOBJECT_ONLY"  ;;

    "SIA_ONLY"        ) SetupType="SIA_ONLY" ;;

    "QA_SH"           ) SetupType="QA_SH" ;;

    *                 ) echo "ERROR: -t ${fType} is invalid. See -help for info."; exit 1   ;;

  esac

    case $ENV in

    "PR"          ) ENV="PR" ;;

    "DR"  	  ) ENV="DR"  ;;

    "NONPR"       ) ENV="NONPR" ;;

    *             ) echo "ERROR: -e ${ENV} is invalid. See -help for info."; exit 1   ;;

  esac

  case $verbose in

    "Y"|"N" ) verbose=${verbose}       ;;

    *       ) verbose="N"              ;;

  esac

  [[ $dryrun == "Y" ]] && SetupType="DUMMY" 

}

function constants() {

  verbose "+ func constants"

  scriptname="setup_syb.sh"

  scripthome="/software/sybase/setup_syb/"

  gdatetime=`/bin/date +%Y%m%d%H%M%S`

  logdir=$scripthome"log"

  scripts=$scripthome"scripts"

  tmp=$scripthome"tmp"

  logkeep="400" #days

  srvdetails=$scripthome"server_details"

  mailto="Abhishek.Gupta@centurylink.com"


}


function server_test() {

  verbose "+++ func server_test"

  sshadmin ${SVR} exit

  case $? in

    "0" ) log "INFO: Server connection succeed to ${SVR}";return 0      ;;

    "1" ) log "INFO: Unable to connect server ${SVR}";kill;;

  esac

}

function prepare_logfile() {

  logfile="${logdir}/${scriptname}_${SVR}_${gdatetime}_${fType}.log"

  [[ ! -z $db ]] && logfile="${logdir}/${scriptname}_${SVR}_${gdatetime}_${fType}_${db}.log"

  verbose "+ func prepare_logfile"

  [[ ! -d "${logdir}" ]] && mkdir -p "${logdir}"

  touch "${logfile}"

  chmod 644 "${logfile}"

  if [[ $? != 0 ]]; then echo "ERROR: Unable to create ${logfile}"; exit 1; fi

  verbose "- Logfile is ${logfile}"


}

function prepare_logfile_dtl() {

  logfiledtl="${logdir}/${scriptname}_${SVR}_${gdatetime}_${fType}_dtl.log"

  [[ ! -z $db ]] && logfiledtl="${logdir}/${scriptname}_${SVR}_${gdatetime}_${fType}_${db}_dtl.log"

  verbose "+ func prepare_logfile_dtl"

  [[ ! -d "${logdir}" ]] && mkdir -p "${logdir}"

  touch "${logfiledtl}"

  chmod 644 "${logfiledtl}"

  if [[ $? != 0 ]]; then echo "ERROR: Unable to create ${logfiledtl}"; exit 1; fi

  verbose "- Logfiledtl is ${logfiledtl}"

  echo "Check script log after completion"

  echo $logfiledtl


} 

function log() {

  echo  "====================================================================================================================="  >> ${logfile}

  echo >&2 "`/bin/date +%Y%m%d%H%M%S`: $@" >> ${logfile}

  echo  "====================================================================================================================="  >> ${logfile}

}


function die() {

  log  >&2 "$@"

  rc=1

}

 

function kill() {

  log  >&2 "$@"

  log  >&2 "rc=$1"

  exit 1

}

function show_command() {

  verbose "+ func show_command"

  log "${scriptname}${cmd}"

  log ""

}

function logfile_maintenance() {

  # And of course, we need to look after our logs..

  verbose "+ func logfile_maintenance"

  logcnt=`find ${logdir} -name "setup_syb*.log" -type f -mtime +${logkeep} | wc -l`

  case $logcnt in

    "0"  )  verbose "No logfiles to purge beyond ${logkeep} days..."            ;;

     *   )  verbose "Cleaning up logfiles beyond ${logkeep} days..."

          find ${logdir} -name "setup_syb*.log" -type f -mtime +${logkeep} -exec rm {} \; >/dev/null

          case $? in

            "0"  )  log "INFO: Deleted ${logcnt} logfile(s)."               ;;

             *   )  log "INFO: Error encountered during logfile deletion."  ;;

          esac ;;

  esac

  if [ -f ${tmp}/${SVR}.SID ]; then rm ${tmp}/${SVR}.SID; fi

  if [ -f ${tmp}/${SVR}.PWD ]; then rm ${tmp}/${SVR}.PWD; fi

  if [ -f ${tmp}/${SVR}.ENV ]; then rm ${tmp}/${SVR}.ENV; fi

  if [ -f ${tmp}/${SVR}.MEM ]; then rm ${tmp}/${SVR}.MEM; fi

  if [ -f ${tmp}/${SVR}.REP ]; then rm ${tmp}/${SVR}.REP; fi

  if [ -f "$logfiletmp" ]; then rm ${logfiletmp}; fi

}
function check_for_global_error() {

  verbose "+ func check_for_global_error"

  errflag="`grep -i "(rc=1)" ${logfile} | wc -l`"

  if [ ${errflag} != 0 ]; then

    rc=1

    verbose "rc=${rc}"

  else

    rc=0

  fi

}

function display() {

  verbose "+ func display"

  RED='\033[0;31m'

  YELLOW='\033[1;33m'

  NC='\033[0m' # No Color

  GREEN='\033[0;32m'

  while read -r line

  do

  if [ `echo $line | grep "SKIPPED"  | wc -l` -gt 0 ]; then
  
        #echo -e "${YELLOW}SKIPPED${NC} - `echo $line |  cut -d " " -f2-`"
        echo -e "${YELLOW}$line${NC}"
  
  elif

        [ `echo $line |grep -w "FAILED\|ERROR"  | wc -l` -gt 0 ]; then
  
           echo -e "${RED}$line${NC}"

  elif

        [ `echo $line |grep "SUCCESS"  | wc -l` -gt 0 ]; then

           echo -e "${GREEN}$line${NC}"
  
  else
  
          echo $line
  
  fi
  
  sleep 0.25
  
  done < $logfile

}

function setup_syb00() {

  verbose "+ func setup_syb00"

  if [[ $dryrun = "Y" ]]; then log "INFO: This is Dry run"

  else

  echo $SID > ${tmp}/${SVR}.SID;

  chmod 777 ${tmp}/${SVR}.SID;

  echo $PWD > ${tmp}/${SVR}.PWD;

  chmod 777 ${tmp}/${SVR}.PWD;

  echo $ENV > ${tmp}/${SVR}.ENV;

  chmod 777 ${tmp}/${SVR}.ENV;

  echo $MEM > ${tmp}/${SVR}.MEM;

  chmod 777 ${tmp}/${SVR}.MEM;

  echo $REP > ${tmp}/${SVR}.REP;

  chmod 777 ${tmp}/${SVR}.REP;

  sid=`echo $SID |tr '[:upper:]' '[:lower:]'`

  logfiletmp="${tmp}/${scriptname}_${SVR}_${gdatetime}_${fType}.tmp.log"

  log "INFO: Copying scripts to server ${SVR}";

  scpadmin -r ${scripts} ${SVR}:/tmp  > /dev/null 2>&1 |tee $logfiletmp;

  scpadmin ${tmp}/${SVR}.* ${SVR}:/tmp/scripts  > /dev/null 2>&1 |tee -a $logfiletmp;

  cat $logfiletmp >> $logfiledtl;

  cat $logfiletmp |grep -w "SUCCESS\|SKIPPED\|FAILED\|INFO\|ERROR" >> $logfile

  dos2unix $logfiledtl &> /dev/null;

  fi

}

function setup_syb01() {

  verbose "+ func setup_syb01"

  if [[ $dryrun = "Y" ]]; then log "INFO: This is Dry run"
  
  else

  log "INFO: Creating CTL related directories, scripts and Netbackup configuration on server ${SVR}";

  sshadmin ${SVR} -n -q -tt 'sudo su - root -c "sh /tmp/scripts/setup_01.sh" '  2>&1  |tee $logfiletmp;

  cat $logfiletmp >> $logfiledtl;

  cat $logfiletmp |grep -w "SUCCESS\|SKIPPED\|FAILED\|INFO\|ERROR" >> $logfile;

  dos2unix $logfiledtl &> /dev/null;

  fi

}


function setup_syb02() {

  verbose "+ func setup_syb02"

  if [[ $dryrun = "Y" ]]; then log "INFO: This is Dry run"

  else

  log "INFO: Setting SID related profile, crontab and CLT DB objects on server ${SVR}";
  
  sshadmin ${SVR} -n -q -tt "sudo su - syb${sid} -c 'sh /tmp/scripts/setup_02.sh' "  2>&1  |tee $logfiletmp;

  cat $logfiletmp >> $logfiledtl;

  cat $logfiletmp |grep -w "SUCCESS\|SKIPPED\|FAILED\|INFO\|ERROR" >> $logfile

  dos2unix $logfiledtl &> /dev/null;

  fi

}

function setup_syb03() {

  verbose "+ func setup_syb03"

  if [[ $dryrun = "Y" ]]; then log "INFO: This is Dry run"

  else

  log "INFO: Configuring customized sybase SIA monitoring on server ${SVR}";

  sshadmin ${SVR} -n -q -tt 'sudo su - root  -c "sh /tmp/scripts/setup_03.sh" '  2>&1  |tee $logfiletmp;

  cat $logfiletmp >> $logfiledtl;

  cat $logfiletmp |grep -w "SUCCESS\|SKIPPED\|FAILED\|INFO\|ERROR" >> $logfile

  dos2unix $logfiledtl &> /dev/null;

  fi
}


function setup_syb04() {

  verbose "+ func setup_syb04"

  if [[ $dryrun = "Y" ]]; then log "INFO: This is Dry run"

  else

  log "INFO: Removing temporary scripts from server ${SVR}";

  sshadmin ${SVR} -n -q -tt 'sudo su - root -c "ls -lrt /tmp/scripts/; rm -rf /tmp/scripts/;" '  2>&1  |tee $logfiletmp;

  cat $logfiletmp >> $logfiledtl;

  cat $logfiletmp |grep -w "SUCCESS\|SKIPPED\|FAILED\|INFO\|ERROR" >> $logfile;

  dos2unix $logfiledtl &> /dev/null;

  fi

}

function setup_syb05() {

  verbose "+ func setup_syb05"

  if [[ $dryrun = "Y" ]]; then log "INFO: This is Dry run"

  else

  log "INFO: Executing qa.sh on server ${SVR}";

  sshadmin ${SVR} -n -q -tt "sudo su - syb${sid} -c 'sh /tmp/scripts/setup_05.sh' "  2>&1  |tee $logfiletmp;

  cat $logfiletmp >> $logfiledtl;

  cat $logfiletmp |grep -v "SKIPPED" |grep -v "This session is logged" >> $logfile;

  dos2unix $logfiledtl &> /dev/null;

  fi

}

function send_mail() {

  verbose "+ func send_mail"
  
  sed -i 's/$/\t/' $logfile  

  mutt -s "CLT ASE environment setup on ${SVR} : ${SID}  " -a $logfiledtl -- $mailto  < $logfile


}



## fuctions are called below 

check_params

constants

prepare_logfile

prepare_logfile_dtl 

show_command

server_test &> /dev/null

setup_syb00

if [[ $fType == "FULL" ]] || [[ $fType == "SCRIPT_ONLY" ]]   ; then setup_syb01 ; if [ $? != 0 ]; then rc=1; return 1; fi; fi &> /dev/null

if [[ $fType == "FULL" ]] || [[ $fType == "DBOBJECT_ONLY" ]] ; then setup_syb02 ; if [ $? != 0 ]; then rc=1; return 1; fi; fi &> /dev/null

if [[ $fType == "FULL" ]] || [[ $fType == "SIA_ONLY" ]] ; then setup_syb03 ; if [ $? != 0 ]; then rc=1; return 1; fi; fi &> /dev/null

if [[ $fType == "FULL" ]] || [[ $fType == "QA_SH" ]] ; then setup_syb05 ; if [ $? != 0 ]; then rc=1; return 1; fi; fi &> /dev/null

setup_syb04 &> /dev/null

logfile_maintenance

check_for_global_error

trap cleanup INT TERM EXIT

verbose "setup_syb.sh exit $rc"

log     "setup_syb.sh exit $rc"

display

send_mail &> /dev/null

exit $rc
