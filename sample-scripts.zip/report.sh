#!/bin/bash

ls -lrt /software/sybase/setup_syb/log | awk -F'_' '{ print $3 }'|sort |uniq > /software/sybase/setup_syb/tmp/tmp.log.txt

input="/software/sybase/setup_syb/tmp/tmp.log.txt"

cnt=`cat /software/sybase/setup_syb/tmp/tmp.log.txt |wc -l`

cdate=`date +"%m-%d-%y"`

num=0

stn=1

echo "=============================================================="

echo "Number of ASE server build as of $cdate :  $cnt"

echo "=============================================================="
echo "                 Details of Servers                           " 
echo "=============================================================="

while IFS= read -r var

do

num=$((${num}+${stn}))

cat /software/sybase/syb_ips.xls |grep -i $var 2>/dev/null

done < "$input" 

num=0

stn=1


echo "=============================================================="
echo "                Missing server details                        "
echo "=============================================================="

while IFS= read -r var

do

num=$((${num}+${stn}))

SCAN=`cat /software/sybase/syb_ips.xls |grep -i $var 2>/dev/null`

[ -z "$SCAN" ] && echo $var

done < "$input"


echo "=============================================================="

