#!/bin/csh
# SIA pre checks for ASE DBs
set LOG_FILE=SIA.log
set SID=`echo $SYBASE | sed 's/\/sybase\///g'`
$SYBASE/$SYBASE_OCS/bin/isql -S $SID -U ctlbkp -I $SYBASE/interfaces -w 9999 -X -b <<EOF 
`cat /data01/home/sybase/scripts/.ctlbkp_word`
use master
go
`cat /usr/local/monitor/sql/sybase/sybase_db_status.sql`
`cat /usr/local/monitor/sql/sybase/sybase_db_suspect.sql`
`cat /usr/local/monitor/sql/sybase/sybase_data_free_size_mb.sql`
`cat /usr/local/monitor/sql/sybase/sybase_data_free_pct.sql`
`cat /usr/local/monitor/sql/sybase/sybase_log_free_size_mb.sql`
`cat /usr/local/monitor/sql/sybase/sybase_log_free_pct.sql`
`cat /usr/local/monitor/sql/sybase/sybase_blocking.sql`
`cat /usr/local/monitor/sql/sybase/sybase_db_backups.sql`
`cat /usr/local/monitor/sql/sybase/sybase_log_backups.sql`
`cat /usr/local/monitor/sql/sybase/sybase_backup_error.sql`
`cat /usr/local/monitor/sql/sybase/sybase_long_tran.sql`
`cat /usr/local/monitor/sql/sybase/sybase_user_connect_pct.sql`
`cat /usr/local/monitor/sql/sybase/sybase_license.sql`
EOF
/usr/local/monitor/sql/sybase/sybase_bs_server_status.sh $SID
/usr/local/monitor/sql/sybase/sybase_js_server_status.sh $SID
/usr/local/monitor/sql/sybase/sybase_rep_delay.sh $SID $SID

