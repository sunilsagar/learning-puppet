#!/bin/bash
#####################################################
## qa.sh - ASE health checks of the instance running under the unix account executing the script
##
## Checks based on:
##    Sybase ASE QA and Hardening Process https://confluence.savvis.net/display/GDE/Sybase+ASE+QA+and+Hardening+Process
##      1581695 - SYB: Configuration Guide for SAP ASE 16.0Version 42 from Oct 19, 2017 in English
##    EWA reports
##    Solman alerts
##    DBA experience with HEC environment
##
## Modification history
##      Zoltan        2017 Oct 1      create
##      Zoltan        2017 Dec 6      added banner, check for lockscheme for MDA tables
##      Zoltan        2017 Dec 7      deleted extra "missing exec"-s in echo
##      Zoltan        2017 Dec 7      checking for default device should not be master
##      Zoltan        2017 Dec 11     checking for kernel mode, adjusted on optimization goal
##      Zoltan        2017 Dec 18     fixed false positive on solman monitoring switches
##      Zoltan        2017 Dec 19     added version specific checks
##      Zoltan        2017 Dec 29     checking for existence of /tmp/xxx.log, alert if not there (assuming cronjob never executed)
##      Zoltan        01/03/18     number of online engines should be same or 1 less than CPUs on machine
##      Zoltan        01/05/18     fixed numbering in sp_dbrecovery_order
##      Zoltan        01/05/18     ignore 'enforce dump tran sequence'
##      Zoltan        01/05/18     nicer "lock hashtable size" alert
##      Zoltan        01/09/18     added chage
##      Zoltan        01/22/18     checking only local mounts for 15% free, added BO logic, added ignore for lock scheme and net password encryption reqd, added setuser to sp_chgattribute
##      Zoltan        02/07/18     added check for ~/SYBASE.sh
##      Zoltan        02/21/18     changed "net password encryption reqd" alert from !=1 to <1
##	Zoltan		3/8/18	 checks for 'stack size' and 'lock hashtable size' moved to db cc/cce as a DBA must fix 
##	Zoltan		3/22/18	 added cmd line params, -r -m
##	Zoltan		3/27/18	 added connection test
##	Zoltan		4/3/18	 BO checks: added FAIL/PASS mode, reversed logic
##	Zoltan		4/4/18	 bplist hung during H11/H12 QA, skipping since new ASE doe snot have anyting anyway
##	Zoltan		4/4/18	 updated net password encryption reqd from =1 to >= 1
##	Zoltan		4/4/18	 updated chage check with REPORT
##	Zoltan		4/10/18	 bypassed chage check if can't run as sybase user
##	Zoltan		4/16/18	 added -rMUST
##	Zoltan		4/23/18	 rewrote huge pages checks
##	Zoltan		5/02/18	 moved chekcs for "quoted identifier enhancements", "enable xml" to solmane
##	Zoltan		5/04/18	 added checks for "allow nulls by default" of tempdb-s to MUST haves in qa.sh
##	Zoltan		5/07/18	 eliminated false positive db option and sp_dbrecovery_order alert for nonexistent saptempdb
##	Zoltan		5/29/18	 we are running most BOBJ ASE-s with datarows except DSQ, stopped making exception for lock scheme for BOBJ environments
##	Zoltan		7/30/18	 added SAPSR3DB.BC_MID_CON_XX tables to concurrency_opt_threshold checks
##	Zoltan		8/14/18	 added new Version 52 params in "1581695 - SYB: Configuration Guide for SAP ASE 16.0Version 52 from 08.08.2018 in English"
##	Zoltan		8/14/18	 rewrote automatic database expansion, printing cmds to fix
##	Zoltan		8/17/18	 added interfaces file check, ASE should listen on physical hostname, required by (external) solman monitoring
##      Zoltan		08/20/18     updated FIX mode to print cmd to fix when number of online engines off
##      Zoltan		08/29/18     updated online engines check to include SHARED/DEDICATED in calculation, aiming at half or half-1 the CPU-s for threads on SHARED env
##      Zoltan		08/30/18     converted 31 sp_configure params to show current value and dynamic/static with cmd to fix, e.g. "max nesting level"
##      Zoltan		08/30/18     added warning when ASE is not v16
##      Zoltan		10/16/18     added audit check
##      Zoltan		11/09/18     updated tempdb check to accept "unused by any segments" for space allocated on master device
##      Zoltan		11/13/18     updated "only config_history should be audited" to accomodate longer line returned on latest patch levels when config_history auditing turned on
##      Zoltan		11/14/18     added "enable granular permissions" check to allow backing up of sybsecurity db
##      Zoltan		11/14/18     fixed missing quotes for sp_configure "max online engines"
##      Zoltan		12/05/18     continued with converting to report how to fix instead just alert
##      Zoltan		12/05/18     fixed syntax problem with union preventing checks for "number of aux scan descriptors, disk i/o structures, kernel resource memory, size of unilib cache"
##      Zoltan		12/06/18     converted most sp_configure fixes to "--static/dynamic now=.." style 
##      Zoltan		12/06/18     updated missing sia with fiupdated missing sia with fix
##
#####################################################
#

# process optional arguments
while getopts "hm:r:" opt; do
     case $opt in
         h) HELP=1;;
         m) MEMORY=$OPTARG;;
         r) REPORT=$OPTARG;;
     esac
done
shift $((OPTIND-1))

if [[ $HELP ]]; then echo '
-h	help
-r [*FIX|LIST|BOTH|MUST]
	Report type
		FIX	cmds to fix when non compl
		LIST	all checked parameteres as PASS/FAIL (not yet fully implemted, some show fix cmds instead)
		BOTH	combined FIX and LIST output
		MUST	reports must have parameters CSP/TOM-s agreed to retrofit if out of compliance
	Defaults to FIX
-m [*SHARED|DEDICATED]
	Memory configured as % of OS memory for max memory, data cache, procedure cache
		SHARED %-es: 40/20/8
		DEDICATED %-es: 70/35/14 
	Defaults to SHARED
Exmaples
	qa.sh -rLIST -mDEDICATED
	qa.sh -rFIX -mDEDICATED
	qa.sh -rMUST -mSHARED'
exit
fi

if [[ -z $MEMORY ]]; then MEMORY=SHARED; fi
if [[ -z $REPORT ]]; then REPORT=FIX; fi

SID=`echo $SYBASE | cut -d/ -f3`
#SYBUSER=`ps -ef | grep dataserver | grep -v grep | awk '{print $1;}'| sort -u`
SYBUSER=`whoami`

if [[ `ps -eo comm | grep -c dataserver` -lt 1 ]];then echo Not running Sybase dataserver, exiting;exit 0; fi

echo "Running `basename $0` on `hostname`:$SID as $SYBUSER on `date`, Questions? Pls check https://confluence.savvis.net/display/GDE/New+ASE+Setup"

# connection test
MSG=`/tmp/db -q 'select "123"'`
if [[ "$MSG" != *"123"* ]]; then echo "Can't connect to the db."; exit; fi

# check for must have parameters
# these are duplicate checks just to cover MUST
if [[ $REPORT = "MUST" ]]; then
echo Must have settings:
  RESULT=`/tmp/db -q cc $MEMORY | cut -c1-180`; if [[ "$RESULT"xx != "xx" ]]; then echo "$RESULT"; fi
  /tmp/db cpu $MEMORY
  /tmp/db sp | egrep "saptools" | awk '{ if ( $6 < 1024) print "FAIL saptools logspace is "$6"MB < 1GB"; else print "PASS saptools logspace is "$6"MB >= 1GB"; }'
  # db options tempdb and saptempdb
  RESULT=`/tmp/db -s "sp_helpdb tempdb" | egrep 'allow nulls by default'`
  for STR in "allow nulls by default"; do
        if [[ "$RESULT" != *"$STR"* ]]; then echo FAIL tempdb,  \'$STR\' is false; else echo PASS tempdb,  \'$STR\' is true; fi
  done
  RESULT=`/tmp/db -s "sp_helpdb saptempdb" | egrep 'allow nulls by default|specified database does not exist'`
  if [[ "$RESULT" != *"specified database does not exist"* ]]; then
	for STR in "allow nulls by default"; do
	        if [[ "$RESULT" != *"$STR"* ]]; then echo FAIL saptempdb,  \'$STR\' is false; else echo PASS saptempdb,  \'$STR\' is true; fi
	done
  fi
echo Fixes:
  RESULT=`/tmp/db -q cce $MEMORY | cut -c1-180`; if [[ "$RESULT"xx != "xx" ]]; then echo "$RESULT"; fi
  RESULT=`/tmp/db cpu $MEMORY`
  if [[ "$RESULT" =~ "FAIL" ]]; then
        CPUCNT=`echo $RESULT | sed -e 's/.*CPU://' | cut -d',' -f1`
        THRCNT=`echo $RESULT | sed -e 's/.*threads in def pool://'`
        echo -n "We have CPU/Thread $CPUCNT/$THRCNT in $MEMORY env, change threads: "
        if [[ $MEMORY = "DEDICATED" ]]; then CPUCNT=`echo $CPUCNT-1 | bc`; else CPUCNT=`echo $CPUCNT/2-1 | bc`; fi
        if [[ $CPUCNT -le 2 ]]; then CPUCNT=2; fi
        echo -n sp_configure '"max online engines"', `echo $CPUCNT | bc`" --static"
        echo "; alter thread pool syb_default_pool with thread count = "`echo $CPUCNT | bc`" --dynamic"
  fi
  /tmp/db sp | egrep "saptools" | awk '{ if ( $6 < 1024) print "disk resize name = \"saptools_log_001\", size = \"xxxM\"; alter database saptools log on saptools_log_001=\"xxxM\" --saptools logspace is "$6"MB < 1GB" }'
  RESULT=`/tmp/db -s "sp_helpdb tempdb" | egrep 'allow nulls by default'`
  for STR in "allow nulls by default"; do
        if [[ "$RESULT" != *"$STR"* ]]; then echo exec sp_dboption tempdb, \'$STR\',true; else echo -n; fi
  done
  RESULT=`/tmp/db -s "sp_helpdb saptempdb" | egrep 'allow nulls by default|specified database does not exist'`
  if [[ "$RESULT" != *"specified database does not exist"* ]]; then
	for STR in "allow nulls by default"; do
          if [[ "$RESULT" != *"$STR"* ]]; then echo exec sp_dboption saptempdb, \'$STR\',true; else echo -n; fi
	done
  fi
exit
fi

# for version specific checks
VER=`/tmp/db -q v /tmp/db -q v | cut -d/ -f2 | sed 's/\.//g;s/ //g;s/SP//;s/PL//;s/HF*//'`

# warning when ASE is not v16 
if [[ ! $VER =~ "16" ]]; then echo 'Warning, ASE is not ver16, QA is based on "1581695 - SYB: Configuration Guide for SAP ASE 16", for ver15 please verify findings with SAP Note "1749935 - SYB: Configuration Guide for SAP ASE 15.7"'; fi

BO=`/tmp/db -q 'select name from sysdatabases where name like "%AUDIT%"' | wc -l`
if [[ $BO -gt 0 ]]; then echo "We have Business Objects (ASE has AUDIT db), we are checking per BO need."; fi

#if [[ 1 = 2 ]]; then	# exclude ====================

# Setup both .bash_profile or .cshrc for sybase s/w owner
if [[ -z $SYBUSER ]];then
	 echo "ALERT - no ASE user found, may be IQ? $SID"
else
  if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then if [[  -z `grep "source.*SYBASE.csh" ~/.cshrc` || -z `grep "alias syblog" ~/.cshrc`  ]]; then echo "FAIL Setup .cshrc for sybase s/w owner, add \"source /sybase/SID/SYBASE.csh\""; else  echo "PASS Setup .cshrc for sybase s/w owner"; fi; fi
  if [[ $REPORT = "FIX" && (-z `grep "source.*SYBASE.csh" ~/.cshrc` || -z `grep "alias syblog" ~/.cshrc` ) ]]; then echo "Setup .cshrc for sybase s/w owner, add \"source /sybase/SID/SYBASE.csh\""; fi
  if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then if [[ -z `grep "\..*SYBASE.sh" ~/.bash_profile` || -z `grep "alias syblog" ~/.bash_profile` ]]; then echo "FAIL Setup .bash_profile for sybase s/w owner, add \". /sybase/SID/SYBASE.sh"\"; else echo "PASS Setup .bash_profile for sybase s/w owner"; fi; fi
  if [[ $REPORT = "FIX" && (-z `grep "\..*SYBASE.sh" ~/.bash_profile` || -z `grep "alias syblog" ~/.bash_profile`) ]]; then echo "Setup .bash_profile for sybase s/w owner, add \". /sybase/SID/SYBASE.sh\""; fi
fi

# check sybase user password to not expire
USERN=`whoami`
RESULT=`chage -l $USERN 2>&1`
RETVAL=$?
if [[ $RETVAL != 0 ]]; then
	echo "Could not check on sybase user password to not expire, try as root \"chage -l $USERN | grep '^Password.*expires'\", to fix \"chage -M -1 $USERN\""
else
	if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then if [[ -z `chage -l $USERN | grep "^Password expires.*never"` ]]; then echo "FAIL sybase user password expiration, check with: chage -l $USERN, fix as root: chage -M -1 $USERN"; else echo "PASS sybase user password will not expire"; fi; fi
	if [[ $REPORT = "FIX" || $REPORT =  "BOTH" ]]; then if [[ -z `chage -l $USERN | grep "^Password expires.*never"` ]]; then echo "password expiration check: chage -l $USERN, fix as root: chage -M -1 $USERN"; fi; fi
fi

# Create /data01/home/sybase/scripts, /data01/home/sybase/logs directories
if [[ ! -d /data01/home/sybase/scripts ]]; then echo missing /data01/home/sybase/scripts; fi
if [[ ! -d /data01/home/sybase/logs ]]; then echo missing /data01/home/sybase/logs; fi

# Store ctldba and ctlbkp passwords
if [[ ! -f /data01/home/sybase/scripts/.ctldba_word || ! -f /data01/home/sybase/scripts/.ctlbkp_word ]]; then echo missing Store ctldba and ctlbkp passwords; fi

# Check connectivity to db
RETVAL=`/tmp/db "select @@servername"`
if [[ $RETVAL =~ failed || $RETVAL =~ "server name" ]]; then echo "failed Check connectivity to db";echo $RETVAL".";exit 0; fi

# Create svvstools database, procedures, ctldba and ctlbkp users
if [[ `/tmp/db 'select name from master..sysdatabases where name in ("svvstools")' | grep -c svvstools` -ne 1 ]]; then echo missing Create svvstools database; fi
if [[ `/tmp/db 'select name from svvstools..sysobjects where name in ("dump_history")' | grep -c dump_history` -ne 1 ]]; then echo "missing Create svvstools objects (tables,procedures...)"; fi
if [[ `/tmp/db 'select "ctluser "+name from master..syslogins where name in ("ctldba","ctlbkp")' | grep -c ctluser` -lt 2 ]]; then echo missing Create ctldba and ctlbkp users; fi

# Setup DB/LOG Backups to Disk or Tape
if [[ ! `crontab -l | grep -v ^# | grep TLOG_DB_backup` =~ TLOG_DB_backup ]];then echo missing Setup LOG Backups to Disk; fi
if [[ ! `crontab -l | grep -v ^# | grep FULL_DB_backup` =~ FULL_DB_backup && ! -s /data01/home/sybase/scripts/NBU_FULL_DB_backup.sh ]];then echo missing Setup DB Backups; fi
# svvstools..dump_history is configured
if [[ `/tmp/db bak | grep -c $SID` -lt 1 ]]; then echo fail echo svvstools..dump_history is configured; fi
# Update alias bpl with backup policy when provided
DAY=`date --date="-7 day" +%m/%d/%Y`
# hung for 5 min (timeout) during H11/H12 QA, skipping since new ASE does not have anyting anyway
#if [[ -e /usr/openv/netbackup/bin/bplist  && ! `/usr/openv/netbackup/bin/bplist -B -t 7 -R -l -F -s $DAY / 2>&1` =~ $SID ]]; then echo failing bpl does not find any baks in netbackup; fi

# Setup SIA Database Monitoring
if [[ `/etc/init.d/monitor status | grep -c SYBASE` -lt 1 ]];then echo "missing Sybase SIA monitoring, configure it before go live. Check: grep \"SYBASE.*${SID}\" /usr/local/monitor/gen_events.cfg, turn on as root: /etc/init.d/monitor config_restart" ; fi

# SIA Monitoring for Log shipping
if [[ `crontab -l | grep -v ^# | grep rsync` =~ rsync && ! `/etc/init.d/monitor status | grep SYBASE_REPLICATION_DELAY` =~ SYBASE_REPLICATION_DELAY ]];then echo missing SIA Monitoring for Log shipping; fi

# Schedule maintenance/cleanup jobs in cron
if [[ `crontab -l | grep -v ^# | grep -c dbcc` -ne 1 ]];then echo missing Check for Schedule maintenance/cleanup jobs in cron, dbcc; fi
#if [[ `crontab -l | grep -v ^# | grep -c Backup_Clear` -ne 1 ]];then echo missing Check for Schedule maintenance/cleanup jobs in cron, Backup_Clear; fi
if [[ `crontab -l | grep -v ^# | grep -c HistoryFile_Clear` -ne 1 ]];then echo missing Check for Schedule maintenance/cleanup jobs in cron, HistoryFile_Clear; fi
if [[ `crontab -l | grep -v ^# | grep -c ase_log_rotate` -ne 1 ]];then echo missing Check for Schedule maintenance/cleanup jobs in cron, ase_log_rotate; fi
if [[ `crontab -l | grep -v ^# | grep -c backup_verify` -ne 1 ]];then echo missing Check for Schedule maintenance/cleanup jobs in cron, backup_verify; fi
# check for cron job get_sysmon_details
if [[ `crontab -l | grep -v ^# | grep -c get_sysmon_details` -ne 1 ]];then echo missing Check for for Schedule maintenance/cleanup jobs in cron, get_sysmon_details; fi
# are we logging errors?
#if [[ `crontab -l | grep "^[0-9]" | grep -cv ">"` -ne 0 ]];then echo failing Schedule maintenance/cleanup jobs in cron: logging errors in cron job, "`crontab -l | grep "^[0-9]" | grep -v ">"`"; fi
# when deployed is it working?
if [[ ! -e /data01/home/sybase/logs/DBCC/dbcc_cron.log || ( -e /data01/home/sybase/logs/DBCC/dbcc_cron.log && `grep -c MSG /data01/home/sybase/logs/DBCC/dbcc_cron.log` -eq 0 ) ]];then echo failing Schedule maintenance/cleanup jobs in cron, dbcc; fi
if [[ ! -e /tmp/backup_verify.log || ( -e /tmp/backup_verify.log && `grep -ic ^error /tmp/backup_verify.log` -gt 0 ) ]];then echo failing Schedule maintenance/cleanup jobs in cron, backup_verify; fi
# log is 3 lines while runing for 10 min, after that it is 4 lines with "Completed" or log will have "ERROR" when lock file found
if [[ ! -e /tmp/get_sysmon_details.log || ( -e /tmp/get_sysmon_details.log && `grep -ci error /tmp/get_sysmon_details.log` -gt 0 ) ]];then echo failing Schedule maintenance/cleanup jobs in cron, get_sysmon_details; fi
# cron jobs (dbcc script) is using this to define env variables
if [[ ! -f ~/SYBASE.sh ]]; then echo -n "missing ~/SYBASE.sh, you may create it with:";echo "ln -s $SYBASE/SYBASE.sh ~/SYBASE.sh"; fi

#fi	# exclude ====================

# Validate Sybase Version and Dataserver Parameters

if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then RESULT=`/tmp/db -q cc $MEMORY | cut -c1-180`; if [[ "$RESULT"xx != "xx" ]]; then echo "$RESULT"; fi; fi
if [[ $REPORT = "FIX" || $REPORT = "BOTH" ]]; then RESULT=`/tmp/db -q cce $MEMORY | cut -c1-180`; if [[ "$RESULT"xx != "xx" ]]; then echo "$RESULT"; fi; fi

################################
# Database Options and Parameters...based on EWA reports
################################
# spatools log space >= 1GB
if [[ $REPORT = "FIX" || $REPORT = "BOTH" ]]; then /tmp/db sp | egrep "saptools" | awk '{ if ( $6 < 1024) print "disk resize name = \"saptools_log_001\", size = \"xxxM\"; alter database saptools log on saptools_log_001=\"xxxM\" --saptools logspace is "$6"MB < 1GB" }'; fi
if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then /tmp/db sp | egrep "saptools" | awk '{ if ( $6 < 1024) print "FAIL saptools logspace is "$6"MB < 1GB"; else print "PASS saptools logspace is "$6"MB >= 1GB"; }'; fi

# db recovery order
OK=1
RESULT=`/tmp/db -s "sp_dbrecovery_order saptools" | grep saptools`; if [[ $RESULT != *saptools*1*strict* ]]; then if [[ $REPORT = "FIX" || $REPORT = "BOTH" ]]; then echo "exec sp_dbrecovery_order 'saptools', 1, null, strict"; fi; OK=0; fi
# for user db-es
i=1
for DB in `/tmp/db -q 'set nocount on\nselect name from master..sysdatabases where name not in ( "tempdb","master","model","sybmgmtdb","sybpcidb","sybsystemdb","sybsystemprocs","sybsecurity","saptools","svvstools" ) and status3 &256 != 256 and status2 &16 != 16 '`
do
        RESULT=`/tmp/db -s "sp_dbrecovery_order $DB" | grep $DB`; if [[ $RESULT != *$DB*strict* ]]; then i=$((i+1));if [[ $REPORT = "FIX" || $REPORT = "BOTH" ]]; then echo "exec sp_dbrecovery_order '$DB', $i, null, strict"; fi; OK=0; fi
done
RESULT=`/tmp/db -s "sp_dbrecovery_order saptempdb" | egrep "No such database|saptempdb"`
if [[ "$RESULT" != *"No such database"* ]]; then
	if [[ $RESULT != *saptempdb*strict* ]]; then i=$((i+1)); if [[ $REPORT = "FIX" || $REPORT = "BOTH" ]]; then echo "exec sp_dbrecovery_order 'saptempdb', $i, null, strict"; fi; OK=0; fi
fi
# PASS/FAIL decission
if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then if [[ $OK = 1 ]];then echo "PASS db recovery order"; else  echo "FAIL db recovery order";fi; fi

#if [[ 1 = 2 ]]; then	# exclude ====================

# db options for user db-es
# added checks for "allow wide dol rows|allow incremental dumps|no free space acctg|unique auto_identity index|deferred table allocation|deallocate first text page|abort tran on log full|page compression|select into/bulkcopy/pllsort (for SID)|trunc log on chkpt (for SID)" from 1581695 - SYB: Configuration Guide for SAP ASE 16
for DB in `/tmp/db -q 'set nocount on\nselect name from master..sysdatabases where name not in ( "tempdb","master","model","sybmgmtdb","sybpcidb","sybsystemdb","sybsystemprocs","sybsecurity","saptools","svvstools" ) and status3 &256 != 256 and status2 &16 != 16 '`
do
        # echo "db options $DB"
        RESULT=`/tmp/db -s "sp_helpdb $DB" | egrep 'ddl in tran|allow nulls by default|enforce dump tran sequence|full logging for all|deallocate first text page|abort tran on log full|page compression|allow wide dol rows|allow incremental dumps|no free space acctg|unique auto_identity index|deferred table allocation|select into/bulkcopy/pllsort|trunc log on chkpt'`
        for STR in "ddl in tran" "allow nulls by default" "enforce dump tran sequence" "full logging for all" "deallocate first text page" "abort tran on log full" "page compression" "allow wide dol rows" "allow incremental dumps" "deferred table allocation"; do
                if [[ $STR = *"page compression"* ]]; then
                        if [[ "$RESULT" != *"$STR"* ]]; then
                                # page compression is false
                                if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then if [[ $BO -eq 1 ]]; then echo "PASS $DB page compression = false --BO specific, unconfirmed by SAP"; else  echo "FAIL $DB page compression = false"; fi; fi
                                if [[ $REPORT = "FIX"  || $REPORT = "BOTH" ]]; then if [[ $BO -eq 0 ]]; then echo "alter database $DB set compression = page"; fi; fi
                        else
                                # page compression is true
                                if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then if [[ $BO -eq 1 ]]; then echo "FAIL $DB page compression = true --BO specific, unconfirmed by SAP"; else  echo "PASS $DB page compression = true"; fi; fi
                                if [[ $REPORT = "FIX"  || $REPORT = "BOTH" ]]; then if [[ $BO -eq 1 ]]; then echo "alter database $DB set compression = none --BO specific, unconfirmed by SAP"; fi; fi
                        fi
                elif [[ $STR = *"deallocate first text page"* ]]; then
                        if [[ "$RESULT" != *"$STR"* ]]; then
                                # it is false
                                if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then if [[ $BO -eq 1 ]]; then echo "PASS $DB $STR = false --BO specific, KBA 2016149"; else  echo "FAIL $DB $STR = false"; fi; fi
                                if [[ $REPORT = "FIX"  || $REPORT = "BOTH" ]]; then if [[ $BO -eq 0 ]]; then echo "exec sp_dboption $DB, '$STR',true"; fi; fi
                        else
                                # it is is true
                                if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then if [[ $BO -eq 1 ]]; then echo "FAIL $DB $STR = true --BO specific, KBA 2016149"; else  echo "PASS $DB $STR = true"; fi; fi
                                if [[ $REPORT = "FIX"  || $REPORT = "BOTH" ]]; then if [[ $BO -eq 1 ]]; then echo "exec sp_dboption $DB, '$STR',false --BO specific, KBA 2016149"; fi; fi
                        fi
                elif [[ $STR = *"enforce dump tran sequence"* ]]; then
                        if [[ "$RESULT" != *"$STR"* ]]; then
                                # it is false
                                if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then if [[ $BO -eq 1 ]]; then echo "PASS $DB $STR = false --BO specific, KBA 2467784"; else  echo "FAIL $DB $STR = false"; fi; fi
                                if [[ $REPORT = "FIX"  || $REPORT = "BOTH" ]]; then if [[ $BO -eq 0 ]]; then echo "exec sp_dboption $DB, '$STR',true"; fi; fi
                        else
                                # it is true
                                if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then if [[ $BO -eq 1 ]]; then echo "FAIL $DB $STR = true --BO specific, KBA 2467784"; else  echo "PASS $DB $STR = true"; fi; fi
                                if [[ $REPORT = "FIX"  || $REPORT = "BOTH" ]]; then if [[ $BO -eq 1 ]]; then echo "exec sp_dboption $DB, '$STR',false --BO specific, KBA 2467784"; fi; fi
                        fi
                elif [[ "$RESULT" != *"$STR"* ]]; then
                        # these should be true
                        if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then echo "FAIL $DB $STR = false"; fi
                        if [[ $REPORT = "FIX"  || $REPORT = "BOTH" ]]; then echo exec sp_dboption $DB, \'$STR\',true; fi
                else
                        if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then echo "PASS $DB $STR = true"; fi
                fi
        done
        for STR in "no free space acctg" "unique auto_identity index" "select into/bulkcopy/pllsort" "trunc log on chkpt"; do
                # these should be false
                if [[ "$RESULT" = *"$STR"* ]]; then
                        if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then echo "FAIL $DB $STR = true"; fi
                        if [[ $REPORT = "FIX"  || $REPORT = "BOTH" ]]; then echo exec sp_dboption $DB, \'$STR\',false; fi
                else
                        if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then echo "PASS $DB $STR = false"; fi
                fi
        done
done

# db options saptools
RESULT=`/tmp/db -s "sp_helpdb saptools" | egrep 'ddl in tran|allow nulls by default|trunc log on chkpt|allow wide dol rows|allow incremental dumps|no free space acctg|unique auto_identity index|abort tran on log full'`
for STR in "ddl in tran" "allow nulls by default" "trunc log on chkpt" "allow wide dol rows" "allow incremental dumps" "abort tran on log full"; do
	if [[ "$RESULT" != *"$STR"* ]]; then echo exec sp_dboption saptools, \'$STR\',true; else echo -n; fi
done
for STR in "no free space acctg" "unique auto_identity index"; do
	if [[ "$RESULT" = *"$STR"* ]]; then echo exec sp_dboption saptools, \'$STR\',false; else echo -n; fi
done

# db options tempdb
RESULT=`/tmp/db -s "sp_helpdb tempdb" | egrep 'ddl in tran|allow nulls by default|select into/bulkcopy/pllsort|allow wide dol rows'`
for STR in "ddl in tran" "allow nulls by default" "select into/bulkcopy/pllsort" "allow wide dol rows"; do
	if [[ "$RESULT" != *"$STR"* ]]; then echo exec sp_dboption tempdb,  \'$STR\',true; else echo -n; fi
done

# db options saptempdb
RESULT=`/tmp/db -s "sp_helpdb saptempdb" | egrep 'specified database does not exist|ddl in tran|allow nulls by default|select into/bulkcopy/pllsort|allow wide dol rows'`
if [[ "$RESULT" != *"specified database does not exist"* ]]; then
for STR in "ddl in tran" "allow nulls by default" "select into/bulkcopy/pllsort" "allow wide dol rows"; do
        if [[ "$RESULT" != *"$STR"* ]]; then echo exec sp_dboption saptempdb, \'$STR\',true; else echo -n; fi
done
fi

# db options sybsystemdb
RESULT=`/tmp/db -s "sp_helpdb tempdb" | egrep 'trunc log on chkpt'`
for STR in "trunc log on chkpt"
do
if [[ "$RESULT" != *"$STR"* ]]; then echo exec sp_dboption sybsystemdb, \'$STR\',true; else echo -n; fi
done

#if [[ 1 = 2 ]]; then	# exclude ====================

# File system mount points -  Ensure min. 15% free space
if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then df -lP | grep -v Filesystem | awk '{ gsub("%","");if ( $5 >= 85 ) printf "FAIL"; else  printf "PASS"; print " Ensure min. 15% free space, used "$5"%\t"$6; }'; fi
if [[ $REPORT = "FIX" ]]; then df -lP | grep -v Filesystem | awk '{ gsub("%","");if ( $5 >= 85 ) print "Ensure min. 15% free space, used "$5"%\t"$6; }'; fi

# Data and Log devices - Ensure min. 15% free space.
if [[ `/tmp/db 'select name from master..sysdatabases where name in ("saptools")' | grep -c saptools` -ne 1 ]]; then echo missing Create saptools database; fi

# Data and Log devices - Ensure min. 15% free space.
if [[ `/tmp/db sp | grep '^ [a-zA-Z]' | awk ' {if ( $5 < 15 || ($9 < 15 && $9 != 0)) print }' | wc -l` -ne 0 ]]; then echo failed Data and Log devices - Ensure min. 15% free space; fi

# motd...skipped for now, can't decide if needed (on DR it is)
#if [[ ! -s /etc/motd ]]; then echo /etc/motd is empty; else echo "/etc/motd: `cat /etc/motd | tr '\n' ';' | cut -c1-80`..."; fi

# automatic database expansion
# server wide
RESULT=`/tmp/db -qs "sp_dbextend list" | egrep 'database.*enabled|device.*enabled'`
if [[ ! -z $RESULT ]]; then echo -n " --ignore, automatic database expansion, db/device : "; /tmp/db -qs "sp_dbextend list" | \
	awk -v q="'" '{ if (/database.*enabled/) printf "exec sp_dbextend "q"clear"q","q"database"q","q$2q"; "; else if (/device.*enabled/) printf "exec sp_dbextend "q"clear"q","q"device"q","q$2q"; " }END{printf "\n"}'; fi
# for user db-es
for DB in `/tmp/db -q 'set nocount on\nselect name from master..sysdatabases where name not in ( "tempdb","master","model","sybmgmtdb","sybpcidb","sybsystemdb","sybsystemprocs","sybsecurity","saptools","svvstools" ) and status3 &256 != 256 and status2 &16 != 16 order by name'`
do
        RESULT=`/tmp/db -qs "use $DB\ngo\nsp_dbextend list" | egrep "database.*$DB.*enabled"`
	if [[ ! -z $RESULT ]]; then echo -n " --ignore, automatic database expansion, segment   : "; /tmp/db -qs "use $DB\ngo\nsp_dbextend list" | egrep "database.*$DB.*enabled" | \
		awk -v q="'" -v sid=$SID '{ printf "use "sid"; exec sp_dbextend "q"clear"q","q"database"q","q$2q"; " }END{printf "\n"}'; fi
        RESULT=`/tmp/db -qs "use $DB\ngo\nset proc_return_status off\ngo\nset nocount on\ngo\nsp_helpthreshold" | grep -v logsegment`
	if [[ ! -z $RESULT ]]; then echo -n " --ignore, automatic database expansion, threshold : "; /tmp/db -qs "use $DB\ngo\nset proc_return_status off\ngo\nset nocount on\ngo\nsp_helpthreshold" | grep -v logsegment | \
		awk -v q="'" -v sid=$SID '{ printf "use "sid"; exec sp_dropthreshold "sid","q$1q","$2"; " }END{printf "\n"}'; fi
done

# duplicate, already covered in section "db options for user db-es"
# 'trunc log on chkpt' for ALL user db-es should be off... we think. $SID is covered already
#for DB in `/tmp/db -q 'set nocount on\nselect name from master..sysdatabases where name not in ( "tempdb","master","model","sybmgmtdb","sybpcidb","sybsystemdb","sybsystemprocs","sybsecurity","saptools","svvstools",@@servername ) and status3 &256 != 256 and status2 &16 != 16 order by name'`
#do
#if [[ ! -z "`/tmp/db -s "sp_helpdb $DB" | grep 'trunc log on chkpt'`" ]]; then echo "failed,pls fix: exec sp_dboption $DB,'trunc log on chkpt',false"; fi
#done

# do we have Solman monitoring set up?
if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then if [[ -z "`/tmp/db -s "select name from saptools..sysobjects where name like 'DBH_STG_SYSLOAD'" | grep 'DBH_STG_SYSLOAD'`" ]]; then echo "FAIL Solman monitoring is not set up"; else echo "PASS Solman monitoring is set up"; fi; fi
if [[ $REPORT = "FIX" || $REPORT = "BOTH" ]]; then if [[ -z "`/tmp/db -s "select name from saptools..sysobjects where name like 'DBH_STG_SYSLOAD'" | grep 'DBH_STG_SYSLOAD'`" ]]; then echo "Solman monitoring is not set up"; fi; fi

# do we have ATM set up?
if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then if [[ -z "`/tmp/db -s "select name from saptools..sysobjects where name like 'ATM_CONFIG'" | grep 'ATM_CONFIG'`" ]]; then echo "FAIL ATM is not set up"; else echo "PASS ATM is set up"; fi; fi
if [[ $REPORT = "FIX" && -z "`/tmp/db -s "select name from saptools..sysobjects where name like 'ATM_CONFIG'" | grep 'ATM_CONFIG'`" ]]; then echo "ATM is not set up"; fi

# check for sa locked, commented out based on 12/6 call
#if [[ -z "`/tmp/db sp_displaylogin sa | grep "Locked: YES"`" ]]; then echo "failing, sa is unlocked, pls run: sp_locklogin sa, 'lock'"; fi

# check for Solman monitor user MONITOR_XXX
if [[ `/tmp/db sp_displaylogin MONITOR_$SID | grep -c MONITOR_$SID` -eq 0 ]]; then echo "missing, Solman monitoring user MONITOR_$SID, good read https://confluence.savvis.net/display/GDE/Create+Solman+monitoring+account"; fi

# check if tempdb uses master device for log segment
if [[ `/tmp/db -s sp_helpdb tempdb | egrep "master" | egrep -c "data only||unused by any segments"` -eq 0 ]]; then echo "failing, tempdb uses master device for log segment"; fi

# solman monitoring switches
#if [[ "X`/tmp/db -q solmane`" != "X" ]]; then echo "failing, solman monitoring switches:"; echo "`/tmp/db -q solmane`"; fi
if [[ "X`/tmp/db -q solmane`" != "X" ]]; then echo "`/tmp/db -q solmane`"; fi

# sp_dump_history check
if [[ ! `/tmp/db bak3` =~ "DUMP" ]]; then echo "failing, sp_dump_history check"; fi

# master dev check (shold only have master model sybsystemdb tempdb)
if [[ ! `/tmp/db -s spd | grep master | cut -f1 | sort -u | awk '{printf $1}'` =~ "mastermodelsybsystemdbtempdb" ]]; then echo "failing, master dev check, shold only have db-es master model sybsystemdb tempdb"; fi

# for DEDICATED env number of online engines should be same or 1 less than CPUs on machine, for SHARED half or half-1 of CPUs
RESULT=`/tmp/db cpu $MEMORY`
if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then echo "$RESULT"; fi
if [[ ( $REPORT = "FIX" || $REPORT = "BOTH" ) &&  "$RESULT" =~ "FAIL" ]]; then
        CPUCNT=`echo $RESULT | sed -e 's/.*CPU://' | cut -d',' -f1`
        THRCNT=`echo $RESULT | sed -e 's/.*threads in def pool://'`
        echo -n "We have CPU/Thread $CPUCNT/$THRCNT in $MEMORY env, change threads: "
        if [[ $MEMORY = "DEDICATED" ]]; then CPUCNT=`echo $CPUCNT-1 | bc`; else CPUCNT=`echo $CPUCNT/2-1 | bc`; fi
        if [[ $CPUCNT -le 2 ]]; then CPUCNT=2; fi
        echo -n sp_configure '"max online engines"', `echo $CPUCNT | bc`" --static"
        echo "; alter thread pool syb_default_pool with thread count = "`echo $CPUCNT | bc`" --dynamic"
fi

# check for ASE with huge pages
PID=`ps -eo pid,comm,user | grep dataserver | grep $SYBUSER | awk '{print $1}'`
#
# transparent_hugepage should be [never]
if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then 
	if [[ ! `cat /sys/kernel/mm/transparent_hugepage/enabled` =~ "[never]" ]]; then echo -n "FAIL transparent_hugepage is set to: "
        else echo -n "PASS transparent_hugepage is set to: "; fi; 
        echo `cat /sys/kernel/mm/transparent_hugepage/enabled`
fi
if [[ $REPORT = "FIX" || $REPORT = "BOTH" ]]; then if [[ ! `cat /sys/kernel/mm/transparent_hugepage/enabled` =~ "[never]" ]]; then
        echo "transparent_hugepage is not configured for [never], ask unix team to fix, requires OS restart, it is now: "`cat /sys/kernel/mm/transparent_hugepage/enabled`; fi; fi
#
# ASE should run with hugepages
if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then 
	if [[ ! "`grep huge /proc/$PID/numa_maps 2>/dev/null`" =~ 'dirty' ]]; then
	        echo "FAIL ASE $HOST/$SID is running with regular pages, https://confluence.savvis.net/display/GDE/Enable+Huge+Pages+for+ASE+DB, "`/tmp/db -q 'set nocount on\nselect top 1 "it is using "+ cast(scc.value*2/1024 as varchar) + "MB, configure with vm.nr_hugepages=" + cast( ((ROUND((scc.value*2/1024)/256,0)+1)*256*1024/2048) as varchar) from sysconfigures sc, syscurconfigs scc where sc.name like "total%memory" and sc.config = scc.config order by scc.value desc'`
        else echo "PASS ASE runs with huge pages"; fi; fi
if [[ $REPORT = "FIX" || $REPORT = "BOTH" ]]; then if [[ ! "`grep huge /proc/$PID/numa_maps 2>/dev/null`" =~ 'dirty' ]]; then
        echo "ASE $HOST/$SID is running with regular pages, https://confluence.savvis.net/display/GDE/Enable+Huge+Pages+for+ASE+DB, "`/tmp/db -q 'set nocount on\nselect top 1 "it is using "+ cast(scc.value*2/1024 as varchar) + "MB, configure with vm.nr_hugepages=" + cast( ((ROUND((scc.value*2/1024)/256,0)+1)*256*1024/2048) as varchar) from sysconfigures sc, syscurconfigs scc where sc.name like "total%memory" and sc.config = scc.config order by scc.value desc'`; fi; fi

#fi	# exclude ====================

####################
# START check settings in 1581695 - SYB: Configuration Guide for SAP ASE 16.0
####################

: <<'end_long_comment'
The individual parameters of this functionality group are:
> enable inline default sharing = 1 [REQ]
> select for update = 1 [REQ]
> enable permissive unicode = 1 [REQ]
> quoted identifier enhancements = 1 [REQ] # listed in KBA 1593987, moved to solmane
> streamlined dynamic SQL = 1 [REQ]
> suppress js max task message = 1 [REQ]
end_long_comment
SQL='set nocount on
        select cast(col1 as varchar(80)) The_Fix from (
        select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable inline default sharing" and scc.value   !=       1
        union
        select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="select for update" and scc.value   !=       1
	union
        select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable permissive unicode" and scc.value   !=       1
	union
        select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="streamlined dynamic SQL" and scc.value   !=       1
	union
        select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="suppress js max task message" and scc.value   !=       1
        ) a'
/tmp/db -q "$SQL"

#It is required that you use the threaded kernel mode:
#> kernel mode = threaded [REQ]
SQL='set nocount on select cast( "exec sp_configure """+sc.name+""",threaded"+char(9)+"--"+scc.type+" now="+ltrim(scc.value2) as varchar(80) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="kernel mode" and scc.value2  != "threaded"'; /tmp/db -q "$SQL"

# some of the params in this doc are already checked with "db cce", skiping those
: <<'end_long_comment'
The data collection framework used to collect monitoring information for the DBA Cockpit and to schedule recurring DBA tasks needs the SAP Sybase ASE job scheduler in order to be enabled.
> enable job scheduler = 1 [REQ]
> job scheduler interval <= 60 [REQ]
> job scheduler tasks >= 2 [REQ]
> js job output width >= 1024 [REQ]	
For the purpose of database monitoring and to ensure supportability of the database, it is necessary that you set the following parameters:
> enable monitoring = 1 [REQ]
> enable stmt cache monitoring = 1 [REQ]
> errorlog pipe active = 1 [REQ]
> deadlock pipe active = 1 [REQ]
> sql text pipe active = 0 [REC]
> plan text pipe active = 0 [REC]
> lock timeout pipe active = 1 [REQ]
> per object statistics active = 1 [REQ]
> statement statistics active = 1 [REQ]
> SQL batch capture = 1 [REQ]
> wait event timing = 1 [REQ]
> object lockwait timing = 1 [REQ]
> process wait events = 1 [REC]
> enable metrics capture = 0 [REC]
> execution time monitoring = 1 [REQ]
> enable cis = 1 [REQ]
> cis connect timeout = 30 [REQ]
The statement pipe is not needed for SAP monitoring and it is recommended that you keep it switched off for performance reasons:
> statement pipe active = 0 [REC]
For the size of pipes that store messages used by the data collection framework, it is necessary that you set this to at least 500:
> errorlog pipe max messages >= 500 [REQ]
> deadlock pipe max messages >= 500 [REQ]
> statement pipe max messages = 0 [REQ]
> sql text pipe max messages = 0 [REC]
> plan text pipe max messages = 0 [REC]
> lock timeout pipe max messages >= 500 [REQ]
> max SQL text monitored >= 2048 [REQ]
end_long_comment

#SAP applications rely on strong password encryption.
#> FIPS login password encryption = 1[REQ]
SQL='set nocount on select cast( "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(scc.value) as varchar(80) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="FIPS login password encryption" and scc.value  != 1'; /tmp/db -q "$SQL"

#We recommend forcing the database not to send unencrypted passwords over the network:
#> net password encryption reqd >= 1 [REC]
PARAM="net password encryption reqd"
SQL='select ltrim(str(scc.value)) from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="'$PARAM'"'
RESULT=`/tmp/db -q "\`echo "$SQL"\`"`
# should be >=1
if [[ $RESULT -ge 1 ]]; then
        if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then if [[ $BO -eq 1 ]]; then echo "FAIL $PARAM = $RESULT --BO specific, KBA 2273134"; else  echo "PASS $PARAM = $RESULT"; fi; fi
        if [[ $REPORT = "FIX"  || $REPORT = "BOTH" ]]; then if [[ $BO -eq 1 ]]; then echo exec sp_configure \"$PARAM\",0 --dynamic now=$RESULT, BO specific, KBA 2273134; fi; fi
else
        if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then if [[ $BO -eq 1 ]]; then echo "PASS $PARAM = $RESULT --BO specific, KBA 2273134"; else  echo "FAIL $PARAM = $RESULT"; fi; fi
        if [[ $REPORT = "FIX"  || $REPORT = "BOTH" ]]; then if [[ $BO -eq 0 ]]; then echo exec sp_configure \"$PARAM\",1 --dynamic now=$RESULT, BO specific, KBA 2273134; fi; fi
fi

#The compression feature of SAP Sybase ASE is always used for SAP applications. Therefore, compression has to be enabled for the database server:
#> enable compression = 1 [REQ]
SQL='set nocount on select cast( "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(scc.value) as varchar(80) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable compression" and scc.value  != 1'
/tmp/db -q "$SQL"

#> compression info pool size >= 32768 [REQ]
SQL='set nocount on select cast( "exec sp_configure """+sc.name+""",32768"+char(9)+"--"+scc.type+" now="+ltrim(scc.value) as varchar(80) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="compression info pool size" and scc.value  < 32768'; /tmp/db -q "$SQL"

#XML support is needed to run SAP applications:
#> enable xml = 1 [REQ]
# listed in KBA 1593987, moved to solmane
#if [[ `/tmp/db -q 'select value from master..sysconfigures where name in ("enable xml")'` -ne 1 ]]; then echo exec sp_configure \"enable xml\",1; fi

#For Unicode, the following settings are required:
SQL='set nocount on select cast( "exec sp_configure """+sc.name+""",0"+char(9)+"--"+scc.type+" now="+ltrim(scc.value) as varchar(80) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable unicode normalization" and scc.value  != 0'; /tmp/db -q "$SQL"
SQL='set nocount on select cast( "exec sp_configure """+sc.name+""",0"+char(9)+"--"+scc.type+" now="+ltrim(scc.value) as varchar(80) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable surrogate processing" and scc.value  != 0'; /tmp/db -q "$SQL"
SQL='set nocount on select cast( "exec sp_configure """+sc.name+""",0"+char(9)+"--"+scc.type+" now="+ltrim(scc.value) as varchar(80) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="disable character set conversions" and scc.value  != 0'; /tmp/db -q "$SQL"
SQL='set nocount on select cast( "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(scc.value) as varchar(80) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable enable unicode conversions" and scc.value  != 1'; /tmp/db -q "$SQL"

#Default character set settings:
#> default character set id = 190 [REQ]
#> default language id = 0 [REQ]
SQL='set nocount on select cast( "--ignore (more research needed), exec sp_configure """+sc.name+""",190"+char(9)+"--"+scc.type+" now="+ltrim(scc.value) as varchar(100) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="default character set id" and scc.value  != 190'; /tmp/db -q "$SQL"
SQL='set nocount on select cast( "--ignore (more research needed), exec sp_configure """+sc.name+""",0"+char(9)+"--"+scc.type+" now="+ltrim(scc.value) as varchar(100) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="default language id" and scc.value  != 0'; /tmp/db -q "$SQL"

#already covered in "db cce"
#The maximum job output needs to be set to the maximum value allowed by ASE:
#> maximum job output <= 16777216 [REQ]
#> maximum job output >= 16384 [REQ]
#VAL=`/tmp/db -q 'select value from master..sysconfigures where name in ("maximum job output")'`
#if (( $VAL < 16384 || $VAL > 16777216 )); then echo exec sp_configure \"maximum job output\",16777216; fi

#A size of at least 512 MB memory is recommended for the procedure cache. Depending on your system's workload and the available memory, this may need to be increased:
#> procedure cache size >= 262144 [REC]		part of DBA must fix params, moved to db cc/cce
#if [[ `/tmp/db -q 'select scc.value from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and sc.name = "procedure cache size" and type="dynamic"'` -lt 262144 ]]; then echo exec sp_configure \"procedure cache size\",262144; fi

#The statement cache needs to have at least 100 MB:
#> statement cache size >= 51200 [REQ]	part of DBA must fix params, moved to db cc/cce
#if (( `/tmp/db -q 'select value from master..sysconfigures where name in ("statement cache size")'` < 51200 )); then echo exec sp_configure \"statement cache size\",51200; fi

#For running SAP systems on SAP Sybase ASE, you are required to set row level locking:
#> lock scheme = datarows [REQ]
PARAM="lock scheme"
SQL='select cast(scc.value2 as char(10)) from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="'$PARAM'"'
RESULT=`/tmp/db -q "\`echo "$SQL"\`"`
# should be datarows
if [[ "$RESULT" = *"datarows"* ]]; then
        # should be datarows
        if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then echo "PASS $PARAM = $RESULT"; fi
else
        if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then echo FAIL $PARAM = $RESULT; fi
        if [[ $REPORT = "FIX"  || $REPORT = "BOTH" ]]; then echo exec sp_configure \"$PARAM\",0,datarows --dynamic now=$RESULT; fi
fi

#This parameter is required for the dictionary (DDIC):
#> select on syscomments.text = 1 [REQ]
SQL='set nocount on select cast( "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(scc.value) as varchar(80) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="select on syscomments" and scc.value  != 1'; /tmp/db -q "$SQL"

#It is recommended that you do not use lock promotion for SAP applications:
#> row lock promotion HWM = 2147483647 [REC]
#> row lock promotion LWM >= 2147483646 [REC]
SQL='set nocount on select cast( "exec sp_configure """+sc.name+""",2147483647"+char(9)+"--"+scc.type+" now="+ltrim(scc.value) as varchar(100) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="row lock promotion HWM" and scc.value  != 2147483647'; /tmp/db -q "$SQL"
SQL='set nocount on select cast( "exec sp_configure """+sc.name+""",2147483646"+char(9)+"--"+scc.type+" now="+ltrim(scc.value) as varchar(100) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="row lock promotion LWM" and scc.value  < 2147483646'; /tmp/db -q "$SQL"

#The number of locks should be at least 1000000. Depending on your workload, a higher number of locks may be required:
#> number of locks >= 1000000 [REC]	duplicate, already in db cce
#> lock wait period = 1800 [REC]
#> lock spinlock ratio = 40 [REC]
#if [[ `/tmp/db -q 'select value from master..sysconfigures where name in ("number of locks")'` -lt 1000000 ]]; then echo exec sp_configure \"number of locks\",1000000; fi
SQL='set nocount on select cast( "exec sp_configure """+sc.name+""",1800"+char(9)+"--"+scc.type+" now="+str(scc.value) as varchar(100) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="lock wait period" and scc.value  != 1800'; /tmp/db -q "$SQL"
SQL='set nocount on select cast( "exec sp_configure """+sc.name+""",40"+char(9)+"--"+scc.type+" now="+ltrim(scc.value) as varchar(100) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="lock spinlock ratio" and scc.value  != 40'; /tmp/db -q "$SQL"

# part of DBA must fix params, moved to db cc/cce
#You need to set the lock hash table size according to the number of locks. It is recommended to set the lock hash table size to at least the number of locks in full millions times 8192. The value of this parameter should be a power of two, otherwise ASE will round it up to the next power of two and show a warning message.
#> lock hashtable size >= @number of locks@ / 1000000 * 8192 [REC]
#> lock hashtable size >= 8192 [REQ]
#VALPROPSED=`/tmp/db -q 'select (round(scc.value / 1000000,0)+1) * 8192 "Proposed_lock_hashtable" from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and sc.name in ("number of locks")' | awk '{print $1}'`
#if [[ $VALPROPSED -lt 8192 ]]; then $VALPROPSED=8192; fi
#SQL='select cast("exec sp_configure """+sc.name+""",'$VALPROPSED'"+char(9)+"--"+scc.type+", now="+ltrim(str(scc.value)) as varchar(80)) col1 from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="lock hashtable size" and scc.value   < '$VALPROPSED
#/tmp/db -q "`echo "$SQL"`"

: <<'end_long_comment'
The following settings affect memory usage of SAP Sybase ASE. The values given are required to allow SAP applications to run on Sybase ASE:
> number of open objects >= 40000 [REQ]		duplicate, covered in db cce with 60000
> number of open indexes >= 30000 [REQ]		duplicate, covered in db cce with 60000
> number of open partitions >= 30000 [REQ]	duplicate, covered in db cce with 50000
> number of alarms >= 1000 [REQ]		duplicate, covered in db cce with 1000
> number of aux scan descriptors >= 1024 [REQ]
> number of devices >= 200 [REQ] 		duplicate, covered in db cce with 200
> disk i/o structures >= 4096 [REQ]
> kernel resource memory >= 32768 [REQ]
> heap memory per user >= 49152 [REQ]		duplicate, covered in db cce with 49152
> size of unilib cache >= 512000 [REC]
end_long_comment
SQL='set nocount on
	select cast(col1 as varchar(80)) The_Fix from (
	select "exec sp_configure """+sc.name+""",1024"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="number of aux scan descriptors" and scc.value   <       1024
	union
	select "exec sp_configure """+sc.name+""",4096"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="disk i/o structures" and scc.value   <       4096
        union
	select "exec sp_configure """+sc.name+""",32768"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="kernel resource memory" and scc.value   <       32768
        union
	select "exec sp_configure """+sc.name+""",512000"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="size of unilib cache" and scc.value   <       512000
	) a'
/tmp/db -q "$SQL"

# number of user connections: already covered in "db cce"
#The number of user connections needs to be adapted to your system size. For NetWeaver ABAP, recommendation is [total number of work processes * 4]. For NetWeaver Java, recommendation is [number of server nodes * 50]. In both cases, use a minimum of 200 user connections.
#> number of user connections >= 200 [REC]

#CPU grace time has to be set to 1000:
#> cpu grace time = 1000 [REC]
SQL='set nocount on select cast( "exec sp_configure """+sc.name+""",1000"+char(9)+"--"+scc.type+" now="+ltrim(scc.value) as varchar(100) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="cpu grace time" and scc.value  != 1000'; /tmp/db -q "$SQL"

# network stuff: already covered in "db cce"
#The following settings are required for network communication:
#> max network packet size = 16384 [REQ]
#> default network packet size = 16384 [REQ]
#> additional network memory >= 10485760 [REQ]

#> send doneinproc tokens = 1 [REQ]	added with Version 52
SQL='set nocount on
select cast(col1 as varchar(80)) The_Fix from (
select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="send doneinproc tokens" and scc.value   !=       1
) a'
/tmp/db -q "$SQL"

# network stuff: already covered in "db cce"
#For the recovery interval, please note that the parameter name is misleading as the interval is based on an estimate of 1000 pages per minute, whereas the real rate is approximately 10x higher. The value given here represents roughly a 5-minute recovery window:
#> recovery interval in minutes <= 60 [REC]
#> print recovery information = 1 [REC]
SQL='set nocount on select cast( "exec sp_configure """+sc.name+""",60"+char(9)+"--"+scc.type+" now="+ltrim(scc.value) as varchar(80) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="recovery interval in minutes" and scc.value  > 60'; /tmp/db -q "$SQL"
SQL='set nocount on select cast( "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(scc.value) as varchar(80) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="print recovery information" and scc.value  != 1'; /tmp/db -q "$SQL"

: <<'end_long_comment'
Additional settings that are requirements or recommended for SAP on Sybase ASE.
> disable varbinary truncation = 1 [REQ]
> allocate max shared memory = 1 [REC]
> optimizer level = ase_current [REQ]
> enable literal autoparam = 0 [REQ]
> enable semantic partitioning = 1 [REQ]
> permission cache entries >= 128 [REC]
> enable java = 0 [REC]
> deadlock checking period >= 500 [REC]
> read committed with lock = 0 [REQ]
> auto query tuning = 0 [REQ]
> max query parallel degree = 1 [REQ]
end_long_comment
SQL='set nocount on
	select cast(col1 as varchar(100)) The_Fix from (
	select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="disable varbinary truncation" and scc.value   !=       1
	union
	select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="allocate max shared memory" and scc.value   !=       1
	union
	select "exec sp_configure """+sc.name+""",999998"+char(9)+"--"+scc.type+" now="+CASE WHEN scc.value="999999" THEN "ase_default" WHEN scc.value="999998" THEN "ase_current" ELSE ltrim(scc.value) END+", we want ase_current" col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="optimizer level" and scc.value  != 999998
	union
	select "exec sp_configure """+sc.name+""",0"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable literal autoparam" and scc.value   !=       0
	union
	select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable semantic partitioning" and scc.value   !=       1
	union
	select "exec sp_configure """+sc.name+""",128"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="permission cache entries" and scc.value   <       128
	union
	select "exec sp_configure """+sc.name+""",0"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable java" and scc.value   !=       0
	union
	select "exec sp_configure """+sc.name+""",500"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="deadlock checking period" and scc.value   <       500
	union
	select "exec sp_configure """+sc.name+""",0"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="read committed with lock" and scc.value   !=       0
	union
	select "exec sp_configure """+sc.name+""",0"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="auto query tuning" and scc.value   !=       0
	union
	select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="max query parallel degree" and scc.value   !=       1
	) a'
/tmp/db -q "$SQL"

#The optimization goal must be either "allrows_mix" or "sap_oltp" for systems that are not SAP BW Systems.
#optimization goal = allrows_mix [REQ]
#> optimization goal = sap_oltp [REQ]
if [[ $BO -eq 1 ]]; then SQL='set nocount on select cast( "exec sp_configure """+sc.name+""",allrows_dss"+char(9)+"--"+scc.type+" now="+ltrim(scc.value2) as varchar(80) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="optimization goal" and scc.value2  not in ( "allrows_dss")'; /tmp/db -q "$SQL"; fi;
if [[ $BO -eq 0 ]]; then SQL='set nocount on select cast( "exec sp_configure """+sc.name+""",sap_oltp"+char(9)+"--"+scc.type+" now="+ltrim(scc.value2) as varchar(80) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="optimization goal" and scc.value2  not in ( "sap_oltp", "allrows_mix")'; /tmp/db -q "$SQL"; fi;

: <<'end_long_comment'
The optimization goal is recommended to be "allrows_mix" or "sap_oltp" for SAP BW Systems.
optimization goal = allrows_mix [REC:BI]
> optimization goal = sap_oltp [REC:BI]
> number of histogram steps = 100 [REC]
> histogram tuning factor >= 20 [REC]
> capture compression statistics = 0 [REC]
> print deadlock information = 1 [REQ]
> min pages for parallel scan >= 60000 [REC]
> cpu accounting flush interval >= 5000000 [REC]
> i/o accounting flush interval >= 5000000 [REC]
> session tempdb log cache size = 32768 [REC]
> number of large i/o buffers = 32 [REC]
> enable housekeeper GC = 5 [REC]
> enable housekeeper GC >= 1 [REQ]
> sysstatistics flush interval = 5 [REC]
> sysstatistics flush interval >= 1 [REQ]
> global cache partition number >= 8 [REC]
> number of oam trips = 1 [REC]
> number of index trips = 1 [REC]
> user log cache spinlock ratio = 5 [REC]
> user log cache size = 65536 [REQ]
> workload manager cache size = 145 [REQ]
> default exp_row_size percent = 3 [REC]
> housekeeper free write percent = 10 [REC]
> number of pre-allocated extents = 32 [REC] 	already covered in db cce with 32
> SQL Perfmon Integration = 0 [REC:WIN]
> enable spinlock monitoring = 1 [REC]
> enable plan sharing = 0 [REQ]
> enable concurrent dump tran = 1 [REQ]
> enable dump history = 1 [REQ]
> update statistics hashing = partial [REC]
> auditing = 1 [REC]
> allow statement rollback = 1 [REQ]
> enable utility lvl 0 scan wait = 1 [REC]
> enable utility lvl 0 scan wait = 1 [REQ;BI]
> threshold event max messages >= 500 [REQ]
> threshold event monitoring = 1 [REQ]
> allow resource limits = 1 [REC]
> wait on uncommitted insert = 1 [REQ] -> become version specific
> number of network tasks = 4 [REC:LNX]		already covered in db cce with 32
> number of network tasks = 4 [REC:SOL]
> number of network tasks = 4 [REC:HPUX]
> number of network tasks = 4 [REC:AIX]
> number of network tasks = 1 [REC:WIN]
> max nesting level >= 32 [REQ]
end_long_comment
SQL='set nocount on
select cast( col1 as char(120)) [parameter fix(es)] from (
select "exec sp_configure """+sc.name+""",100"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="number of histogram steps" and scc.value != 100
union
select "exec sp_configure """+sc.name+""",20"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="histogram tuning factor" and scc.value < 20
union
select "exec sp_configure """+sc.name+""",0"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="capture compression statistics" and scc.value  != 0
union
select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="print deadlock information" and scc.value != 1
union
select "exec sp_configure """+sc.name+""",60000"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="min pages for parallel scan" and scc.value < 60000
union
select "exec sp_configure """+sc.name+""",5000000"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="cpu accounting flush interval" and scc.value  < 5000000
union
select "exec sp_configure """+sc.name+""",5000000"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="i/o accounting flush interval" and scc.value  < 5000000
union
select "exec sp_configure """+sc.name+""",32768"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="session tempdb log cache size" and scc.value  != 32768
union
select "exec sp_configure """+sc.name+""",32"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="number of large i/o buffers" and scc.value  != 32
union
select "exec sp_configure """+sc.name+""",5"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable housekeeper GC" and scc.value < 5
union
select "exec sp_configure """+sc.name+""",5"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="sysstatistics flush interval" and scc.value < 5
union
select "exec sp_configure """+sc.name+""",8"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="global cache partition number" and scc.value  < 8
union
select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="number of oam trips" and scc.value  != 1
union
select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="number of index trips" and scc.value  != 1
union
select "exec sp_configure """+sc.name+""",5"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="user log cache spinlock ratio" and scc.value  != 5
union
select "exec sp_configure """+sc.name+""",65536"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="user log cache size" and scc.value  != 65536
union
select "exec sp_configure """+sc.name+""",145"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="workload manager cache size" and scc.value  != 145
union
select "exec sp_configure """+sc.name+""",3"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="default exp_row_size percent" and scc.value  != 3
union
select "exec sp_configure """+sc.name+""",10"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="housekeeper free write percent" and scc.value  != 10
union
select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable spinlock monitoring" and scc.value  != 1
union
select "exec sp_configure """+sc.name+""",0"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable plan sharing" and scc.value  != 0
union
select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable concurrent dump tran" and scc.value  != 1
union
select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable dump history" and scc.value  != 1
union
select "exec sp_configure """+sc.name+""",partial"+char(9)+"--"+scc.type+" now="+ltrim(scc.value2) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="update statistics hashing" and scc.value2  != "partial"
union
select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="auditing" and scc.value  != 1
union
select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="allow statement rollback" and scc.value  != 1
union
select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable utility lvl 0 scan wait" and scc.value  != 1
union
select "exec sp_configure """+sc.name+""",500"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="threshold event max messages" and scc.value < 500
union
select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="threshold event monitoring" and scc.value  != 1
union
select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="allow resource limits" and scc.value  != 1
union
select "exec sp_configure """+sc.name+""",32"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="max nesting level" and scc.value < 32
) a'
/tmp/db -q "$SQL"

#> enable logins during recovery = 0 [REC]	added with Version 52
SQL='set nocount on
select cast(col1 as varchar(80)) The_Fix from (
select "exec sp_configure """+sc.name+""",0"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable logins during recovery" and scc.value   !=       0
) a'
/tmp/db -q "$SQL"

# network stuff: already covered in "db cce"
#Stack size and stack guard size need to be set to the following values, depending on your operating system:
#> stack size >= 151552 [REQ]
#> stack size >= 194560 [REQ:AIX]
#> stack size >= 409600 [REQ:HPUX]
#> stack guard size = 16384 [REQ]
#> stack guard size = 4096 [REQ:WIN]
# check for stack size is moved to db cc/cce as a DBA must fix 
#if [[ `/tmp/db -q 'select value from master..sysconfigures where name in ("stack size")'` -lt 151552 ]]; then echo exec sp_configure \"stack size\",151552; fi
SQL='set nocount on select cast( "exec sp_configure """+sc.name+""",16384"+char(9)+"--"+scc.type+" now="+ltrim(scc.value) as varchar(80) ) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="stack guard size" and scc.value  != 16384'; /tmp/db -q "$SQL"

#Set tape retention to at least 1 day, this avoids risk that dump files get overwritten accidentally when generated dump file names contain a timestring AND daylight saving reverts to standard time.
#> tape retention in days >= 1 [REQ]	added with Version 52
SQL='set nocount on
select cast( "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) as varchar(80)) The_Fix from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="tape retention in days" and scc.value   <       1'
/tmp/db -q "$SQL"

#For systems running on HP-UX, it is necessary that you set the following parameter:
#> enable hp posix async i/o = 1 [REQ:HPUX]

#For systems that have HADR enabled, it is necessary to set the following parameter:
#> replication agent memory size >= 16290 [REQ:REP]

#Data Caches
#Depending on the size and the workload, you should consider a larger default data cache, a separate large I/O cache pool, and a separate cache for the database log:
#{ Data Caches
#> default data cache >= 409600 [REQ]	 moved to db cc/cce as a DBA must fix
#}
#if [[ `/tmp/db -q 'select value from master..sysconfigures where name in ("default data cache") and comment = "User Defined Cache"'` -lt 409600 ]]; then echo exec sp_configure \"default data cache\",409600; fi

: <<'end_long_comment'
Logging Error Messages
Using the stored procedure 'sp_altermessage', you can enable logging of certain error messages. Call the following command in isql:
sp_altermessage <message_number>, 'with_log', 'true'
The current setting for a specific message number can be checked using the following SQL command:
SELECT CASE WHEN dlevel & 128 = 0 THEN 'false' ELSE 'true' END from master..sysmessages where error = <message_number>
{ Messages
Message number 701 is raised when the procedure cache size is insufficient to run a request:
> 701 = 'true' [REQ]
Message number 1105 is raised when it is not possible to allocate additional space to store data or logs:
> 1105 = 'true' [REQ]
Message number 2901 is raised when the stack limit has been exceeded:
> 2901 = 'true' [REQ]
Message number 12205 is raised when a lock could not be set within the configured wait time:
> 12205 = 'true' [REQ]
}
end_long_comment
if [[ `/tmp/db -q 'SELECT CASE WHEN dlevel & 128 = 0 THEN "false" ELSE "true" END from master..sysmessages where error = 701'` = *false* ]]; then echo "exec sp_altermessage 701, 'with_log', 'true'"; fi
if [[ `/tmp/db -q 'SELECT CASE WHEN dlevel & 128 = 0 THEN "false" ELSE "true" END from master..sysmessages where error = 1105'` = *false* ]]; then echo "exec sp_altermessage 1105, 'with_log', 'true'"; fi
if [[ `/tmp/db -q 'SELECT CASE WHEN dlevel & 128 = 0 THEN "false" ELSE "true" END from master..sysmessages where error = 2901'` = *false* ]]; then echo "exec sp_altermessage 2901, 'with_log', 'true'"; fi
if [[ `/tmp/db -q 'SELECT CASE WHEN dlevel & 128 = 0 THEN "false" ELSE "true" END from master..sysmessages where error = 12205'` = *false* ]]; then echo "exec sp_altermessage 12205, 'with_log', 'true'"; fi

# most were already checking in section "Database Options and Parameters" above, added there those missing
: <<'end_long_comment'
Database Options
Database options are set using the stored procedure sp_dboption. The following options need to be set for the databases <SID> and saptools. The current settings can be checked using the stored procedure sp_helpdb.
{ DB Options
> ddl in tran = 1 [REQ; S:@SID]
> ddl in tran = 1 [REQ; S:saptools]
> ddl in tran = 1 [REQ; S:tempdb]
> ddl in tran = 1 [REQ; S:saptempdb]
> allow nulls by default = 1 [REQ; S:@SID]
> allow nulls by default = 1 [REQ; S:saptools]
> allow nulls by default = 1 [REQ; S:tempdb]
> allow nulls by default = 1 [REQ; S:saptempdb]
> allow wide dol rows = 1 [REQ; S:@SID]
> allow wide dol rows = 1 [REQ; S:saptools]
> allow wide dol rows = 1 [REQ; S:tempdb]
> allow wide dol rows = 1 [REQ; S:saptempdb]
> allow incremental dumps = 1 [REQ; S:@SID]
> allow incremental dumps = 1 [REQ; S:saptools]
> no free space acctg = 0 [REQ; S:@SID]
> no free space acctg = 0 [REQ; S:saptools]
> unique auto_identity index = 0 [REQ; S:@SID]
> unique auto_identity index = 0 [REQ; S:saptools]
For the database <SID> the following options need to be set:
> deferred table allocation = 1 [REC; S:@SID]
> deallocate first text page = 1 [REC; S:@SID]
It is recommended that you set the 'abort tran on log full' option, but this is not a requirement:
> abort tran on log full = 1 [REC; S:@SID]
> abort tran on log full = 1 [REC; S:saptools]
Page compression can be set for all databases. This is strongly recommended for the SAP database:
> page compression = 1 [REC; S:@SID]
For the production use, for the <SID> database options need to be set as follows:
> enforce dump tran sequence = 1 [REQ; S:@SID]
> full logging for all = 1 [REQ; S:@SID]
> select into/bulkcopy/pllsort = 0 [REQ; S:@SID]
> select into/bulkcopy/pllsort = 1 [REQ; S:tempdb]
> select into/bulkcopy/pllsort = 1 [REQ; S:saptempdb]
> trunc log on chkpt = 0 [REQ; S:@SID]
For 'sybsystemdb' and 'saptools' databases the following option needs to be set:
> trunc log on chkpt = 1 [REC; S:sybsystemdb]
> trunc log on chkpt = 1 [REC; S:saptools]
}
end_long_comment

: <<'end_long_comment'
Table Options
Table options are set using the stored procedure sp_chgattribute. To check the current settings of a table, use stored procedure sp_help.
The following tables are known to be volatile. If 'concurrency_opt_threshold' is set to '-1', the ASE optimizer will always scan the index without consideration of the table's statistics. For more information, see SAP Note 2049506.
{ Table Options
> concurrency_opt_threshold = -1 [REQ; T:@SID.SAPSR3.ARFCSSTATE]
> concurrency_opt_threshold = -1 [REQ; T:@SID.SAPSR3.ARFCSDATA]
> concurrency_opt_threshold = -1 [REQ; T:@SID.SAPSR3.ARFCRSTATE]
> concurrency_opt_threshold = -1 [REQ; T:@SID.SAPSR3.QREFTID]
> concurrency_opt_threshold = -1 [REQ; T:@SID.SAPSR3.RSBATCHCTRL]
> concurrency_opt_threshold = -1 [REQ; T:@SID.SAPSR3.TRFCQSTATE]
> concurrency_opt_threshold = -1 [REQ; T:@SID.SAPSR3.TRFCQINS]
> concurrency_opt_threshold = -1 [REQ; T:@SID.SAPSR3.TRFCQIN]
> concurrency_opt_threshold = -1 [REQ; T:@SID.SAPSR3.TRFCQOUT]
> concurrency_opt_threshold = -1 [REQ; T:@SID.SAPSR3.TRFCQDATA]
> concurrency_opt_threshold = -1 [REQ; T:@SID.SAPSR3.VBMOD]
> concurrency_opt_threshold = -1 [REQ; T:@SID.SAPSR3.VBHDR]
> concurrency_opt_threshold = -1 [REQ; T:@SID.SAPSR3.VBDATA]
> concurrency_opt_threshold = -1 [REQ; T:@SID.SAPSR3DB.BC_MID_CON_TRFC]		added with Version 52
> concurrency_opt_threshold = -1 [REQ; T:@SID.SAPSR3DB.BC_MID_CON_BGRFC]	added with Version 52
}
end_long_comment
for TAB in VBHDR VBMOD VBDATA QREFTID TRFCQIN TRFCQINS TRFCQOUT ARFCSDATA TRFCQDATA ARFCRSTATE ARFCSSTATE TRFCQSTATE RSBATCHCTRL
do
        #echo -n "$TAB "
        RESULT=`/tmp/db 'set nocount on\nuse @@servername\ngo\nset proc_return_status off\nexec sp_help "SAPSR3.'$TAB'"' | tail -1`
        if [[ $RESULT != "Object does not exist in this database." && ! "$RESULT" =~ "-1" ]];then echo 'use '$SID';setuser "SAPSR3";exec sp_chgattribute '$TAB',"concurrency_opt_threshold",-1'; fi
done
for TAB in BC_MID_CON_TRFC BC_MID_CON_BGRFC
do
        #echo -n "$TAB "
        RESULT=`/tmp/db 'set nocount on\nuse @@servername\ngo\nset proc_return_status off\nexec sp_help "SAPSR3DB.'$TAB'"' | tail -1`
        if [[ $RESULT != "Object does not exist in this database." && ! "$RESULT" =~ "-1" ]];then echo 'use '$SID';setuser "SAPSR3DB";exec sp_chgattribute '$TAB',"concurrency_opt_threshold",-1'; fi
done

# this param is duplicate
#Additional Settings
#Version 16.0.00.02 and higher:
#{ Configuration -- Version >= 16.0.00.02
#> allow statement rollback = 1 [REQ]
#}

#Version 16.0.00.04 and higher:
#{ Configuration -- Version >= 16.0.00.04
#> enable async database init = 1 [REQ]
#}
if [[ $VER -ge 1600004 ]]; then 
        SQL='set nocount on
        select cast(col1 as varchar(80)) The_Fix from (
        select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable async database init" and scc.value   !=       1
        ) a'
	/tmp/db -q "`echo "$SQL"`"
fi

#Version 16.0.01.00 and higher:
#{ Configuration -- Version >= 16.0.01.00
#> enable sticky statistics = 0 [REQ]
#> enable bulk inserts = 0 [REQ]
#> expand numeric truncated scale = 1 [REQ]
#}
if [[ $VER -ge 1600100 ]];then 
	SQL='
		set nocount on
		select cast(col1 as varchar(80)) The_Fix from (
		select "exec sp_configure """+sc.name+""",0"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1 	from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable sticky statistics" and scc.value	!=       0
		union
		select "exec sp_configure """+sc.name+""",0"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1 	from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable bulk inserts" and scc.value	!=       0
		union
		select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1 	from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="expand numeric truncated scale" and scc.value	!=       1
		) a
	'
	/tmp/db -q "`echo "$SQL"`"
fi

#Version 16.0.02.04 and higher:
#{ DB Options -- Version >= 16.0.02.04
#> allow db suspect on rollback error = 1 [REQ; S:@SID]	added with Version 52
#}
#{ Configuration -- Version >= 16.0.02.04
#> enable lightweight rvm = 1 [REC]	added with Version 52
#}
if [[ $VER -ge 1600204 ]];then
for DB in `/tmp/db -q 'set nocount on\nselect name from master..sysdatabases where name not in ( "tempdb","master","model","sybmgmtdb","sybpcidb","sybsystemdb","sybsystemprocs","sybsecurity","saptools","svvstools" ) and status3 &256 != 256 and status2 &16 != 16 '`
do
#echo "db options $DB"
RESULT=`/tmp/db -s "sp_helpdb $DB" | egrep 'allow db suspect on rollback error'`
for STR in "allow db suspect on rollback error"; do
	if [[ "$RESULT" != *"$STR"* ]]; then
		# these should be true
		if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then echo "FAIL $DB $STR = false"; fi
		if [[ $REPORT = "FIX"  || $REPORT = "BOTH" ]]; then echo exec sp_dboption $DB, \'$STR\',true; fi
	else
		if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then echo "PASS $DB $STR = true"; fi
	fi
done
done
SQL='set nocount on
select cast(col1 as varchar(80)) The_Fix from (
select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable lightweight rvm" and scc.value   !=       1
) a'
/tmp/db -q "$SQL"
fi

#Version 16.0.02.05 and higher:
#{ Configuration -- Version >= 16.0.02.05
#> wait on uncommitted insert = 2 [REQ] ...otherwise 1
#> restore database options = 1 [REQ]	added with Version 52
#> extend implicit conversion = 1 [REQ]	added with Version 52
#}
if [[ $VER -lt 1600205 ]];then 
	SQL='set nocount on
	select cast(col1 as varchar(80)) The_Fix from (
	select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1 	from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="wait on uncommitted insert" and scc.value	!=       1
	) a'
	/tmp/db -q "`echo "$SQL"`"
else
	SQL='set nocount on
	select cast(col1 as varchar(80)) The_Fix from (
	select "exec sp_configure """+sc.name+""",2"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1 	from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="wait on uncommitted insert" and scc.value	!=       2
	union
	select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="restore database options" and scc.value   !=       1
	union
	select "exec sp_configure """+sc.name+""",1"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="extend implicit conversion" and scc.value   !=       1
	) a'
	/tmp/db -q "`echo "$SQL"`"
fi

####################
# END check settings in 1581695 - SYB: Configuration Guide for SAP ASE 16.0
####################

# lockscheme for MDA tables should be datarows
RESULT=`/tmp/db -q 'select lockscheme(name) lockscheme, count(*) from master..sysobjects where type="U" and name like "%mon%" and name <> "spt_monitor" and lockscheme(name) != "datarows" group by lockscheme(name)'`
if [[ "$RESULT"xx != "xx" ]]; then echo "failed lockscheme for MDA tables should be datarows: $RESULT"; fi

# default device should not be master
if [[ `/tmp/db sp_helpdevice master | grep -ci default` -ne 0 ]]; then echo sp_diskdefault master, defaultoff; fi

# interfaces file check, ASE should listen on physical hostname, required by (external) solman monitoring
# https://confluence.savvis.net/display/SAPBASIS/How+To+prepare+Managed+System+for+Solution+Manager+Technical+Monitoring#HowtoprepareManagedSystemforSolutionManagerTechnicalMonitoring-Interfacesfile
CNT=`netstat -ap 2>/dev/null | grep LISTEN |grep dataserver | grep -i $HOSTNAME | wc -l`
if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then if [[ $CNT -lt 1 ]]; then echo "FAIL interfaces file, mismatch between hostname and IP addr ASE is listening on."; else echo "PASS interfaces file, matching hostname with IP addr ASE is listening on."; fi; fi
if [[ $REPORT = "FIX" || $REPORT = "BOTH" ]]; then if [[ $CNT -lt 1 ]]; then echo "interfaces file problem, mismatch between hostname and the IP addr ASE is listening on, listening on physial hostname is required for solman monitoring"; fi; fi

# only config_history should be audited (or we have prepare with bigger sybsecurity)
RESULT="`/tmp/db "sp_displayaudit" | grep " on" | tr -s " " | tr -d "\n" | grep "config_history" | wc -l`"
if [[ $REPORT = "LIST" || $REPORT = "BOTH" ]]; then if [[ $RESULT -gt 1 ]]; then echo "FAIL audit settings"; else echo "PASS audit settings"; fi; fi
if [[ $REPORT = "FIX"  || $REPORT = "BOTH" ]]; then if [[ $RESULT -gt 1 ]]; then echo "problem with audit settings, only config_history should be audited, check with sp_displayaudit"; fi; fi

# added "enable granular permissions" check to allow backing up of sybsecurity db
SQL='set nocount on
        select cast(col1 as varchar(80)) The_Fix from (
	select "exec sp_configure """+sc.name+""",0"+char(9)+"--"+scc.type+" now="+ltrim(str(scc.value)) col1   from sysconfigures sc, syscurconfigs scc where sc.config = scc.config and  sc.name="enable granular permissions" and scc.value   !=       0
	) a'
/tmp/db -q "`echo "$SQL"`"

#fi	# exclude ====================
