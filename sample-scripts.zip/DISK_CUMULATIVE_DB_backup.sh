#!/bin/ksh
# DISK_CUMULATIVE_DB_backup.sh
# sh /sybase/$SID/SYBASE.sh
. ~/SYBASE.sh
#export SID=SLQ
export SID=`echo $SYBASE | sed 's/\/sybase\///g'`
export SYBASE=/sybase/$SID
export SYBASE_OCS=OCS-16_0
export SYBASE_ASE=ASE-16_0
export INCLUDE=/sybase/$SID/OCS-16_0/include:
export LIB=/sybase/$SID/OCS-16_0/lib:
export LD_LIBRARY_PATH=/sybase/$SID/ASE-16_0/lib:/sybase/$SID/DataAccess64/ODBC/lib:/sybase/$SID/DataAccess/ODBC/lib:/sybase/$SID/OCS-16_0/lib:/sybase/$SID/OCS-16_0/lib3p64:/sybase/$SID/OCS-16_0/lib3p:
export LOG_FILE=/data01/home/sybase/logs/DISK_CUMULATIVE_DB_backup.log
export HISTLOG_FILE=/data01/home/sybase/logs/DISK_CUMULATIVE_DB_backup_history.log
echo $SID
echo '' >> $HISTLOG_FILE
echo '---------------- BACKUP STARTED ON' `date` >> $HISTLOG_FILE

$SYBASE/$SYBASE_OCS/bin/isql -S $SID -U ctlbkp -I $SYBASE/interfaces -w 9999 -X -b <<EOF > $LOG_FILE
`cat /data01/home/sybase/scripts/.ctlbkp_word`
use svvstools
go

/*
**  prc_cumulative_backup (@DmpLoc CHAR(1), @DmpType varchar(4), @DmpMode char(1))
**      Param 1 - @DmpLoc  - Values could be in (D)isk
**      Param 2 - @DmpType - Values could be "data"
**      Param 3 - @DumpMode- Value would be (C)umulative
*/
declare @waitcount tinyint
select @waitcount = 1
while @waitcount <= 3
begin
	if (select count(*) from master..sysprocesses where cmd like 'DUMP%') = 0
	begin
		exec prc_cumulative_backup "D","data","C" 
        	break
	end
	else
	begin
		select '--There is already another backup running... Sleeping for 5 minutes before trying next...'
		waitfor delay '00:05:00'
		select @waitcount = @waitcount + 1
		continue
	end
end
go

/*
** Status clumn in svvstools..dump_summary
**
** Status          Indicates
**------   -------------------------------------------------
** R        Backup is (R)unning
** E        Backup failed with (E)rror
** F        Backup (F)inished successfully
** S        Backup (S)skipped due to already running backup.
**
** -----  Delete the svvstools..dump_history table
** -----  for the records older than 9 months
*/

delete svvstools..dump_history
where datediff(dd, StartTime,getdate() ) > 271
go

dump tran master with no_log
go

EOF

if [ $? != 0 ]
then
        echo "ERROR : Backup failed." >>  $LOG_FILE
        cat $LOG_FILE >> $HISTLOG_FILE
        echo '---------------- BACKUP SCRIPT FINISHED ON' `date` >> $HISTLOG_FILE
        exit 1
fi

echo "SUCCESS : Backup completed successfully." >>  $LOG_FILE
cat $LOG_FILE >> $HISTLOG_FILE
echo '---------------- BACKUP SCRIPT FINISHED ON' `date` >> $HISTLOG_FILE

/bin/find /lbackup/DB/*CUMU*.dmp -type f -mmin +11520 -exec rm {} \;

exit 0

