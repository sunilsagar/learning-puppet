#!/bin/bash

# File: sybase_sia.sh
# version 2.8
# Description: Script to monitor Sybase metrics
#              such as the following:
#                  sybase_db_status
#                  sybase_db_suspect
#                  sybase_data_free_size_mb
#                  sybase_data_free_pct.sql
#                  sybase_log_free_size_mb
#                  sybase_log_free_pct
#                  sybase_blocking
#                  sybase_db_backups
#                  sybase_log_backups
#                  sybase_backup_error
#                  sybase_long_tran
#                  sybase_user_connect_pct
#                  sybase_bs_server_status
#                  sybase_js_server_status
#                  sybase_replication_delay
#                  sybase_license
#              	   sybase_iq_db_status
#                  sybase_iq_data_free_pct
#                  sybase_iq_backup_full
#                  sybase_iq_backup_incr_since_incr
#                  sybase_iq_backup_incr_since_full
#	           sybase_iq_blocking
#		   sybase_iq_connections
#		   sybase_iq_license
#                  sybase_iq_license_vldbmgmt_free_gb
# Created by: John Powell
# Date: 2/02/2018

############################
# Setting Environment
############################

MON_NAME=${1}
RUN_MON=`echo "${MON_NAME}" | tr '[:upper:]' '[:lower:]'`
#below for ASE
DATASERVER=${2}
DATABASE=${3}
SYBASE_OCS=OCS-16_0
SYBASE=/sybase/${2}
#below other than 0 only for sybase_replication_delay only if primary/DR in diff timezones - offset value as minutes PRIMARY TZ is ahead DR TZ.
TZ_OFFSET=0
#below for ASE and IQ
SYB_USER=`echo "syb${2}" | tr '[:upper:]' '[:lower:]'`
#IQ specific params
IQDB=${2}
#datasource name below
IQCONNPARAM=dsn=DQ1
##TEST ENV ONLY
#SYB_USER=sybase

############################
# Function
############################

##ASE DATABASE

sybase_db_status()
{
su - $SYB_USER -c "$SYBASE/$SYBASE_OCS/bin/isql -S $DATASERVER -U ctlbkp -I $SYBASE/interfaces -w 9999 -b -X" <<EOF
`cat /data01/home/sybase/scripts/.ctlbkp_word`
use master
go
`cat /usr/local/monitor/sql/sybase/sybase_db_status.sql | sed "s|INSTANCE_NAME|$DATASERVER|g"`
exit;
EOF
exit;
}

sybase_db_suspect()
{
su - $SYB_USER -c "$SYBASE/$SYBASE_OCS/bin/isql -S $DATASERVER -U ctlbkp -I $SYBASE/interfaces -w 9999 -b -X" <<EOF
`cat /data01/home/sybase/scripts/.ctlbkp_word`
use master
go
`cat /usr/local/monitor/sql/sybase/sybase_db_suspect.sql | sed "s|INSTANCE_NAME|$DATASERVER|g"`
exit;
EOF
exit;
}

sybase_data_free_size_mb()
{
su - $SYB_USER -c "$SYBASE/$SYBASE_OCS/bin/isql -S $DATASERVER -U ctlbkp -I $SYBASE/interfaces -w 9999 -b -X" <<EOF
`cat /data01/home/sybase/scripts/.ctlbkp_word`
use master
go
`cat /usr/local/monitor/sql/sybase/sybase_data_free_size_mb.sql | sed "s|INSTANCE_NAME|$DATASERVER|g"`
exit;
EOF
exit;
}

sybase_data_free_pct()
{
su - $SYB_USER -c "$SYBASE/$SYBASE_OCS/bin/isql -S $DATASERVER -U ctlbkp -I $SYBASE/interfaces -w 9999 -b -X" <<EOF
`cat /data01/home/sybase/scripts/.ctlbkp_word`
use master
go
`cat /usr/local/monitor/sql/sybase/sybase_data_free_pct.sql | sed "s|INSTANCE_NAME|$DATASERVER|g"`
exit;
EOF
exit;
}

sybase_log_free_size_mb()
{
su - $SYB_USER -c "$SYBASE/$SYBASE_OCS/bin/isql -S $DATASERVER -U ctlbkp -I $SYBASE/interfaces -w 9999 -b -X" <<EOF
`cat /data01/home/sybase/scripts/.ctlbkp_word`
use master
go
`cat /usr/local/monitor/sql/sybase/sybase_log_free_size_mb.sql | sed "s|INSTANCE_NAME|$DATASERVER|g"`
exit;
EOF
exit;
}

sybase_log_free_pct()
{
su - $SYB_USER -c "$SYBASE/$SYBASE_OCS/bin/isql -S $DATASERVER -U ctlbkp -I $SYBASE/interfaces -w 9999 -b -X" <<EOF
`cat /data01/home/sybase/scripts/.ctlbkp_word`
use master
go
`cat /usr/local/monitor/sql/sybase/sybase_log_free_pct.sql | sed "s|INSTANCE_NAME|$DATASERVER|g"`
exit;
EOF
exit;
}

sybase_blocking()
{
su - $SYB_USER -c "$SYBASE/$SYBASE_OCS/bin/isql -S $DATASERVER -U ctlbkp -I $SYBASE/interfaces -w 9999 -b -X" <<EOF
`cat /data01/home/sybase/scripts/.ctlbkp_word`
use master
go
`cat /usr/local/monitor/sql/sybase/sybase_blocking.sql | sed "s|INSTANCE_NAME|$DATASERVER|g"`
exit;
EOF
exit;
}

sybase_db_backups()
{
su - $SYB_USER -c "$SYBASE/$SYBASE_OCS/bin/isql -S $DATASERVER -U ctlbkp -I $SYBASE/interfaces -w 9999 -b -X" <<EOF
`cat /data01/home/sybase/scripts/.ctlbkp_word`
use master
go
`cat /usr/local/monitor/sql/sybase/sybase_db_backups.sql | sed "s|INSTANCE_NAME|$DATASERVER|g"`
exit;
EOF
exit;
}

sybase_log_backups()
{
su - $SYB_USER -c "$SYBASE/$SYBASE_OCS/bin/isql -S $DATASERVER -U ctlbkp -I $SYBASE/interfaces -w 9999 -b -X" <<EOF
`cat /data01/home/sybase/scripts/.ctlbkp_word`
use master
go
`cat /usr/local/monitor/sql/sybase/sybase_log_backups.sql | sed "s|INSTANCE_NAME|$DATASERVER|g"`
exit;
EOF
exit;
}

sybase_backup_error()
{
su - $SYB_USER -c "$SYBASE/$SYBASE_OCS/bin/isql -S $DATASERVER -U ctlbkp -I $SYBASE/interfaces -w 9999 -b -X" <<EOF
`cat /data01/home/sybase/scripts/.ctlbkp_word`
use master
go
`cat /usr/local/monitor/sql/sybase/sybase_backup_error.sql | sed "s|INSTANCE_NAME|$DATASERVER|g"`
exit;
EOF
exit;
}

sybase_long_tran()
{
su - $SYB_USER -c "$SYBASE/$SYBASE_OCS/bin/isql -S $DATASERVER -U ctlbkp -I $SYBASE/interfaces -w 9999 -b -X" <<EOF
`cat /data01/home/sybase/scripts/.ctlbkp_word`
use master
go
`cat /usr/local/monitor/sql/sybase/sybase_long_tran.sql | sed "s|INSTANCE_NAME|$DATASERVER|g"`
exit;
EOF
exit;
}

sybase_backup_server_status()
{
/usr/local/monitor/sql/sybase/sybase_bs_server_status.sh $DATASERVER
}

sybase_job_server_status()
{
/usr/local/monitor/sql/sybase/sybase_js_server_status.sh $DATASERVER
}

sybase_data_cache_ratio()
{
su - $SYB_USER -c "$SYBASE/$SYBASE_OCS/bin/isql -S $DATASERVER -U ctlbkp -I $SYBASE/interfaces -w 9999 -b -X" <<EOF
`cat /data01/home/sybase/scripts/.ctlbkp_word`
use master
go
`cat /usr/local/monitor/sql/sybase/sybase_data_cache_ratio.sql | sed "s|INSTANCE_NAME|$DATASERVER|g"`
exit;
EOF
exit;
}

sybase_proc_cache_ratio()
{
su - $SYB_USER -c "$SYBASE/$SYBASE_OCS/bin/isql -S $DATASERVER -U ctlbkp -I $SYBASE/interfaces -w 9999 -b -X" <<EOF
`cat /data01/home/sybase/scripts/.ctlbkp_word`
use master
go
`cat /usr/local/monitor/sql/sybase/sybase_proc_cache_ratio.sql | sed "s|INSTANCE_NAME|$DATASERVER|g"`
exit;
EOF
exit;
}

sybase_user_connect_pct()
{
su - $SYB_USER -c "$SYBASE/$SYBASE_OCS/bin/isql -S $DATASERVER -U ctlbkp -I $SYBASE/interfaces -w 9999 -b -X" <<EOF
`cat /data01/home/sybase/scripts/.ctlbkp_word`
use master
go
`cat /usr/local/monitor/sql/sybase/sybase_user_connect_pct.sql | sed "s|INSTANCE_NAME|$DATASERVER|g"`
exit;
EOF
exit;
}

sybase_replication_delay()
{
rep_delay()
{
su - $SYB_USER -c "$SYBASE/$SYBASE_OCS/bin/isql -S $DATASERVER -U ctlbkp -I $SYBASE/interfaces -w 9999 -b -X" <<EOF
`cat /data01/home/sybase/scripts/.ctlbkp_word`
use master
go
`cat /usr/local/monitor/sql/sybase/sybase_replication_delay.sql | sed "s|INSTANCE_NAME|$DATASERVER|g" | sed "s|DATABASE_NAME|$DATABASE|g" | sed "s|TZ|$TZ_OFFSET|g"`
exit;
EOF
}
rep_delay | sed -n '/sh/!p'
exit;
}

sybase_license()
{
su - $SYB_USER -c "$SYBASE/$SYBASE_OCS/bin/isql -S $DATASERVER -U ctlbkp -I $SYBASE/interfaces -w 9999 -b -X" <<EOF
`cat /data01/home/sybase/scripts/.ctlbkp_word`
use master
go
`cat /usr/local/monitor/sql/sybase/sybase_license.sql | sed "s|INSTANCE_NAME|$DATASERVER|g"`
exit;
EOF
exit;
}

#IQ database

sybase_iq_db_status()
{
su - $SYB_USER -c "dbping -q -d -c $IQCONNPARAM;" >/dev/null 2>&1
if [ $? -ne 0 ]; then
echo "SYBASE_IQ_DB_STATUS:$IQDB=0"
else echo "SYBASE_IQ_DB_STATUS:$IQDB=1"
fi
}

sybase_iq_data_free_pct()
{
RETVAL=`su - $SYB_USER -c "dbisql -c $IQCONNPARAM -nogui /usr/local/monitor/sql/sybase/sybase_iq_data_free_pct.sql;"`
echo "$RETVAL"| grep $MON_NAME | tail -n +2 | sed "s|INSTANCE_NAME|$IQDB|g"
}

sybase_iq_backup_incr_since_full()
{
RETVAL=`su - $SYB_USER -c "dbisql -c $IQCONNPARAM -nogui /usr/local/monitor/sql/sybase/sybase_iq_backup_incr_since_full.sql;"`
echo "$RETVAL"| grep $MON_NAME | tail -n +2 | sed "s|INSTANCE_NAME|$IQDB|g"
}

sybase_iq_backup_incr_since_incr()
{
RETVAL=`su - $SYB_USER -c "dbisql -c $IQCONNPARAM -nogui /usr/local/monitor/sql/sybase/sybase_iq_backup_incr_since_incr.sql;"`
echo "$RETVAL"| grep $MON_NAME | tail -n +2 | sed "s|INSTANCE_NAME|$IQDB|g"
}

sybase_iq_backup_full ()
{
RETVAL=`su - $SYB_USER -c "dbisql -c $IQCONNPARAM -nogui /usr/local/monitor/sql/sybase/sybase_iq_backup_full.sql;"`
echo "$RETVAL"| grep $MON_NAME | tail -n +2 | sed "s|INSTANCE_NAME|$IQDB|g"
}

sybase_iq_blocking ()
{
RETVAL=`su - $SYB_USER -c "dbisql -c $IQCONNPARAM -nogui /usr/local/monitor/sql/sybase/sybase_iq_blocking.sql;"`
echo "$RETVAL"| grep $MON_NAME | tail -n +2 | sed "s|INSTANCE_NAME|$IQDB|g"
}

sybase_iq_connections ()
{
RETVAL=`su - $SYB_USER -c "dbisql -c $IQCONNPARAM -nogui /usr/local/monitor/sql/sybase/sybase_iq_connections.sql;"`
echo "$RETVAL"| grep $MON_NAME | tail -n +2 | sed "s|INSTANCE_NAME|$IQDB|g"
}

sybase_iq_license ()
{
#path to license files
LICDIR=/sybase/$IQDB/SYSAM-2_0/licenses/*.lic
#core license check
#first check if core temp license, if temp skip core count
IQTEMP=`cat $LICDIR | grep IQ_EE_TEMP | wc -l`
if [[ $IQTEMP -lt 1 ]];then
SRVCORE=`nproc --all`
#non temp licenses
if ls $LICDIR 1> /dev/null 2>&1; then
LICFILELIST=`ls $LICDIR`
for l in $LICFILELIST; do
`cat $l | grep -E 'INCREMENT|UPGRADE' | awk '{ print $2, $5 , $6 }' | sort -u >/tmp/liclist`
for a in /tmp/liclist; do
while read -r a b c; do
LICENSE="$a"
CORLICCNT="$c"
if [[ "$CORLICCNT" != "uncounted" ]]; then
#count licenses
if [[ $SRVCORE -gt $CORLICCNT ]]; then
echo "SYBASE_IQ_LICENSE:$IQDB:CORE_COUNT=0"
else
if [[ $b == "permanent" ]]; then
EXPIREDAYS=999999
echo "SYBASE_IQ_LICENSE:$IQDB:"$LICENSE"_PERM="$EXPIREDAYS
else
EXPIRY=`date -d $b +"%Y%m%d"`
DATE=$(date +"%Y%m%d")
EXPIREDAYS=`printf "%s\n" $(( ($(date -d "$EXPIRY" "+%s") - $(date -d "$DATE" "+%s"))/86400 ))`
echo "SYBASE_IQ_LICENSE:$IQDB:$LICENSE=$EXPIREDAYS"
fi
fi
else
if [[ $b == "permanent" ]]; then
EXPIREDAYS=999999
echo "SYBASE_IQ_LICENSE:$IQDB:"$LICENSE"_PERM="$EXPIREDAYS
else
EXPIRY=`date -d $b +"%Y%m%d"`
DATE=$(date +"%Y%m%d")
EXPIREDAYS=`printf "%s\n" $(( ($(date -d "$EXPIRY" "+%s") - $(date -d "$DATE" "+%s"))/86400 ))`
echo "SYBASE_IQ_LICENSE:$IQDB:$LICENSE=$EXPIREDAYS"
fi
fi
done < /tmp/liclist
done
done
else
echo "SYBASE_IQ_LICENSE:$IQDB:NO_LICENSE=0"
fi
fi
echo "$RETVAL"| grep $MON_NAME | tail -n +2 | sed "s|INSTANCE_NAME|$IQDB|g"
}

sybase_iq_license_vldbmgmt_free_gb ()
{
#path to license files
LICDIR=/sybase/$IQDB/SYSAM-2_0/licenses/*.lic
#count partitions
echo "SELECT count(*) FROM sp_iqtable() where isPartitioned='Y';" > /tmp/part_count.sql
chmod 755 /tmp/part_count.sql
PARTCOUNT=`su - $SYB_USER -c "dbisql -c $IQCONNPARAM -nogui /tmp/part_count.sql;"`
PARTCOUNT=`echo "$PARTCOUNT" | tail -n5 | head -n1 | xargs`
#count main dbspace
echo "select count(DBSpaceName) from sp_iqdbspace() where DBSpaceType='MAIN';" > /tmp/dbspace_count.sql
chmod 755 /tmp/dbspace_count.sql
DBCOUNT=`su - $SYB_USER -c "dbisql -c $IQCONNPARAM -nogui /tmp/dbspace_count.sql;"`
DBCOUNT=`echo "$DBCOUNT" | tail -n5 | head -n1 | xargs`
#check if either multiple partitions or more than 1 main dbspace
if [[ "$PARTCOUNT" -gt "1" || "$DBCOUNT" -gt "1" ]];then
#collect size of main dbspaces
echo "select TotalSize from sp_iqdbspace() where DBSpaceType='MAIN';" > /tmp/dbspace_size.sql
chmod 755  /tmp/dbspace_size.sql
DBSIZE=`su - $SYB_USER -c "dbisql -c $IQCONNPARAM -nogui /tmp/dbspace_size.sql;"`
DBSIZE=`echo "$DBSIZE" | grep -v SYBASE | grep -v TotalSize | grep -E 'B|K|M|G|T|P'`
sumMB=0
#below converts all to MB and sums into $sumMB
for s in `echo "$DBSIZE"`;do
case $s in
    *B )
        v=`echo -n "$s" | head -c-1`
        value=$(echo $v/1048576 | bc)
        sumMB=$(echo $sumMB+$value | bc)
                ;;
    *K )
        v=`echo -n "$s" | head -c-1`
        value=$(echo $v/1024 | bc)
        sumMB=$(echo $sumMB+$value | bc)
                ;;
    *M )
        v=`echo -n "$s" | head -c-1`
        sumMB=$(echo $sumMB+$value | bc)
                ;;
    *G )
        v=`echo -n "$s" | head -c-1`
        value=$(echo $v*1024 | bc)
        sumMB=$(echo $sumMB+$value | bc)
                ;;
    *T )
        v=`echo -n "$s" | head -c-1`
        value=$(echo $v*1048576 | bc)
        sumMB=$(echo $sumMB+$value | bc)
                ;;
    *P )
        v=`echo -n "$s" | head -c-1`
        value=$(echo $v*1073741824 | bc)
        sumMB=$(echo $sumMB+$value | bc)
                ;;
esac
done
sumGB=$(echo $sumMB/1024 | bc)
#next find # of VLDBMGMT licenses available.
VLDBMGMTLICCNT=`grep -A2 'IQ_VLDBMGMT' $LICDIR | grep CP= | awk '{ print $3 }' | sed 's/^.*CP=/CP=/'| sed -e 's/;[^;]*$//'| sed -e 's/;[^;]*$//'`
VLDBMGMTLICCNT=`echo ${VLDBMGMTLICCNT#*=}`
#multiply license # * 1048576 to get MB covered by licenses.
licensedMB=$(echo $VLDBMGMTLICCNT*1048576 | bc)
licensedGB=$(echo $licensedMB/1024 | bc)
#subtract $sumGB from licensedGB to get remaining licensed space.
remainingVLDBMGMT=$(echo $licensedGB - $sumGB | bc)
echo "SYBASE_IQ_LICENSE_VLDBMGMT_FREE_GB:$IQDB=$remainingVLDBMGMT"
else
echo "SYBASE_IQ_LICENSE_VLDBMGMT_FREE_GB:$IQDB=999999"
fi
}

############################
# Main
############################

#checks if IQ monitor
if [[ $RUN_MON == *iq* ]];then
#Checks if connect to IQ DB, returns status=0 if not and exits.
su - $SYB_USER -c "dbping -q -d -c $IQCONNPARAM;" >/dev/null 2>&1
if [ $? -ne 0 ]; then
echo "SYBASE_IQ_DB_STATUS:$IQDB=0"
exit 0
else
${RUN_MON}
exit 0
fi
else

#Checks if ASE dataserver is running first, returns 0 if not and exits.
RETVAL=$(sybase_db_status)
if [[ $RETVAL != *$DATASERVER=1* ]]; then
if [[ $RUN_MON == sybase_db_status ]];then
echo "SYBASE_DB_STATUS:$DATASERVER=0"
exit 0
else
exit 0
fi
fi
${RUN_MON}| sed -n '/Password/!p'
#end ASE
#exit 0
fi

# End of the script

