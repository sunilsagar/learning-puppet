#!/bin/sh

SID=`cat /tmp/scripts/*SID`
gdatetime=`/bin/date +%Y%m%d%H%M%S`
sid=`echo ${SID} |tr '[:upper:]' '[:lower:]'`
sybuser=syb${sid}

##Creating required directories
DIR="/data01/home/sybase"
if [ -d "$DIR" ]
then
        echo "SKIPPED - Directory $DIR exists"
else
        mkdir $DIR
        echo "SUCCESS - Created directory $DIR"
fi


DIR="/data01/home/sybase/scripts"
if [ -d "$DIR" ]
then
        echo "SKIPPED - Directory $DIR exists"
else
        mkdir $DIR
        echo "SUCCESS - Created directory $DIR"
fi

DIR="/data01/home/sybase/sqls"
if [ -d "$DIR" ]
then
        echo "SKIPPED - Directory $DIR exists"
else
        mkdir $DIR
        echo "SUCCESS - Created directory $DIR"

fi

DIR="/data01/home/sybase/logs"
if [ -d "$DIR" ]
then
        echo "SKIPPED - Directory $DIR exists"
else
        mkdir $DIR
        echo "SUCCESS - Created directory $DIR"

fi

DIR="/data01/home/sybase/logs/OLD"
if [ -d "$DIR" ]
then
        echo "SKIPPED - Directory $DIR exists"
else
        mkdir $DIR
        echo "SUCCESS - Created directory $DIR"
fi

DIR="/data01/home/sybase/logs/BACKUP_VERIFY"
if [ -d "$DIR" ]
then
        echo "SKIPPED - Directory $DIR exists"
else
        mkdir $DIR
        echo "SUCCESS - Created directory $DIR"
fi

DIR="/data01/home/sybase/logs/DBCC"
if [ -d "$DIR" ]
then
        echo "SKIPPED - Directory $DIR exists"
else
        mkdir $DIR
        echo "SUCCESS - Created directory $DIR"
fi

DIR="/lbackup/DB"
if [ -d "$DIR" ]
then
        echo "SKIPPED - Directory $DIR exists"
else
        mkdir $DIR
        echo "SUCCESS - Created directory $DIR"

fi

DIR="/lbackup/LOG"
if [ -d "$DIR" ]
then
        echo "SKIPPED - Directory $DIR exists"
else
        mkdir $DIR
        echo "SUCCESS - Created directory $DIR"
fi


##Granting Permission
#sybuser=`ps -ef | grep dataserver | awk '{print $1;}'| grep -v 'root' |sort -u`;

chown -R $sybuser.sapsys /lbackup/DB;
chown -R $sybuser.sapsys /lbackup/LOG;
chown -R $sybuser.sapsys /data01/home/sybase;
chown -R $sybuser.sapsys /data01/home/sybase/scripts;

##Setting Sybase user password to expire never

if [[ -z `chage -l $sybuser | grep "^Password expires.*never"` ]];
then
        chage -M -1 $sybuser
        echo "SUCCESS - Password is set to expire never for $sybuser";
else
        echo "SKIPPED - Password is already set to expire never for $sybuser"
fi

##Creating logging files
cd /data01/home/sybase/scripts;
echo -e 'ctl007$DBA' > .ctldba_word;
echo -e 'ctl787$BKP' > .ctlbkp_word;
chmod 400 .ctl*_word;
chown $sybuser.sapsys .ctl*_word;

##Creating netbackup directory
DIR="/usr/openv/netbackup/logs/bpbkar"
if [ -d "$DIR" ]
then
        echo "SKIPPED - Directory $DIR exists"
else
        mkdir $DIR
        echo "SUCCESS - Created directory $DIR"
fi

chmod 777 /usr/openv/netbackup/logs/bpbkar;
chmod 644 /usr/openv/netbackup/bp.conf;


echo "===================================Directories created========================================"

ls -lrt /data01/home/sybase/ |grep ^d
ls -lrt /data01/home/sybase/logs/ |grep ^d
ls -rlt /lbackup/ |grep ^d |grep -w 'DB\|LOG'
ls -lrt /usr/openv/netbackup/logs/ | grep ^d |grep bpbkar

echo "=============================================================================================="

##Untar scripts
tar -xvpf /tmp/scripts/NBU.tar -C /tmp/scripts
##Setting SID in scripts
sed -i -e "s/<REPLACE SID>/$SID/g" /tmp/scripts/NBU_FULL_DB_backup.sh
sed -i -e "s/<REPLACE SID>/$SID/g" /tmp/scripts/DISK_FULL_DB_backup.sh
sed -i -e "s/<REPLACE SID>/$SID/g" /tmp/scripts/DISK_CUMULATIVE_DB_backup.sh
sed -i -e "s/SID/$SID/g" /tmp/scripts/crontab.txt
sed -i -e "s/SID/$SID/g" /tmp/scripts/ddl.sql
sed -i -e "s/SID/$SID/g" /tmp/scripts/bash_profile.txt
sed -i -e "s/SID/$SID/g" /tmp/scripts/cshrc.txt

##Copy scripts


FILE="/data01/home/sybase/scripts/dbcc.sh"
if [ -f "$FILE" ]
then
        echo "SKIPPED - Script $FILE exists"
else
        cp /tmp/scripts/dbcc.sh /data01/home/sybase/scripts/dbcc.sh
        echo "SUCCESS - Created script $FILE"
fi


FILE="/data01/home/sybase/scripts/HistoryFile_Clear.sh"
if [ -f "$FILE" ]
then
        echo "SKIPPED - Script $FILE exists"
else
        cp /tmp/scripts/HistoryFile_Clear.sh /data01/home/sybase/scripts/HistoryFile_Clear.sh
        echo "SUCCESS - Created script $FILE"
fi



FILE="/data01/home/sybase/scripts/TLOG_DB_backup.sh"
if [ -f "$FILE" ]
then
        echo "SKIPPED - Script $FILE exists"
else
        cp /tmp/scripts/TLOG_DB_backup.sh /data01/home/sybase/scripts/TLOG_DB_backup.sh
        echo "SUCCESS - Created script $FILE"
fi



FILE="/data01/home/sybase/scripts/DISK_FULL_DB_backup.sh"
if [ -f "$FILE" ]
then
        echo "SKIPPED - Script $FILE exists"
else
        cp /tmp/scripts/DISK_FULL_DB_backup.sh /data01/home/sybase/scripts/DISK_FULL_DB_backup.sh
        echo "SUCCESS - Created script $FILE"
fi

FILE="/data01/home/sybase/scripts/ase_log_rotate.sh"
if [ -f "$FILE" ]
then
        echo "SKIPPED - Script $FILE exists"
else
        cp /tmp/scripts/ase_log_rotate.sh /data01/home/sybase/scripts/ase_log_rotate.sh
        echo "SUCCESS - Created script $FILE"
fi


FILE="/data01/home/sybase/scripts/NBU_FULL_DB_backup.sh"
if [ -f "$FILE" ]
then
        echo "SKIPPED - Script $FILE exists"
else
        cp /tmp/scripts/NBU_FULL_DB_backup.sh /data01/home/sybase/scripts/NBU_FULL_DB_backup.sh
        echo "SUCCESS - Created script $FILE"
fi

FILE="/data01/home/sybase/scripts/backup_verify"
if [ -f "$FILE" ]
then
        echo "SKIPPED - Script $FILE exists"
else
        cp /tmp/scripts/backup_verify /data01/home/sybase/scripts/backup_verify
        echo "SUCCESS - Created script $FILE"
fi


FILE="/data01/home/sybase/scripts/get_sysmon_details"
if [ -f "$FILE" ]
then
        echo "SKIPPED - Script $FILE exists"
else
        cp /tmp/scripts/get_sysmon_details /data01/home/sybase/scripts/get_sysmon_details
        echo "SUCCESS - Created script $FILE"
fi

FILE="/data01/home/sybase/scripts/DISK_CUMULATIVE_DB_backup.sh"
if [ -f "$FILE" ]
then
        echo "SKIPPED - Script $FILE exists"
else
        cp /tmp/scripts/DISK_CUMULATIVE_DB_backup.sh /data01/home/sybase/scripts/DISK_CUMULATIVE_DB_backup.sh
        echo "SUCCESS - Created script $FILE"
fi

chown $sybuser.sapsys /data01/home/sybase/scripts/*
chmod 744 /data01/home/sybase/scripts/*


echo "===================================Script installed==========================================="

ls -lrt /data01/home/sybase/scripts/*

echo "=============================================================================================="

##Setting for Netbackup
#Soft link created

FILE="/sybase/$SID/ASE-16_0/lib/libsybackup.so"
if [ -f "$FILE" ]
then
        echo "SKIPPED - Soft link $FILE exists"
else
        ln -s /usr/openv/netbackup/bin/libsybackup64.so /sybase/$SID/ASE-16_0/lib/libsybackup.so
        echo "SUCCESS - Created Soft link $FILE"
fi

#Correcting permission of libsybackup64.so

FILE="/usr/openv/netbackup/bin/libsybackup64.so"
if [ -f "$FILE" ]
then
		chmod 777 /usr/openv/netbackup/bin/libsybackup64.so
        echo "SUCCESS - Corrected permission of libsybackup64.so"
else
        echo "INFO - Missing file: $FILE"
fi


#Sybase Environment variables are added for Netbackup

if grep -q "SYBASE.sh" ~/.bash_profile;
then
                echo "SKIPPED - Sybase variables exists in root profile"

else
                cp ~/.bash_profile ~/.bash_profile.$gdatetime
				echo "###Sybase Environment variables are added for Netbackup" >> ~/.bash_profile
				echo "#######################################################" >> ~/.bash_profile
                echo ". /sybase/$SID/SYBASE.sh" >> ~/.bash_profile
				echo "#######################################################" >> ~/.bash_profile
                echo "SUCCESS - Sybase variables added to root profile"
fi
echo "=============================================================================================="


echo "===================================Soft link=================================================="

ls -lrt /sybase/$SID/ASE-16_0/lib/libsybackup.so 

echo "=============================================================================================="

echo "===================================Root environment variables================================="

env

echo "=============================================================================================="


exit;

