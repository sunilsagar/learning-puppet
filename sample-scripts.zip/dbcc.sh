#!/bin/bash
#####################################################
## Script dbcc.sh
##      Script to execute dbcc checks for db-es on instance running by the script owner
##      Output is going to log files, log folder defaults to $LOGDIR, folder will be created unless already exists
##      Execution history logged into svvstools db, log table is crated unless already exists
##      Logs are generated with day of month appended allowing to keep maximum 31 days worth of logs
##      Features test run by passing in '-t' argument to have a feel which db-es are checked
##      Automatically picks up all connection parameters from the environment
##      Error checking is based on info @ http://infocenter.sybase.com/help/index.jsp?topic=/com.sybase.dc35823_1251/html/uconfig/X12262.htm
##
## arguments
##	-t	test run
##	-e	execute dbcc checks
##	-l1	log report from history table for last execution
##	-l2	log report from log files for last execution
##
## test run
##      dbcc.sh -t
## execute
##	dbcc.sh -e
## log report from history table for last execution
##      dbcc.sh -l1
##
## prerequisites
##	cron requires ~/SYBASE.sh: ln -s $SYBASE/SYBASE.sh ~/SYBASE.sh
##	svvstools db, log history table will be created in there if not exists
##	permission to create new folder $LOGDIR (default is /data01/home/sybase/logs/DBCC) if not exists
##
## deploy
##	copy script from jumpserver:/software/sybase/dbcc to machine:/data01/home/sybase/scripts folder	
##	test tun by executing "/data01/home/sybase/scripts/dbcc.sh -t"
## 	schedule weekly executions in cron, scatter times across hosts
##              min hour * * day /data01/home/sybase/scripts/dbcc.sh -e > /data01/home/sybase/logs/DBCC/dbcc_cron.log 2>&1
##            e.g.: 05 04 * * 4 /data01/home/sybase/scripts/dbcc.sh -e > /data01/home/sybase/logs/DBCC/dbcc_cron.log 2>&1
##
## documentation
##	https://confluence.savvis.net/display/GDE/dbcc+checks
##
## Modification history
##      Zoltan        07/13/2017	created
##      Zoltan        07/14/2017	added logic to create log folder and log table if not exists
##      Zoltan        07/26/2017	SAP case 371631 Eaton/FIX dbcc checkdb errors, excluded errors from FIX,FID,FIQ,FIP,DF1,DR1 
##      Zoltan        07/29/2017	added -t -l
##      Zoltan        08/01/2017	added -l1 -l2, excluding known errors requiring downtime to fix, -l2 still shows them
##      Zoltan        08/28/2017	excluded Msg 12205 "Could not acquire a lock within the specified wait period" from reporting as error
##      Zoltan        08/29/2017	added session level change "set lock wait 3600" to avoid Msg 12205
##      Zoltan        12/07/2017      	minor changes in documentation, updated confluence page
##      Zoltan        12/22/2017      	exit if there is no ~/SYBASE.sh
##	
#####################################################

if [[ ! -f ~/SYBASE.sh ]]; then echo "Missing ~/SYBASE.sh, you may create it with:";echo "ln -s $SYBASE/SYBASE.sh ~/SYBASE.sh"; exit; fi
. ~/SYBASE.sh

HOST=`hostname`
DBUSER=ctldba
SYBUSER=`whoami`
SID=`echo \$SYBASE | cut -d/ -f3`
DATE=`date +%Y%m%d_%H%M%S`
DATE=`date +%d`
PROCESS_KEY="`date +%y%m%d%H%M%S`"
LOGDIR=/data01/home/sybase/logs/DBCC
PW='#gK6^sP5dQ'
if [ -f "/data01/home/sybase/scripts/.ctldba_word" ]; then PW=`cat /data01/home/sybase/scripts/.ctldba_word`;fi;
if [[ "$HOST" = "smd-cs" && "$SID" = "SMD" ]]; then PW='#gK6^sP5dQ'; fi;
EXCLUSION='Msg 2514|Msg 15052|Msg 7794|Msg 12205'

if [[ -z $1 ]];
then
	echo '
   arguments
        -t      test run
        -e      execute dbcc checks
        -l1     log report from history table for last execution
        -l2     log report from log files for last execution
   test run
        dbcc.sh -t
   execute
        dbcc.sh -e
   log report from history table for last execution
        dbcc.sh -l1
   deploy
        copy script from dc2jump1.mgmt.savvis.net:/software/sybase/dbcc to machine:/data01/home/sybase/scripts folder
        test tun by executing "/data01/home/sybase/scripts/dbcc.sh -t"
        schedule weekly executions in cron, scatter times across hosts
                56 22 * * 0 /data01/home/sybase/scripts/dbcc.sh -e > /data01/home/sybase/logs/DBCC/dbcc_cron.log 2>&1
   documentation
	https://confluence.savvis.net/display/GDE/dbcc+checks
'
	exit
elif [[ $1 = "-l1" ]]; then
	SQL='set nocount on
	--report last execution
	select convert(char(28),START_TIME,109) START_TIME, datediff(ss, START_TIME, END_TIME) "Dur[sec]", SERVER, convert(char(15),DB) DB, STATUS, convert(char(120),DESCRIPTION) DESCRIPTION 
	from svvstools..PROCESS_RUN_DETAILS 
	where PROCESS_NAME = "dbcc_checks" and PROCESS_KEY=(select max(PROCESS_KEY) from svvstools..PROCESS_RUN_DETAILS where PROCESS_NAME = "dbcc_checks" )
	order by START_TIME'
	$SYBASE/$SYBASE_OCS/bin/isql -I $SYBASE/interfaces -S $SID -U $DBUSER -P $PW -X -w1999 <<EOF
	$SQL
go
EOF
	exit
elif [[ $1 = "-l2" ]]; then
	LASTDAY=`ls -1tr /data01/home/sybase/logs/DBCC/dbcc_${SID}_??.log | tail -1 | sed -e "s#.*\(..\).log#\1#"`
	# summary log, may be 0 size during execution
	wc -l /data01/home/sybase/logs/DBCC/dbcc_${SID}_${LASTDAY}.log
	# known errors excluded
	if [[ ! -z "$EXCLUSION" ]]; then echo "Exclusions, known problems for which downtime needed: $EXCLUSION"; fi
	# ALERTS in summary log
	grep -v MSG /data01/home/sybase/logs/DBCC/dbcc_${SID}_${LASTDAY}.log
	# check for Msg in last set
	grep 'Msg ' /data01/home/sybase/logs/DBCC/dbcc_${SID}_*_${LASTDAY}.log | sort -u
	exit
fi

# create logdir if not exist
if [[ ! -d "$LOGDIR" ]];then mkdir -p "$LOGDIR"; fi

# get list of db-es
RETVAL=`$SYBASE/$SYBASE_OCS/bin/isql -I $SYBASE/interfaces -S $SID -U $DBUSER -P $PW -X -b -w199 <<EOF
SET NOCOUNT ON
select name from master..sysdatabases
where  name not in ( 'tempdb', 'model', 'saptempdb', 'svvstools' ) and name not like 'pubs%'
        --name not in ( 'model' )
        --name not in ( 'master', 'model', 'tempdb', 'saptempdb', 'svvstools', 'sybmgmtdb', 'sybpcidb', 'sybsystemdb', 'sybsystemprocs', 'test', 'sybsecurity', 'saptools')
        --name in ('master','svvstools','sybpcidb')
        --name in ('svvstools')
        and status2&16!=16      --skip offline db-es
GO
--create log table if not exist
use svvstools
go
setuser 'dbo'
go 
IF NOT EXISTS (SELECT 1 FROM svvstools.dbo.sysobjects WHERE name = 'PROCESS_RUN_DETAILS')
execute("create table PROCESS_RUN_DETAILS (
	PROCESS_KEY                     decimal(18,0)                        null,
	PROCESS_NAME                    varchar(60)                          null,
	START_TIME                      datetime                             null,
	END_TIME                        datetime                             null,
	SERVER                          varchar(10)                          null,
	DB                              varchar(30)                          null,
	STATUS                          char(1)                              null,
	DESCRIPTION                     varchar(2000)                        null)")
go
EOF`

if [[ $RETVAL =~ failed ]]; then
  echo "ALERT - ASE_DB_DBCC: cannot establish isql connection to $SID as $DBUSER on $HOST at $DATE."
  echo $RETVAL"."
  exit 0
elif [[ $RETVAL =~ "server name" ]]; then
  echo "ALERT - ASE_DB_DBCC: cannot find dataserver $SID as $DBUSER on $HOST at $DATE."
  echo "ALERT" $RETVAL"."
  exit 0
else

if [[ $1 = "-e" ]]; then cat /dev/null > ${LOGDIR}/dbcc_${SID}_$DATE.log; fi

for db in $RETVAL; do

if [[ $1 = "-e" ]]; then
	SQL="set nocount on
insert into svvstools..PROCESS_RUN_DETAILS(PROCESS_KEY, PROCESS_NAME, START_TIME, END_TIME, SERVER, DB, STATUS, DESCRIPTION) values ( ${PROCESS_KEY},'dbcc_checks',getdate(),null,'${SID}','${db}','R','log is ${LOGDIR}/dbcc_${SID}_${db}_${DATE}.log')"
	RETVAL2=`$SYBASE/$SYBASE_OCS/bin/isql -I $SYBASE/interfaces -S $SID -U $DBUSER -P $PW -X -b -w199 <<EOF
	$SQL
	set lock wait 3600
	dbcc checkdb( $db )
	dbcc checkcatalog( $db )
go
EOF`

	echo "$RETVAL2" > ${LOGDIR}/dbcc_${SID}_${db}_$DATE.log

	#if [[ $RETVAL2 =~ "Msg 25" ]]; then
	if [[ `echo "$RETVAL2" | grep 'Msg ' | egrep -v "$EXCLUSION" | wc -c` -ne 0 ]]; then
	  echo "ALERT - ASE_DB_DBCC: $db database on $SID $host failed DBCC checks." | tee -a ${LOGDIR}/dbcc_${SID}_$DATE.log
	  SQL="update svvstools..PROCESS_RUN_DETAILS set END_TIME = getdate(), STATUS = 'E' , DESCRIPTION = DESCRIPTION + ', dbcc checks for DB ${db} failed.' where PROCESS_KEY = ${PROCESS_KEY} and DB = '${db}' and PROCESS_NAME = 'dbcc_checks' "
	else
	  echo "MSG - ASE_DB_DBCC: $db database on $SID $host passed DBCC checks." | tee -a ${LOGDIR}/dbcc_${SID}_$DATE.log
	  SQL="update svvstools..PROCESS_RUN_DETAILS set END_TIME = getdate(), STATUS = 'C' , DESCRIPTION = DESCRIPTION + ', dbcc checks for DB ${db} completed succesfully.' where PROCESS_KEY = ${PROCESS_KEY} and DB = '${db}' and PROCESS_NAME = 'dbcc_checks' "
	fi

	# update status table
	$SYBASE/$SYBASE_OCS/bin/isql -I $SYBASE/interfaces -S $SID -U $DBUSER -P $PW -X -b -w199 <<EOF
	set nocount on
	$SQL
	--select PROCESS_KEY, convert(char(15),PROCESS_NAME), convert(varchar,START_TIME,109), convert(varchar,END_TIME,109), SERVER, DB, STATUS, convert(varchar(120),DESCRIPTION) from svvstools..PROCESS_RUN_DETAILS where PROCESS_NAME = 'dbcc_checks' order by PROCESS_KEY
go
EOF
elif [[ $1 = "-t" ]]; then
	echo "dbcc checkdb( $db )"
	echo "dbcc checkcatalog( $db )"
fi
done
fi
