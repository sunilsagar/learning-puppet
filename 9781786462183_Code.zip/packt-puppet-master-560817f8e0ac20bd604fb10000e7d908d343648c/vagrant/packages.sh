#!/bin/bash

yum -y -q install git || exit 1
